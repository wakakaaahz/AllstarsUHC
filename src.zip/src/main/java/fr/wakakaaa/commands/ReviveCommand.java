package fr.wakakaaa.commands;

import fr.wakakaaa.Main;
import fr.wakakaaa.managers.RankManager;
import fr.wakakaaa.roles.Role;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ReviveCommand implements CommandExecutor {

    private Main plugin;

    public ReviveCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player)) {
            sender.sendMessage("§cCette commande est réservée aux joueurs !");
            return true;
        }

        Player player = (Player) sender;

        if (!plugin.getRankManager().hasPermission(player, RankManager.Rank.MODERATOR)) {
            player.sendMessage("§cTu n'as pas la permission !");
            return true;
        }

        if (args.length < 1) {
            player.sendMessage("§cUsage: /revive <joueur>");
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            player.sendMessage("§cJoueur introuvable !");
            return true;
        }

        if (!plugin.getRoleManager().hasLastRole(target)) {
            player.sendMessage("§c" + target.getName() + " n'avait pas de rôle ou n'est pas mort !");
            return true;
        }

        Role lastRole = plugin.getRoleManager().getLastRole(target);
        plugin.getRoleManager().clearLastRole(target);

        // Appliquer directement sans respawn — le joueur est déjà en spectateur
        target.setGameMode(GameMode.SURVIVAL);
        plugin.getRoleManager().assignRole(target, lastRole);
        target.setHealth(target.getMaxHealth());
        target.setFoodLevel(20);
        target.setSaturation(20);
        target.sendMessage("§aTu as été revivifié avec ton rôle §6" + lastRole.getName() + " §a!");

        player.sendMessage("§aTu as revivifié §6" + target.getName() + " §a!");
        Bukkit.broadcastMessage("§a" + target.getName() + " §7a été revivifié !");
        return true;
    }
}