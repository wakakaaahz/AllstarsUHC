package fr.wakakaaa.commands;

import fr.wakakaaa.Main;
import fr.wakakaaa.managers.RankManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class HealCommand implements CommandExecutor {

    private Main plugin;

    public HealCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player)) {
            sender.sendMessage("§cCette commande est réservée aux joueurs !");
            return true;
        }

        Player player = (Player) sender;

        if (!plugin.getRankManager().hasPermission(player, RankManager.Rank.MODERATOR)) {
            player.sendMessage("§cTu n'as pas la permission !");
            return true;
        }

        // /heal sans argument = se heal soi-même
        if (args.length == 0) {
            player.setHealth(player.getMaxHealth());
            player.setFoodLevel(20);
            player.setSaturation(20);
            player.sendMessage("§aTu as été soigné !");
            return true;
        }

        // /heal <joueur>
        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            player.sendMessage("§cJoueur introuvable !");
            return true;
        }

        target.setHealth(target.getMaxHealth());
        target.setFoodLevel(20);
        target.setSaturation(20);
        target.sendMessage("§aTu as été soigné par §6" + player.getName() + " §a!");
        player.sendMessage("§aTu as soigné §6" + target.getName() + " §a!");
        return true;
    }
}