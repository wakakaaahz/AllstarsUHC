package fr.wakakaaa.commands;

import fr.wakakaaa.Main;
import fr.wakakaaa.roles.Role;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class RolesCommand implements CommandExecutor {

    private Main plugin;

    public RolesCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player)) {
            sender.sendMessage("§cCette commande est réservée aux joueurs !");
            return true;
        }

        Player player = (Player) sender;

        player.sendMessage("§6§l--- Rôles dans la partie ---");

        boolean hasRoles = false;
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (plugin.getRoleManager().hasRole(online)) {
                hasRoles = true;
                Role role = plugin.getRoleManager().getRole(online);
                player.sendMessage("§e" + online.getName() + " §7→ §a" + role.getName());
            }
        }

        if (!hasRoles) {
            player.sendMessage("§cAucun rôle attribué pour l'instant !");
        }

        return true;
    }
}