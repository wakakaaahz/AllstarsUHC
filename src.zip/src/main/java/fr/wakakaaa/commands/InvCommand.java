package fr.wakakaaa.commands;

import fr.wakakaaa.Main;
import fr.wakakaaa.managers.RankManager;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class InvCommand implements CommandExecutor {

    private Main plugin;

    public InvCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player)) {
            sender.sendMessage("§cCette commande est réservée aux joueurs !");
            return true;
        }

        Player player = (Player) sender;

        if (!plugin.getRankManager().hasPermission(player, RankManager.Rank.MODERATOR)) {
            player.sendMessage("§cTu n'as pas la permission !");
            return true;
        }

        player.getInventory().clear();
        player.setGameMode(GameMode.CREATIVE);
        player.sendMessage("§aTu es en mode créatif, fais ton inventaire de départ !");
        player.sendMessage("§eTape §6/saveinv §equand tu as terminé !");
        return true;
    }
}