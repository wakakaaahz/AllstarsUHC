package fr.wakakaaa.commands;

import fr.wakakaaa.Main;
import fr.wakakaaa.managers.RankManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class FreezeCommand implements CommandExecutor {

    private Main plugin;

    public FreezeCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player)) {
            sender.sendMessage("§cCette commande est réservée aux joueurs !");
            return true;
        }

        Player player = (Player) sender;

        if (!plugin.getRankManager().hasPermission(player, RankManager.Rank.MODERATOR)) {
            player.sendMessage("§cTu n'as pas la permission !");
            return true;
        }

        if (args.length == 0) {
            player.sendMessage("§cUsage: /freeze <joueur>");
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            player.sendMessage("§cJoueur introuvable !");
            return true;
        }

        if (plugin.getFreezeManager().isFrozen(target)) {
            plugin.getFreezeManager().unfreeze(target);
            player.sendMessage("§a" + target.getName() + " a été dégelé !");
            target.sendMessage("§aTu as été dégelé !");
        } else {
            plugin.getFreezeManager().freeze(target);
            player.sendMessage("§6" + target.getName() + " a été gelé !");
            target.sendMessage("§cTu as été gelé par un modérateur !");
        }

        return true;
    }
}