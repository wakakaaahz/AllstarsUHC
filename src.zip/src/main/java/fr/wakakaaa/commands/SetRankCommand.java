package fr.wakakaaa.commands;

import fr.wakakaaa.Main;
import fr.wakakaaa.managers.RankManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SetRankCommand implements CommandExecutor {

    private Main plugin;

    public SetRankCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player)) {
            sender.sendMessage("§cCette commande est réservée aux joueurs !");
            return true;
        }

        Player player = (Player) sender;

        if (!plugin.getRankManager().hasPermission(player, RankManager.Rank.OWNER)) {
            player.sendMessage("§cTu n'as pas la permission !");
            return true;
        }

        if (args.length < 2) {
            player.sendMessage("§cUsage: /setrank <joueur> <owner|admin|modo|player>");
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            player.sendMessage("§cJoueur introuvable !");
            return true;
        }

        RankManager.Rank rank;
        switch (args[1].toLowerCase()) {
            case "owner":
                rank = RankManager.Rank.OWNER;
                break;
            case "admin":
                rank = RankManager.Rank.ADMIN;
                break;
            case "modo":
                rank = RankManager.Rank.MODERATOR;
                break;
            case "player":
                rank = RankManager.Rank.PLAYER;
                break;
            default:
                player.sendMessage("§cGrade inconnu ! Utilise: owner, admin, modo, player");
                return true;
        }

        plugin.getRankManager().setRank(target, rank);
        player.sendMessage("§aGrade §6" + rank.name() + " §adonné à §6" + target.getName());
        target.sendMessage("§aTu as reçu le grade §6" + rank.name());
        return true;
    }
}