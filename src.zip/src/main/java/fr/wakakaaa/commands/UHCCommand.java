package fr.wakakaaa.commands;

import fr.wakakaaa.Main;
import fr.wakakaaa.managers.RankManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class UHCCommand implements CommandExecutor {

    private Main plugin;

    public UHCCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player)) {
            sender.sendMessage("§cCette commande est réservée aux joueurs !");
            return true;
        }

        Player player = (Player) sender;

        if (!plugin.getRankManager().hasPermission(player, RankManager.Rank.MODERATOR)) {
            player.sendMessage("§cTu n'as pas la permission !");
            return true;
        }

        if (args.length == 0) {
            player.sendMessage("§6Usage: /uhc <start|stop>");
            return true;
        }

        if (args[0].equalsIgnoreCase("start")) {
            plugin.getGameManager().startGame();
            return true;
        }

        if (args[0].equalsIgnoreCase("stop")) {
            plugin.getGameManager().stopGame();
            return true;
        }

        player.sendMessage("§cCommande inconnue ! Usage: /uhc <start|stop>");
        return true;
    }
}