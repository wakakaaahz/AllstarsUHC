package fr.wakakaaa.commands;

import fr.wakakaaa.Main;
import fr.wakakaaa.managers.RankManager;
import fr.wakakaaa.roles.*;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import fr.wakakaaa.roles.StainRole;
import fr.wakakaaa.roles.SunrakuRole;
import fr.wakakaaa.roles.TengenRole;

public class SetRoleCommand implements CommandExecutor {

    private Main plugin;

    public SetRoleCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player)) {
            sender.sendMessage("§cCette commande est réservée aux joueurs !");
            return true;
        }

        Player player = (Player) sender;

        if (!plugin.getRankManager().hasPermission(player, RankManager.Rank.MODERATOR)) {
            player.sendMessage("§cTu n'as pas la permission !");
            return true;
        }

        if (args.length < 2) {
            player.sendMessage("§cUsage: /setrole <joueur> <luffy|kashimo|gojo>");
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            player.sendMessage("§cJoueur introuvable !");
            return true;
        }

        Role role;
        switch (args[1].toLowerCase()) {
            case "luffy":
                role = new LuffyRole();
                break;
            case "kashimo":
                role = new KashimoRole();
                break;
            case "gojo":
                role = new GojoRole();
                break;
            case "kokushibo":
                role = new KokushiboRole();
                break;
            case "stain":
                role = new StainRole();
                break;
            case "yoriichi":
                role = new YoriichRole();
                break;
            case "sunraku":
                role = new SunrakuRole(plugin);
                break;
            case "tengen":
                role = new TengenRole(plugin);
                break;
            default:
                player.sendMessage("§cRôle inconnu ! Utilise: luffy, kashimo, gojo, kokushibo, sunraku, tengen");
                return true;
        }

        if (plugin.getRoleManager().hasRole(target)) {
            plugin.getRoleManager().removeRole(target);
        }

        plugin.getRoleManager().assignRole(target, role);
        player.sendMessage("§aRôle §6" + role.getName() + " §aattribué à §6" + target.getName());
        target.sendMessage("§aTon rôle a été changé en §6" + role.getName());
        return true;
    }
}