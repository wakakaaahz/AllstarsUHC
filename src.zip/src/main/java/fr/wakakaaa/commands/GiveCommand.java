package fr.wakakaaa.commands;

import fr.wakakaaa.Main;
import fr.wakakaaa.managers.RankManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class GiveCommand implements CommandExecutor {

    private Main plugin;

    public GiveCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player)) {
            sender.sendMessage("§cCette commande est réservée aux joueurs !");
            return true;
        }

        Player player = (Player) sender;

        if (!plugin.getRankManager().hasPermission(player, RankManager.Rank.MODERATOR)) {
            player.sendMessage("§cTu n'as pas la permission !");
            return true;
        }

        if (args.length < 2) {
            player.sendMessage("§cUsage: /give <joueur> <item> <quantité>");
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            player.sendMessage("§cJoueur introuvable !");
            return true;
        }

        Material material = Material.getMaterial(args[1].toUpperCase());
        if (material == null) {
            player.sendMessage("§cItem inconnu : " + args[1]);
            return true;
        }

        int amount = 1;
        if (args.length >= 3) {
            try {
                amount = Integer.parseInt(args[2]);
            } catch (NumberFormatException e) {
                player.sendMessage("§cLa quantité doit être un nombre !");
                return true;
            }
        }

        target.getInventory().addItem(new ItemStack(material, amount));
        player.sendMessage("§aDonné §6" + amount + "x " + material.name() + " §aà §6" + target.getName());
        target.sendMessage("§aTu as reçu §6" + amount + "x " + material.name());
        return true;
    }
}