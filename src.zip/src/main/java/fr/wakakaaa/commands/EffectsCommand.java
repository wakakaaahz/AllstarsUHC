package fr.wakakaaa.commands;

import fr.wakakaaa.Main;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import fr.wakakaaa.utils.EffectUtils;

public class EffectsCommand implements CommandExecutor {

    private Main plugin;

    public EffectsCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player)) {
            sender.sendMessage("§cCette commande est réservée aux joueurs !");
            return true;
        }

        Player player = (Player) sender;

        if (player.getActivePotionEffects().isEmpty()) {
            player.sendMessage("§cTu n'as aucun effet actif !");
            return true;
        }

        player.sendMessage("§6§l--- Tes effets actifs ---");

        for (PotionEffect effect : player.getActivePotionEffects()) {
            String nom = EffectUtils.getEffectName(effect.getType());
            int percentage = EffectUtils.getPercentage(effect.getType(), effect.getAmplifier());
            String bar = EffectUtils.getBar(percentage / 10);

            player.sendMessage("§a" + nom + " §f" + percentage + "%");
            player.sendMessage("  " + bar);
        }

        return true;
    }
}