package fr.wakakaaa;

import fr.wakakaaa.managers.CampManager;
import fr.wakakaaa.managers.GameManager;
import org.bukkit.plugin.java.JavaPlugin;
import fr.wakakaaa.commands.UHCCommand;
import fr.wakakaaa.managers.RoleManager;
import fr.wakakaaa.listeners.PlayerJoinListener;
import fr.wakakaaa.listeners.PlayerDeathListener;
import fr.wakakaaa.listeners.PlayerRespawnListener;
import fr.wakakaaa.managers.TimerManager;
import fr.wakakaaa.managers.ScoreboardManager;
import fr.wakakaaa.commands.InvCommand;
import fr.wakakaaa.commands.SaveInvCommand;
import fr.wakakaaa.managers.KitManager;
import fr.wakakaaa.listeners.BlockFromToListener;
import fr.wakakaaa.listeners.BlockPlaceListener;
import fr.wakakaaa.commands.GiveCommand;
import fr.wakakaaa.commands.EffectsCommand;
import fr.wakakaaa.managers.KillManager;
import fr.wakakaaa.managers.BorderManager;
import fr.wakakaaa.listeners.PlayerRegainHealthListener;
import fr.wakakaaa.commands.RolesCommand;
import fr.wakakaaa.managers.RankManager;
import fr.wakakaaa.commands.SetRankCommand;
import fr.wakakaaa.listeners.ChatListener;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import fr.wakakaaa.managers.FreezeManager;
import fr.wakakaaa.commands.FreezeCommand;
import fr.wakakaaa.listeners.FreezeListener;
import fr.wakakaaa.listeners.KashimoListener;
import fr.wakakaaa.listeners.GojoListener;
import fr.wakakaaa.commands.SetRoleCommand;
import fr.wakakaaa.listeners.KokushiboListener;
import fr.wakakaaa.commands.HealCommand;
import fr.wakakaaa.commands.ReviveCommand;
import fr.wakakaaa.listeners.StainListener;
import fr.wakakaaa.listeners.YoriichListener;
import fr.wakakaaa.listeners.SunrakuListener;
import fr.wakakaaa.listeners.TengenListener;

public class Main extends JavaPlugin {

    private static Main instance;
    private GameManager gameManager;
    private RoleManager roleManager;
    private TimerManager timerManager;
    private ScoreboardManager scoreboardManager;
    private KitManager kitManager;
    private KillManager killManager;
    private BorderManager borderManager;
    private RankManager rankManager;
    private FreezeManager freezeManager;
    private CampManager campManager;

    @Override
    public void onEnable() {
        instance = this;
        gameManager = new GameManager(this);
        roleManager = new RoleManager(this);
        timerManager = new TimerManager(this);
        scoreboardManager = new ScoreboardManager(this);
        kitManager = new KitManager();
        killManager = new KillManager();
        borderManager = new BorderManager(this);
        rankManager = new RankManager();
        campManager = new CampManager(this);

        final RankManager rm = rankManager;
        Bukkit.getScheduler().runTaskLater(this, new Runnable() {
            @Override
            public void run() {
                Player owner = Bukkit.getPlayer("wxkakaaa");
                if (owner != null) {
                    rm.setRank(owner, RankManager.Rank.OWNER);
                    owner.sendMessage("§4Tu as automatiquement reçu le grade Owner !");
                }
            }
        }, 20L);

        freezeManager = new FreezeManager(this);
        getCommand("freeze").setExecutor(new FreezeCommand(this));
        getCommand("setrole").setExecutor(new SetRoleCommand(this));
        getCommand("revive").setExecutor(new ReviveCommand(this));
        getCommand("heal").setExecutor(new HealCommand(this));
        getServer().getPluginManager().registerEvents(new KokushiboListener(this), this);
        getServer().getPluginManager().registerEvents(new FreezeListener(this), this);
        getServer().getPluginManager().registerEvents(new GojoListener(this), this);
        getServer().getPluginManager().registerEvents(new StainListener(this), this);
        getServer().getPluginManager().registerEvents(new YoriichListener(this), this);
        getServer().getPluginManager().registerEvents(new SunrakuListener(this), this);
        getServer().getPluginManager().registerEvents(new TengenListener(this), this);
        getCommand("effects").setExecutor(new EffectsCommand(this));
        getServer().getPluginManager().registerEvents(new KashimoListener(this), this);
        getServer().getPluginManager().registerEvents(new ChatListener(this), this);
        getCommand("setrank").setExecutor(new SetRankCommand(this));
        getCommand("roles").setExecutor(new RolesCommand(this));
        getServer().getPluginManager().registerEvents(new PlayerRegainHealthListener(this), this);
        getCommand("give").setExecutor(new GiveCommand(this));
        getServer().getPluginManager().registerEvents(new BlockPlaceListener(this), this);
        getServer().getPluginManager().registerEvents(new BlockFromToListener(this), this);
        getCommand("inv").setExecutor(new InvCommand(this));
        getCommand("saveinv").setExecutor(new SaveInvCommand(this));
        getCommand("uhc").setExecutor(new UHCCommand(this));
        getServer().getPluginManager().registerEvents(new PlayerDeathListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerRespawnListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerJoinListener(this), this);
        getLogger().info("OnePiece UHC activé !");
    }

    @Override
    public void onDisable() {
        getLogger().info("OnePiece UHC désactivé !");
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (roleManager.hasRole(player)) {
                roleManager.getRole(player).removeRole(player);
            }
        }
    }

    public static Main getInstance() { return instance; }
    public GameManager getGameManager() { return gameManager; }
    public RoleManager getRoleManager() { return roleManager; }
    public TimerManager getTimerManager() { return timerManager; }
    public ScoreboardManager getScoreboardManager() { return scoreboardManager; }
    public KitManager getKitManager() { return kitManager; }
    public KillManager getKillManager() { return killManager; }
    public BorderManager getBorderManager() { return borderManager; }
    public RankManager getRankManager() { return rankManager; }
    public FreezeManager getFreezeManager() { return freezeManager; }
    public CampManager getCampManager() { return campManager; }
}