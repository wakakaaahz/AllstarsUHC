package fr.wakakaaa.utils;

import org.bukkit.potion.PotionEffectType;

public class EffectUtils {

    public static int getPercentage(PotionEffectType type, int amplifier) {
        int level = amplifier + 1;

        if (type.equals(PotionEffectType.SPEED)) {
            return level * 20;
        }
        if (type.equals(PotionEffectType.INCREASE_DAMAGE)) {
            return level * 15;
        }
        if (type.equals(PotionEffectType.DAMAGE_RESISTANCE)) {
            return level * 20;
        }
        if (type.equals(PotionEffectType.JUMP)) {
            return level * 20;
        }
        if (type.equals(PotionEffectType.REGENERATION)) {
            return level * 10;
        }

        return level * 10;
    }

    public static String getEffectName(PotionEffectType type) {
        if (type.equals(PotionEffectType.SPEED)) return "Vitesse";
        if (type.equals(PotionEffectType.INCREASE_DAMAGE)) return "Force";
        if (type.equals(PotionEffectType.DAMAGE_RESISTANCE)) return "Résistance";
        if (type.equals(PotionEffectType.JUMP)) return "Saut";
        if (type.equals(PotionEffectType.REGENERATION)) return "Régénération";
        if (type.equals(PotionEffectType.FIRE_RESISTANCE)) return "Résistance au feu";
        if (type.equals(PotionEffectType.WATER_BREATHING)) return "Respiration aquatique";
        if (type.equals(PotionEffectType.INVISIBILITY)) return "Invisibilité";
        if (type.equals(PotionEffectType.NIGHT_VISION)) return "Vision nocturne";
        return type.getName();
    }

    public static String getBar(int percentage) {
        int filled = percentage / 10;
        StringBuilder bar = new StringBuilder("§a");
        for (int i = 0; i < 10; i++) {
            if (i < filled) {
                bar.append("■");
            } else {
                bar.append("§7■");
            }
        }
        return bar.toString();
    }
}