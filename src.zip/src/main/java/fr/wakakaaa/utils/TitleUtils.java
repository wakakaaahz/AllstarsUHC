package fr.wakakaaa.utils;

import org.bukkit.entity.Player;

public class TitleUtils {

    public static void sendTitle(Player player, String title, String subtitle) {
        try {
            Object entityPlayer = player.getClass().getMethod("getHandle").invoke(player);
            Class<?> chatSerializer = Class.forName("net.minecraft.server.v1_8_R3.IChatBaseComponent$ChatSerializer");

            Object chatTitle = chatSerializer.getMethod("a", String.class)
                    .invoke(null, "{\"text\":\"" + title + "\"}");
            Object chatSubtitle = chatSerializer.getMethod("a", String.class)
                    .invoke(null, "{\"text\":\"" + subtitle + "\"}");

            Class<?> titleAction = Class.forName("net.minecraft.server.v1_8_R3.PacketPlayOutTitle$EnumTitleAction");
            Class<?> packetClass = Class.forName("net.minecraft.server.v1_8_R3.PacketPlayOutTitle");
            Class<?> chatComponent = Class.forName("net.minecraft.server.v1_8_R3.IChatBaseComponent");

            Object packetTitle = packetClass
                    .getConstructor(titleAction, chatComponent, int.class, int.class, int.class)
                    .newInstance(titleAction.getField("TITLE").get(null), chatTitle, 10, 70, 20);

            Object packetSubtitle = packetClass
                    .getConstructor(titleAction, chatComponent, int.class, int.class, int.class)
                    .newInstance(titleAction.getField("SUBTITLE").get(null), chatSubtitle, 10, 70, 20);

            Object connection = entityPlayer.getClass().getField("playerConnection").get(entityPlayer);
            Class<?> packetInterface = Class.forName("net.minecraft.server.v1_8_R3.Packet");
            connection.getClass().getMethod("sendPacket", packetInterface).invoke(connection, packetTitle);
            connection.getClass().getMethod("sendPacket", packetInterface).invoke(connection, packetSubtitle);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void sendActionBar(Player player, String message) {
        try {
            Object entityPlayer = player.getClass().getMethod("getHandle").invoke(player);
            Class<?> chatSerializer = Class.forName("net.minecraft.server.v1_8_R3.IChatBaseComponent$ChatSerializer");
            Class<?> chatComponent = Class.forName("net.minecraft.server.v1_8_R3.IChatBaseComponent");
            Class<?> packetClass = Class.forName("net.minecraft.server.v1_8_R3.PacketPlayOutChat");

            Object chat = chatSerializer.getMethod("a", String.class)
                    .invoke(null, "{\"text\":\"" + message + "\"}");

            Object packet = packetClass
                    .getConstructor(chatComponent, byte.class)
                    .newInstance(chat, (byte) 2);

            Object connection = entityPlayer.getClass().getField("playerConnection").get(entityPlayer);
            Class<?> packetInterface = Class.forName("net.minecraft.server.v1_8_R3.Packet");
            connection.getClass().getMethod("sendPacket", packetInterface).invoke(connection, packet);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void sendTabHeaderFooter(Player player, String header, String footer) {
        try {
            Object entityPlayer = player.getClass().getMethod("getHandle").invoke(player);
            Class<?> chatSerializer = Class.forName("net.minecraft.server.v1_8_R3.IChatBaseComponent$ChatSerializer");
            Class<?> chatComponent = Class.forName("net.minecraft.server.v1_8_R3.IChatBaseComponent");
            Class<?> packetClass = Class.forName("net.minecraft.server.v1_8_R3.PacketPlayOutPlayerListHeaderFooter");

            Object chatHeader = chatSerializer.getMethod("a", String.class)
                    .invoke(null, "{\"text\":\"" + header + "\"}");
            Object chatFooter = chatSerializer.getMethod("a", String.class)
                    .invoke(null, "{\"text\":\"" + footer + "\"}");

            // Créer le packet via constructeur vide puis setter les champs via reflection forcée
            Object packet = packetClass.newInstance();

            java.lang.reflect.Field[] fields = packetClass.getDeclaredFields();
            fields[0].setAccessible(true);
            fields[0].set(packet, chatHeader);
            fields[1].setAccessible(true);
            fields[1].set(packet, chatFooter);

            Object connection = entityPlayer.getClass().getField("playerConnection").get(entityPlayer);
            Class<?> packetInterface = Class.forName("net.minecraft.server.v1_8_R3.Packet");
            connection.getClass().getMethod("sendPacket", packetInterface).invoke(connection, packet);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}