package fr.wakakaaa.listeners;

import fr.wakakaaa.Main;
import fr.wakakaaa.managers.GameManager;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.Material;

public class BlockPlaceListener implements Listener {

    private Main plugin;

    public BlockPlaceListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        if (plugin.getGameManager().getState() != GameManager.GameState.INGAME) {
            return;
        }

        Block block = event.getBlock();

        plugin.getServer().getScheduler().runTaskLater(plugin, new Runnable() {
            @Override
            public void run() {
                if (block.getType() != Material.AIR) {
                    block.setType(Material.AIR);
                }
            }
        }, 20L * 15);
    }
}