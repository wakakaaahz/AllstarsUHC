package fr.wakakaaa.listeners;

import fr.wakakaaa.Main;
import fr.wakakaaa.roles.Role;
import fr.wakakaaa.roles.TengenRole;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class TengenListener implements Listener {

    private final Main plugin;

    public TengenListener(Main plugin) {
        this.plugin = plugin;
    }

    // ── Coups avec le Kris → Souffle du Son ──────────────────────────────────
    @EventHandler(priority = EventPriority.MONITOR)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (event.isCancelled()) return;
        if (!(event.getDamager() instanceof Player)) return;
        if (!(event.getEntity() instanceof Player)) return;

        Player attacker = (Player) event.getDamager();
        Player victim   = (Player) event.getEntity();

        if (!plugin.getRoleManager().hasRole(attacker)) return;
        Role role = plugin.getRoleManager().getRole(attacker);
        if (!(role instanceof TengenRole)) return;

        TengenRole tengen = (TengenRole) role;
        ItemStack item = attacker.getItemInHand();

        if (!tengen.isKrisSword(item)) return;

        tengen.onHit(attacker, victim);
    }

    // ── Clic droit sur Écho ──────────────────────────────────────────────────
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();

        if (!plugin.getRoleManager().hasRole(player)) return;
        Role role = plugin.getRoleManager().getRole(player);
        if (!(role instanceof TengenRole)) return;

        TengenRole tengen = (TengenRole) role;
        ItemStack item = player.getItemInHand();

        if (!tengen.isEchoItem(item)) return;

        if (event.getAction() == Action.RIGHT_CLICK_AIR ||
                event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            event.setCancelled(true);
            tengen.triggerEcho(player);
        }
    }

    // ── Cleanup au déco ──────────────────────────────────────────────────────
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getRoleManager().hasRole(player)) return;
        Role role = plugin.getRoleManager().getRole(player);
        if (!(role instanceof TengenRole)) return;
        ((TengenRole) role).removeRole(player);
    }
}