package fr.wakakaaa.listeners;

import fr.wakakaaa.Main;
import fr.wakakaaa.roles.Role;
import fr.wakakaaa.roles.StainRole;
import fr.wakakaaa.utils.TitleUtils;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class StainListener implements Listener {

    private Main plugin;

    public StainListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getItemInHand();

        if (!plugin.getRoleManager().hasRole(player)) return;
        Role role = plugin.getRoleManager().getRole(player);
        if (!(role instanceof StainRole)) return;

        StainRole stain = (StainRole) role;

        if (stain.isArsenalItem(item)) {
            if (event.getAction() == Action.LEFT_CLICK_AIR ||
                    event.getAction() == Action.LEFT_CLICK_BLOCK) {
                event.setCancelled(true);
                stain.onArsenalLeftClick(player);
            }
            if (event.getAction() == Action.RIGHT_CLICK_AIR ||
                    event.getAction() == Action.RIGHT_CLICK_BLOCK) {
                event.setCancelled(true);
                stain.onArsenalRightClick(player);
                // ── NOUVEAU : afficher l'arme sélectionnée dans l'action bar ──
                TitleUtils.sendActionBar(player, stain.getSelectedWeaponName(player));
            }
        }

        if (stain.isCoagulationItem(item)) {
            if (event.getAction() == Action.RIGHT_CLICK_AIR ||
                    event.getAction() == Action.RIGHT_CLICK_BLOCK) {
                event.setCancelled(true);
                stain.onCoagulation(player);
            }
        }
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player)) return;
        if (!(event.getEntity() instanceof Player)) return;
        if (event.isCancelled()) return;

        Player attacker = (Player) event.getDamager();
        Player victim = (Player) event.getEntity();

        if (!plugin.getRoleManager().hasRole(attacker)) return;
        Role role = plugin.getRoleManager().getRole(attacker);
        if (!(role instanceof StainRole)) return;

        StainRole stain = (StainRole) role;

        ItemStack inHand = attacker.getItemInHand();
        if (inHand != null && stain.isArsenalItem(inHand)) return;

        double multiplier = stain.getDamageMultiplier(victim);
        if (multiplier > 1.0) {
            event.setDamage(event.getDamage() * multiplier);
        }

        stain.trackHit(victim);
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        if (event.isCancelled()) return;

        Player victim = (Player) event.getEntity();

        for (Player p : org.bukkit.Bukkit.getOnlinePlayers()) {
            if (!plugin.getRoleManager().hasRole(p)) continue;
            Role role = plugin.getRoleManager().getRole(p);
            if (!(role instanceof StainRole)) continue;
            StainRole stain = (StainRole) role;
            if (stain.isCoagulated(victim)) {
                stain.onCoagulatedPlayerDamage(victim, event.getDamage());
            }
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getRoleManager().hasRole(player)) return;
        Role role = plugin.getRoleManager().getRole(player);
        if (!(role instanceof StainRole)) return;
        ((StainRole) role).removeRole(player);
    }
}