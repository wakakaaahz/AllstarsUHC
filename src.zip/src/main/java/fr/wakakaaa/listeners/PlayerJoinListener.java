package fr.wakakaaa.listeners;

import fr.wakakaaa.Main;
import fr.wakakaaa.managers.GameManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.entity.Player;
import org.bukkit.Location;
import fr.wakakaaa.managers.RankManager;

public class PlayerJoinListener implements Listener {

    private Main plugin;

    public PlayerJoinListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        player.sendMessage("§6Bienvenue sur OnePiece UHC !");
        event.setJoinMessage(null);
        plugin.getScoreboardManager().updateScoreboard(player);

        if (player.getName().equals("wxkakaaa")) {
            plugin.getRankManager().setRank(player, RankManager.Rank.OWNER);
        }
        if (player.getName().equals("Bpdr")) {
            plugin.getRankManager().setRank(player, RankManager.Rank.OWNER);
        }

        player.teleport(new Location(player.getWorld(), 0.5, 80, 0.5));

        for (PotionEffect effect : player.getActivePotionEffects()) {
            player.removePotionEffect(effect.getType());
        }

        player.setHealth(20.0);
        player.setFoodLevel(20);
        player.setSaturation(20);
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        if (plugin.getGameManager().getState() == GameManager.GameState.INGAME) {
            event.setQuitMessage(null);
            plugin.getRoleManager().removeRole(event.getPlayer());
        }
    }
}