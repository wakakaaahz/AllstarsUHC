package fr.wakakaaa.listeners;

import fr.wakakaaa.Main;
import fr.wakakaaa.managers.GameManager;
import fr.wakakaaa.utils.TitleUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import fr.wakakaaa.roles.KashimoRole;
import fr.wakakaaa.roles.YoriichRole;
import fr.wakakaaa.roles.Role;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class PlayerDeathListener implements Listener {

    private Main plugin;
    private Set<UUID> processingDeath = new HashSet<>();

    public PlayerDeathListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerDeath(PlayerDeathEvent event) {
        if (plugin.getGameManager().getState() != GameManager.GameState.INGAME) {
            return;
        }

        Player player = event.getEntity();

        if (processingDeath.contains(player.getUniqueId())) {
            event.setDeathMessage(null);
            return;
        }
        processingDeath.add(player.getUniqueId());

        event.setDeathMessage(null);

        String role = "Aucun";
        if (plugin.getRoleManager().hasRole(player)) {
            role = plugin.getRoleManager().getRole(player).getName();
        }

        plugin.getRoleManager().removeRole(player);

        if (player.getKiller() != null) {
            Player killer = player.getKiller();
            plugin.getKillManager().addKill(killer);
            TitleUtils.sendTitle(killer, "§a§lELIMINATION", "§f" + player.getName() + " §7est éliminé !");

            if (plugin.getRoleManager().hasRole(killer)) {
                Role killerRole = plugin.getRoleManager().getRole(killer);
                if (killerRole instanceof KashimoRole) {
                    ((KashimoRole) killerRole).onKill(killer);
                }
                if (killerRole instanceof YoriichRole) {
                    ((YoriichRole) killerRole).onKill(killer);
                }
            }
        }

        Bukkit.broadcastMessage("§c" + player.getName() + " §7(§e" + role + "§7) est éliminé !");

        plugin.getServer().getScheduler().runTaskLater(plugin, new Runnable() {
            @Override
            public void run() {
                processingDeath.remove(player.getUniqueId());
            }
        }, 20L);
    }
}