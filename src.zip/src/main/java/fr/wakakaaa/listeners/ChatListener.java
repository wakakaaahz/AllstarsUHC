package fr.wakakaaa.listeners;

import fr.wakakaaa.Main;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ChatListener implements Listener {

    private Main plugin;

    public ChatListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent event) {
        String prefix = plugin.getRankManager().getPrefix(event.getPlayer());
        event.setFormat(prefix + "§f" + event.getPlayer().getName() + " §8» §f%2$s");
    }
}