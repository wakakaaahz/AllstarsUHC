package fr.wakakaaa.listeners;

import fr.wakakaaa.Main;
import fr.wakakaaa.roles.KokushiboRole;
import fr.wakakaaa.roles.Role;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class KokushiboListener implements Listener {

    private Main plugin;

    public KokushiboListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player)) return;
        if (!(event.getEntity() instanceof Player)) return;
        if (event.isCancelled()) return;

        Player attacker = (Player) event.getDamager();
        Player victim = (Player) event.getEntity();

        if (!plugin.getRoleManager().hasRole(attacker)) return;
        Role role = plugin.getRoleManager().getRole(attacker);
        if (!(role instanceof KokushiboRole)) return;

        KokushiboRole kokushibo = (KokushiboRole) role;

        ItemStack item = attacker.getItemInHand();
        if (!kokushibo.isKokushiboSword(item)) return;

        kokushibo.onHit(attacker, victim);
    }

    // FIX: annuler les dégâts de chute pour les joueurs lancés par le Miroir
    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        if (event.getCause() != EntityDamageEvent.DamageCause.FALL) return;

        Player player = (Player) event.getEntity();

        // Chercher si un Kokushibo a lancé ce joueur
        for (Player p : org.bukkit.Bukkit.getOnlinePlayers()) {
            if (!plugin.getRoleManager().hasRole(p)) continue;
            Role role = plugin.getRoleManager().getRole(p);
            if (!(role instanceof KokushiboRole)) continue;
            if (((KokushiboRole) role).isMiroirLaunched(player)) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getItemInHand();

        if (!plugin.getRoleManager().hasRole(player)) return;
        Role role = plugin.getRoleManager().getRole(player);
        if (!(role instanceof KokushiboRole)) return;

        KokushiboRole kokushibo = (KokushiboRole) role;

        if (!kokushibo.isKokushiboStar(item)) return;

        if (event.getAction() == Action.LEFT_CLICK_AIR ||
                event.getAction() == Action.LEFT_CLICK_BLOCK) {
            event.setCancelled(true);
            kokushibo.onStarLeftClick(player);
        }

        if (event.getAction() == Action.RIGHT_CLICK_AIR ||
                event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            event.setCancelled(true);
            kokushibo.onStarRightClick(player);
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getRoleManager().hasRole(player)) return;
        Role role = plugin.getRoleManager().getRole(player);
        if (!(role instanceof KokushiboRole)) return;

        ((KokushiboRole) role).removeRole(player);
    }
}