package fr.wakakaaa.listeners;

import fr.wakakaaa.Main;
import fr.wakakaaa.managers.GameManager;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockFromToEvent;

public class BlockFromToListener implements Listener {

    private Main plugin;

    public BlockFromToListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBlockFromTo(BlockFromToEvent event) {
        // FIX: == au lieu de != , on bloque l'écoulement pendant la partie
        if (plugin.getGameManager().getState() == GameManager.GameState.INGAME) {
            Material type = event.getBlock().getType();
            if (type == Material.WATER || type == Material.STATIONARY_WATER ||
                    type == Material.LAVA || type == Material.STATIONARY_LAVA) {
                event.setCancelled(true);
            }
        }
    }
}