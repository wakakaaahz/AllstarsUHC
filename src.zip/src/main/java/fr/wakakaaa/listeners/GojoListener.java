package fr.wakakaaa.listeners;

import fr.wakakaaa.Main;
import fr.wakakaaa.roles.GojoRole;
import fr.wakakaaa.roles.Role;
import fr.wakakaaa.utils.TitleUtils;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class GojoListener implements Listener {

    private Main plugin;

    public GojoListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        Player victim = (Player) event.getEntity();

        if (!plugin.getRoleManager().hasRole(victim)) return;
        Role role = plugin.getRoleManager().getRole(victim);
        if (!(role instanceof GojoRole)) return;

        GojoRole gojo = (GojoRole) role;

        // Immunité aux projectiles
        if (event.getDamager() instanceof Projectile) {
            event.setCancelled(true);
            return;
        }

        // Passif Infini
        if (event.getDamager() instanceof Player) {
            Player attacker = (Player) event.getDamager();
            double distance = attacker.getLocation().distance(victim.getLocation());

            if (gojo.isInfinityActive(victim) && distance > gojo.getInfinityRadius()) {
                event.setCancelled(true);
                attacker.sendMessage("§7L'Infini a bloqué ton attaque !");
                victim.sendMessage("§7L'Infini a bloqué une attaque !");
                gojo.triggerInfinityEscape(victim);
            }
        }
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getItemInHand();
        if (item == null || item.getType() != Material.NETHER_STAR) return;
        if (!item.hasItemMeta()) return;

        ItemMeta meta = item.getItemMeta();
        if (!meta.hasDisplayName()) return;
        if (!meta.getDisplayName().equals(ChatColor.WHITE + "Illimité")) return;

        if (!plugin.getRoleManager().hasRole(player)) return;
        Role role = plugin.getRoleManager().getRole(player);
        if (!(role instanceof GojoRole)) return;

        GojoRole gojo = (GojoRole) role;

        if (event.getAction() == Action.LEFT_CLICK_AIR ||
                event.getAction() == Action.LEFT_CLICK_BLOCK) {
            event.setCancelled(true);
            gojo.onLeftClick(player);
            // ── NOUVEAU : afficher le sort sélectionné dans l'action bar ──
            TitleUtils.sendActionBar(player, gojo.getSelectedSpellName(player));
        }

        if (event.getAction() == Action.RIGHT_CLICK_AIR ||
                event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            event.setCancelled(true);
            gojo.onRightClick(player);
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getRoleManager().hasRole(player)) return;
        Role role = plugin.getRoleManager().getRole(player);
        if (!(role instanceof GojoRole)) return;

        GojoRole gojo = (GojoRole) role;
        gojo.removeRole(player);
    }
}