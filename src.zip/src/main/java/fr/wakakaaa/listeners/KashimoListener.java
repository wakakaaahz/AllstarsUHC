package fr.wakakaaa.listeners;

import fr.wakakaaa.Main;
import fr.wakakaaa.roles.KashimoRole;
import fr.wakakaaa.roles.Role;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.event.block.Action;

public class KashimoListener implements Listener {

    private Main plugin;

    public KashimoListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR &&
                event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        ItemStack item = player.getItemInHand();
        if (item == null || item.getType() == Material.AIR) return;
        if (!item.hasItemMeta()) return;

        ItemMeta meta = item.getItemMeta();
        if (!meta.hasDisplayName()) return;

        if (!plugin.getRoleManager().hasRole(player)) return;
        Role role = plugin.getRoleManager().getRole(player);
        if (!(role instanceof KashimoRole)) return;

        KashimoRole kashimo = (KashimoRole) role;

        if (item.getType() == Material.DIAMOND_SWORD &&
                meta.getDisplayName().equals(ChatColor.YELLOW + "Bâton Nyoi")) {
            event.setCancelled(true);
            kashimo.onBatonRightClick(player);
        }

        if (item.getType() == Material.NETHER_STAR &&
                meta.getDisplayName().equals(ChatColor.YELLOW + "Électrification")) {
            event.setCancelled(true);
            kashimo.onElectrificationRightClick(player);
        }
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player)) return;
        if (!(event.getEntity() instanceof Player)) return;
        if (event.isCancelled()) return;

        Player attacker = (Player) event.getDamager();

        if (!plugin.getRoleManager().hasRole(attacker)) return;
        Role role = plugin.getRoleManager().getRole(attacker);
        if (!(role instanceof KashimoRole)) return;

        ItemStack item = attacker.getItemInHand();
        if (item == null || item.getType() != Material.DIAMOND_SWORD) return;
        if (!item.hasItemMeta()) return;
        ItemMeta meta = item.getItemMeta();
        if (!meta.hasDisplayName()) return;
        if (!meta.getDisplayName().equals(ChatColor.YELLOW + "Bâton Nyoi")) return;

        ((KashimoRole) role).onHit(attacker);
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        Player player = (Player) event.getEntity();

        if (event.getCause() == EntityDamageEvent.DamageCause.FIRE ||
                event.getCause() == EntityDamageEvent.DamageCause.FIRE_TICK) {

            if (!plugin.getRoleManager().hasRole(player)) return;
            Role role = plugin.getRoleManager().getRole(player);
            if (role instanceof KashimoRole) return;

            for (Role r : getRolesInGame()) {
                if (r instanceof KashimoRole) {
                    KashimoRole kashimo = (KashimoRole) r;
                    if (kashimo.isTrailFireImmune(player)) {
                        player.setFireTicks(player.getFireTicks());
                        return;
                    }
                }
            }
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getRoleManager().hasRole(player)) return;
        Role role = plugin.getRoleManager().getRole(player);
        if (!(role instanceof KashimoRole)) return;

        ((KashimoRole) role).removeRole(player);
    }

    private java.util.List<Role> getRolesInGame() {
        java.util.List<Role> roles = new java.util.ArrayList<>();
        for (org.bukkit.entity.Player p : org.bukkit.Bukkit.getOnlinePlayers()) {
            if (plugin.getRoleManager().hasRole(p)) {
                roles.add(plugin.getRoleManager().getRole(p));
            }
        }
        return roles;
    }
}