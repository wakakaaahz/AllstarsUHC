package fr.wakakaaa.listeners;

import fr.wakakaaa.Main;
import fr.wakakaaa.roles.Role;
import fr.wakakaaa.roles.SunrakuRole;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class SunrakuListener implements Listener {

    private final Main plugin;

    public SunrakuListener(Main plugin) {
        this.plugin = plugin;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Passif – Immunité chute
    // ════════════════════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onEntityDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        Player player = (Player) event.getEntity();
        if (event.isCancelled()) return;

        if (event.getCause() != EntityDamageEvent.DamageCause.FALL) return;

        if (!plugin.getRoleManager().hasRole(player)) return;
        Role role = plugin.getRoleManager().getRole(player);
        if (!(role instanceof SunrakuRole)) return;

        event.setCancelled(true);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Parade Parfaite – détection du bloc entrant
    // ════════════════════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGH)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (event.isCancelled()) return;

        // ── Cas 1 : Sunraku reçoit un coup → vérifier parade ──────────────
        if (event.getEntity() instanceof Player) {
            Player victim = (Player) event.getEntity();
            if (plugin.getRoleManager().hasRole(victim)) {
                Role role = plugin.getRoleManager().getRole(victim);
                if (role instanceof SunrakuRole) {
                    SunrakuRole sunraku = (SunrakuRole) role;
                    boolean parried = sunraku.tryParade(victim);
                    if (parried) {
                        event.setCancelled(true);
                        return;
                    }
                }
            }
        }

        // ── Cas 2 : Sunraku frappe quelqu'un ──────────────────────────────
        if (!(event.getDamager() instanceof Player)) return;
        if (!(event.getEntity() instanceof Player)) return;

        Player attacker = (Player) event.getDamager();
        Player victim   = (Player) event.getEntity();

        if (!plugin.getRoleManager().hasRole(attacker)) return;
        Role role = plugin.getRoleManager().getRole(attacker);
        if (!(role instanceof SunrakuRole)) return;

        SunrakuRole sunrakuRole = (SunrakuRole) role;
        ItemStack held = attacker.getItemInHand();

        boolean isGoldsheen   = sunrakuRole.isGoldsheenItem(held);
        boolean isNetherlight = sunrakuRole.isNetherightItem(held);
        boolean isPaleSheen   = sunrakuRole.isPaleSheenItem(held);

        if (!isGoldsheen && !isNetherlight && !isPaleSheen) return;

        // Détecter coup critique (1.8) : en l'air + pas sprinting + vitesse verticale négative
        boolean isCrit = !attacker.isOnGround()
                && attacker.getFallDistance() > 0
                && !attacker.hasPotionEffect(org.bukkit.potion.PotionEffectType.BLINDNESS);

        // Appliquer multiplicateur de parade si actif
        double mult = sunrakuRole.getParadeMultiplier(attacker);
        if (mult != 1.0) {
            event.setDamage(event.getDamage() * mult);
        }

        // Notifier le rôle
        sunrakuRole.onHit(attacker, victim, isCrit, isGoldsheen || isPaleSheen, isNetherlight || isPaleSheen);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Clic droit – Gravity Zero + début de parade
    // ════════════════════════════════════════════════════════════════════════

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getRoleManager().hasRole(player)) return;
        Role role = plugin.getRoleManager().getRole(player);
        if (!(role instanceof SunrakuRole)) return;

        SunrakuRole sunrakuRole = (SunrakuRole) role;
        ItemStack item = player.getItemInHand();
        if (item == null) return;

        org.bukkit.event.block.Action action = event.getAction();

        // ── Gravity Zero : clic droit sur l'étoile du nether ──────────────
        if ((action == org.bukkit.event.block.Action.RIGHT_CLICK_AIR
                || action == org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK)
                && sunrakuRole.isGravityZeroItem(item)) {
            event.setCancelled(true);
            sunrakuRole.triggerGravityZero(player);
            return;
        }

        // ── Parade : clic droit avec une épée → enregistrer timestamp ──────
        if ((action == org.bukkit.event.block.Action.RIGHT_CLICK_AIR
                || action == org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK)
                && (sunrakuRole.isGoldsheenItem(item)
                || sunrakuRole.isNetherightItem(item)
                || sunrakuRole.isPaleSheenItem(item))) {
            sunrakuRole.onStartBlock(player);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Changement d'item en main → mettre à jour l'action bar immédiatement
    // ════════════════════════════════════════════════════════════════════════

    @EventHandler
    public void onItemHeld(PlayerItemHeldEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getRoleManager().hasRole(player)) return;
        Role role = plugin.getRoleManager().getRole(player);
        if (!(role instanceof SunrakuRole)) return;

        SunrakuRole sunrakuRole = (SunrakuRole) role;
        // Forcer une mise à jour immédiate
        plugin.getServer().getScheduler().runTaskLater(plugin,
                () -> sunrakuRole.updateActionBarNow(player), 1L);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Cleanup au déco
    // ════════════════════════════════════════════════════════════════════════

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getRoleManager().hasRole(player)) return;
        Role role = plugin.getRoleManager().getRole(player);
        if (!(role instanceof SunrakuRole)) return;

        ((SunrakuRole) role).removeRole(player);
    }
}