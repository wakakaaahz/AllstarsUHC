package fr.wakakaaa.listeners;

import fr.wakakaaa.Main;
import fr.wakakaaa.managers.GameManager;
import fr.wakakaaa.roles.Role;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerRespawnEvent;

public class PlayerRespawnListener implements Listener {

    private Main plugin;

    public PlayerRespawnListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        if (plugin.getGameManager().getState() != GameManager.GameState.INGAME) {
            return;
        }

        // Forcer le spawn au centre (0, Y, 0) pour éviter le hors-bordure
        Player player = event.getPlayer();
        World world = player.getWorld();
        Location center = new Location(world, 0.5, world.getHighestBlockYAt(0, 0) + 1, 0.5);
        event.setRespawnLocation(center);

        if (plugin.getRoleManager().isPendingRevive(player)) {
            Role lastRole = plugin.getRoleManager().getLastRole(player);
            plugin.getRoleManager().clearLastRole(player);

            plugin.getServer().getScheduler().runTaskLater(plugin, new Runnable() {
                @Override
                public void run() {
                    if (!player.isOnline()) return;
                    player.setGameMode(GameMode.SURVIVAL);
                    plugin.getRoleManager().assignRole(player, lastRole);
                    player.setHealth(player.getMaxHealth());
                    player.setFoodLevel(20);
                    player.setSaturation(20);
                    player.sendMessage("§aTu as été revivifié avec ton rôle §6" + lastRole.getName() + " §a!");
                }
            }, 2L);
        } else {
            plugin.getServer().getScheduler().runTaskLater(plugin, new Runnable() {
                @Override
                public void run() {
                    if (!player.isOnline()) return;
                    player.setGameMode(GameMode.SPECTATOR);
                    player.sendMessage("§cTu es éliminé ! Tu es maintenant spectateur.");
                }
            }, 2L);
        }
    }
}