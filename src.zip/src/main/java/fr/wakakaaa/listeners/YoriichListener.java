package fr.wakakaaa.listeners;

import fr.wakakaaa.Main;
import fr.wakakaaa.roles.Role;
import fr.wakakaaa.roles.YoriichRole;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class YoriichListener implements Listener {

    private Main plugin;

    public YoriichListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player)) return;
        if (!(event.getEntity() instanceof Player)) return;
        if (event.isCancelled()) return;

        Player attacker = (Player) event.getDamager();
        Player victim = (Player) event.getEntity();

        if (!plugin.getRoleManager().hasRole(attacker)) return;
        Role role = plugin.getRoleManager().getRole(attacker);
        if (!(role instanceof YoriichRole)) return;

        YoriichRole yoriich = (YoriichRole) role;
        ItemStack item = attacker.getItemInHand();

        // ── FIX : les messages de debug ont été supprimés ──
        if (!yoriich.isNichirinSword(item)) return;

        yoriich.onHit(attacker, victim);
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getItemInHand();

        if (!plugin.getRoleManager().hasRole(player)) return;
        Role role = plugin.getRoleManager().getRole(player);
        if (!(role instanceof YoriichRole)) return;

        YoriichRole yoriich = (YoriichRole) role;

        if (yoriich.isDanseDragonItem(item)) {
            if (event.getAction() == Action.RIGHT_CLICK_AIR ||
                    event.getAction() == Action.RIGHT_CLICK_BLOCK) {
                event.setCancelled(true);
                yoriich.onDanseDragon(player);
            }
        }
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();
        if (killer == null) return;
        if (!plugin.getRoleManager().hasRole(killer)) return;
        Role role = plugin.getRoleManager().getRole(killer);
        if (!(role instanceof YoriichRole)) return;
        ((YoriichRole) role).onKill(killer);
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getRoleManager().hasRole(player)) return;
        Role role = plugin.getRoleManager().getRole(player);
        if (!(role instanceof YoriichRole)) return;
        ((YoriichRole) role).removeRole(player);
    }
}