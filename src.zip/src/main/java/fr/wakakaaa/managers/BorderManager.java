package fr.wakakaaa.managers;

import fr.wakakaaa.Main;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public class BorderManager {

    private Main plugin;
    private int borderSize;
    private int centerX = 0;
    private int centerZ = 0;

    public BorderManager(Main plugin) {
        this.plugin = plugin;
        this.borderSize = 1000;
    }

    public void startBorder() {
        // Dégâts si hors bordure
        Bukkit.getScheduler().runTaskTimer(plugin, new Runnable() {
            @Override
            public void run() {
                if (plugin.getGameManager().getState() != GameManager.GameState.INGAME) {
                    return;
                }
                for (Player player : Bukkit.getOnlinePlayers()) {
                    if (isOutsideBorder(player)) {
                        player.damage(2.0);
                        player.sendMessage("§cTu es hors de la bordure !");
                    }
                }
            }
        }, 0L, 20L);

        // Réduction de la bordure toutes les 5 minutes
        Bukkit.getScheduler().runTaskTimer(plugin, new Runnable() {
            @Override
            public void run() {
                if (plugin.getGameManager().getState() != GameManager.GameState.INGAME) {
                    return;
                }
                reduceBorder(100);
            }
        }, 0L, 20L * 60 * 5);
    }

    public void reduceBorder(int amount) {
        borderSize = Math.max(50, borderSize - amount);
        Bukkit.broadcastMessage("§6La bordure se réduit ! Nouvelle taille: §e" + borderSize + " blocs");
    }

    public boolean isOutsideBorder(Player player) {
        Location loc = player.getLocation();
        int halfSize = borderSize / 2;
        return Math.abs(loc.getX() - centerX) > halfSize ||
                Math.abs(loc.getZ() - centerZ) > halfSize;
    }

    public void resetBorder() {
        borderSize = 1000;
    }

    public int getBorderSize() {
        return borderSize;
    }
}