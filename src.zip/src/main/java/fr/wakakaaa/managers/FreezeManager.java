package fr.wakakaaa.managers;

import fr.wakakaaa.Main;
import org.bukkit.entity.Player;
import java.util.HashSet;
import java.util.UUID;

public class FreezeManager {

    private Main plugin;
    private HashSet<UUID> frozenPlayers;

    public FreezeManager(Main plugin) {
        this.plugin = plugin;
        this.frozenPlayers = new HashSet<>();
    }

    public void freeze(Player player) {
        frozenPlayers.add(player.getUniqueId());
    }

    public void unfreeze(Player player) {
        frozenPlayers.remove(player.getUniqueId());
    }

    public boolean isFrozen(Player player) {
        return frozenPlayers.contains(player.getUniqueId());
    }
}