package fr.wakakaaa.managers;

import org.bukkit.inventory.ItemStack;

public class KitManager {

    private ItemStack[] kitContents;
    private ItemStack[] kitArmor;

    public KitManager() {
        this.kitContents = new ItemStack[36];
        this.kitArmor = new ItemStack[4];
    }

    public void saveKit(ItemStack[] contents, ItemStack[] armor) {
        this.kitContents = contents;
        this.kitArmor = armor;
    }

    public ItemStack[] getKitContents() {
        return kitContents;
    }

    public ItemStack[] getKitArmor() {
        return kitArmor;
    }

    public boolean hasKit() {
        for (ItemStack item : kitContents) {
            if (item != null) return true;
        }
        return false;
    }
}