package fr.wakakaaa.managers;

import org.bukkit.entity.Player;
import java.util.HashMap;
import java.util.UUID;

public class KillManager {

    private HashMap<UUID, Integer> kills;

    public KillManager() {
        this.kills = new HashMap<>();
    }

    public void addKill(Player player) {
        kills.put(player.getUniqueId(), getKills(player) + 1);
    }

    public int getKills(Player player) {
        return kills.getOrDefault(player.getUniqueId(), 0);
    }

    public void resetKills(Player player) {
        kills.put(player.getUniqueId(), 0);
    }

    public void clearKills() {
        kills.clear();
    }
}