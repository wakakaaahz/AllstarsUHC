package fr.wakakaaa.managers;

import fr.wakakaaa.Main;
import fr.wakakaaa.utils.TitleUtils;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

public class ScoreboardManager {

    private Main plugin;
    private int gameTimer = 0;

    public ScoreboardManager(Main plugin) {
        this.plugin = plugin;
        startUpdater();
    }

    public void incrementTimer() { gameTimer++; }
    public void resetTimer() { gameTimer = 0; }

    public String getFormattedTimer() {
        int minutes = gameTimer / 60;
        int seconds = gameTimer % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }

    public void updateScoreboard(Player player) {
        Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective objective = board.registerNewObjective("uhc", "dummy");
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);
        objective.setDisplayName(ChatColor.GOLD + "§lEmpire Omertant");

        int score = 10;
        int joueurs = Bukkit.getOnlinePlayers().size();
        int kills = plugin.getKillManager().getKills(player);

        String role = "Aucun";
        if (plugin.getRoleManager().hasRole(player)) {
            role = plugin.getRoleManager().getRole(player).getName();
        }

        int distanceAuCentre = (int) Math.sqrt(
                Math.pow(player.getLocation().getX(), 2) +
                        Math.pow(player.getLocation().getZ(), 2)
        );

        String grade = plugin.getRankManager().getPrefix(player).trim();

        objective.getScore(ChatColor.YELLOW + "§lInformations").setScore(score--);
        objective.getScore(ChatColor.GRAY + "• Grade: " + grade).setScore(score--);
        objective.getScore(ChatColor.GRAY + "• Rôle: " + ChatColor.WHITE + role).setScore(score--);
        objective.getScore(ChatColor.GRAY + "• Joueurs: " + ChatColor.WHITE + joueurs).setScore(score--);
        objective.getScore(ChatColor.GRAY + "• Kills: " + ChatColor.WHITE + kills).setScore(score--);
        objective.getScore(" ").setScore(score--);
        objective.getScore(ChatColor.YELLOW + "§lDurée").setScore(score--);
        objective.getScore(ChatColor.GRAY + "• Timer: " + ChatColor.WHITE + getFormattedTimer()).setScore(score--);
        objective.getScore(ChatColor.GRAY + "• Centre: " + ChatColor.WHITE + distanceAuCentre + " blocs").setScore(score--);
        objective.getScore(ChatColor.GRAY + "• Bordure: " + ChatColor.WHITE + plugin.getBorderManager().getBorderSize() + " blocs").setScore(score--);
        objective.getScore("  ").setScore(score--);
        objective.getScore(ChatColor.GOLD + "discord.gg/N7Fjj59es7").setScore(score--);

        // ── FIX : on passe le joueur pour que applyTeamsToBoard puisse
        // appliquer les teams Tengen (tng_) si ce joueur est Tengen ──
        plugin.getCampManager().applyTeamsToBoard(board, player);

        player.setScoreboard(board);

        String header = "\\n§6§lEmpire Omertant\\n§7Mode de Jeu » §fOnePiece UHC\\n";
        String footer = "\\n§7discord.gg/N7Fjj59es7\\n";
        TitleUtils.sendTabHeaderFooter(player, header, footer);
    }

    private void startUpdater() {
        Bukkit.getScheduler().runTaskTimer(plugin, new Runnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    updateScoreboard(player);
                }
            }
        }, 0L, 20L);
    }

    public void removeScoreboard(Player player) {
        player.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
    }
}