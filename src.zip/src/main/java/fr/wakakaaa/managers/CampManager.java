package fr.wakakaaa.managers;

import fr.wakakaaa.Main;
import fr.wakakaaa.roles.Role;
import fr.wakakaaa.roles.GojoRole;
import fr.wakakaaa.roles.KokushiboRole;
import fr.wakakaaa.roles.KashimoRole;
import fr.wakakaaa.roles.StainRole;
import fr.wakakaaa.roles.YoriichRole;
import fr.wakakaaa.roles.SunrakuRole;
import fr.wakakaaa.roles.TengenRole;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

public class CampManager {

    public enum Camp {
        PROTAGONISTE("Protagoniste", ChatColor.GREEN),
        ANTAGONISTE("Antagoniste", ChatColor.RED),
        DIVERGENT("Divergent", ChatColor.YELLOW),
        SOLO("Solo", ChatColor.GOLD),
        AUCUN("Aucun", ChatColor.WHITE);

        private final String name;
        private final ChatColor color;

        Camp(String name, ChatColor color) {
            this.name = name;
            this.color = color;
        }

        public String getName() { return name; }
        public ChatColor getColor() { return color; }
    }

    private Main plugin;

    public CampManager(Main plugin) {
        this.plugin = plugin;
    }

    public Camp getCamp(Role role) {
        if (role instanceof GojoRole) return Camp.PROTAGONISTE;
        if (role instanceof KokushiboRole) return Camp.ANTAGONISTE;
        if (role instanceof KashimoRole) return Camp.DIVERGENT;
        if (role instanceof StainRole) return Camp.DIVERGENT;
        if (role instanceof YoriichRole) return Camp.SOLO;
        if (role instanceof SunrakuRole) return Camp.PROTAGONISTE;
        if (role instanceof TengenRole) return Camp.PROTAGONISTE;
        return Camp.AUCUN;
    }

    public Camp getPlayerCamp(Player player) {
        if (!plugin.getRoleManager().hasRole(player)) return Camp.AUCUN;
        return getCamp(plugin.getRoleManager().getRole(player));
    }

    public void updateAllPlayers() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            updatePlayer(player);
        }
    }

    public void updatePlayer(Player player) {
        Camp camp = getPlayerCamp(player);
        ChatColor color = camp.getColor();
        String roleName = plugin.getRoleManager().hasRole(player)
                ? plugin.getRoleManager().getRole(player).getName()
                : null;

        for (Player other : Bukkit.getOnlinePlayers()) {
            Scoreboard board = other.getScoreboard();
            if (board == null) continue;

            String teamName = "camp_" + player.getName().substring(0, Math.min(player.getName().length(), 10));
            try {
                Team team = board.getTeam(teamName);
                if (team == null) team = board.registerNewTeam(teamName);
                team.setPrefix(color.toString());
                team.setSuffix("");
                if (!team.hasEntry(player.getName())) team.addEntry(player.getName());
            } catch (Exception e) { /* ignore */ }

            if (roleName != null) {
                player.setPlayerListName(color + roleName + " §7| " + color + player.getName());
            } else {
                player.setPlayerListName(ChatColor.WHITE + player.getName());
            }
        }
    }

    // ── Ancienne signature gardée pour compatibilité ──
    public void applyTeamsToBoard(Scoreboard board) {
        applyTeamsToBoard(board, null);
    }

    // ── Nouvelle signature : reçoit le joueur destinataire du scoreboard ──
    // Si ce joueur est Tengen, on applique aussi les teams tng_ avec les
    // couleurs de vie pour la Partition Musicale.
    public void applyTeamsToBoard(Scoreboard board, Player boardOwner) {
        Player stainPlayer = null;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (plugin.getRoleManager().hasRole(p) &&
                    plugin.getRoleManager().getRole(p) instanceof StainRole) {
                stainPlayer = p;
                break;
            }
        }

        for (Player p : Bukkit.getOnlinePlayers()) {
            Camp camp = getPlayerCamp(p);
            ChatColor color = camp.getColor();
            String roleName = plugin.getRoleManager().hasRole(p)
                    ? plugin.getRoleManager().getRole(p).getName()
                    : null;

            String teamName = "camp_" + p.getName().substring(0, Math.min(p.getName().length(), 10));
            try {
                Team team = board.getTeam(teamName);
                if (team == null) team = board.registerNewTeam(teamName);
                team.setPrefix(color.toString());
                team.setSuffix("");
                if (!team.hasEntry(p.getName())) team.addEntry(p.getName());
            } catch (Exception e) { /* ignore */ }

            if (roleName != null) {
                p.setPlayerListName(color + roleName + " §7| " + color + p.getName());
            } else {
                p.setPlayerListName(ChatColor.WHITE + p.getName());
            }
        }

        // ── Blood tags pour Stain ──
        if (stainPlayer != null) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.equals(stainPlayer)) continue;
                String group = StainRole.getBloodGroup(p);
                String bloodColor;
                switch (group) {
                    case "A":  bloodColor = "§a"; break;
                    case "AB": bloodColor = "§5"; break;
                    case "B":  bloodColor = "§9"; break;
                    default:   bloodColor = "§f"; break;
                }
                String campTeamName = "camp_" + p.getName().substring(0, Math.min(p.getName().length(), 10));
                try {
                    Team team = board.getTeam(campTeamName);
                    if (team == null) team = board.registerNewTeam(campTeamName);
                    ChatColor campColor = getPlayerCamp(p).getColor();
                    team.setPrefix(bloodColor + "[" + group + "] " + campColor);
                } catch (Exception e) { /* ignore */ }
            }
        }

        // ── FIX Partition Musicale : si le destinataire est Tengen,
        // on applique les teams tng_ avec les couleurs de vie.
        // Ces teams écrasent le prefix camp_ uniquement pour Tengen,
        // les autres joueurs gardent leurs couleurs de camp normales. ──
        if (boardOwner != null
                && plugin.getRoleManager().hasRole(boardOwner)
                && plugin.getRoleManager().getRole(boardOwner) instanceof TengenRole) {

            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.equals(boardOwner)) continue;

                double ratio = p.getHealth() / p.getMaxHealth();
                ChatColor lifeColor;
                if (ratio >= 0.5)       lifeColor = ChatColor.GREEN;
                else if (ratio >= 0.25) lifeColor = ChatColor.GOLD;
                else                    lifeColor = ChatColor.RED;

                // On réutilise la team camp_ existante et on change juste le prefix
                // pour Tengen — pas besoin d'une team séparée tng_
                String teamName = "camp_" + p.getName().substring(0, Math.min(p.getName().length(), 10));
                try {
                    Team team = board.getTeam(teamName);
                    if (team == null) team = board.registerNewTeam(teamName);
                    team.setPrefix(lifeColor.toString());
                } catch (Exception e) { /* ignore */ }
            }
        }
    }
}