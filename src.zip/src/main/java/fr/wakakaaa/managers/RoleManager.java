package fr.wakakaaa.managers;

import fr.wakakaaa.Main;
import fr.wakakaaa.roles.LuffyRole;
import fr.wakakaaa.roles.Role;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import fr.wakakaaa.roles.KashimoRole;
import fr.wakakaaa.roles.GojoRole;
import fr.wakakaaa.roles.KokushiboRole;
import fr.wakakaaa.roles.StainRole;
import fr.wakakaaa.roles.YoriichRole;
import fr.wakakaaa.roles.SunrakuRole;
import fr.wakakaaa.roles.TengenRole;

public class RoleManager {

    private Main plugin;
    private HashMap<UUID, Role> playerRoles;
    private List<Role> availableRoles;
    // Stocke le dernier rôle avant la mort
    private HashMap<UUID, Role> lastRoles = new HashMap<>();
    // Joueurs en attente de revive (activé uniquement par /revive)
    private Set<UUID> pendingRevive = new HashSet<>();

    public RoleManager(Main plugin) {
        this.plugin = plugin;
        this.playerRoles = new HashMap<>();
        this.availableRoles = new ArrayList<>();
        loadRoles();
    }

    private void loadRoles() {
        availableRoles.add(new LuffyRole());
        availableRoles.add(new KashimoRole());
        availableRoles.add(new GojoRole());
        availableRoles.add(new KokushiboRole());
        availableRoles.add(new YoriichRole());
        availableRoles.add(new StainRole());
        availableRoles.add(new SunrakuRole(plugin));
        availableRoles.add(new TengenRole(plugin));
    }

    public void distributeRoles(List<Player> players) {
        List<Role> shuffledRoles = new ArrayList<>(availableRoles);
        Collections.shuffle(shuffledRoles);
        List<Role> roles = new ArrayList<>();
        int index = 0;
        for (int i = 0; i < players.size(); i++) {
            roles.add(shuffledRoles.get(index));
            index++;
            if (index >= shuffledRoles.size()) index = 0;
        }
        for (int i = 0; i < players.size(); i++) {
            assignRole(players.get(i), roles.get(i));
        }
    }

    public void assignRole(Player player, Role role) {
        playerRoles.put(player.getUniqueId(), role);
        role.applyRole(player);
        plugin.getScoreboardManager().updateScoreboard(player);
        // Mettre à jour les camps pour tous les joueurs
        plugin.getCampManager().updateAllPlayers();
    }

    public void assignLuffy(Player player) {
        assignRole(player, new LuffyRole());
    }

    public Role getRole(Player player) {
        return playerRoles.get(player.getUniqueId());
    }

    public boolean hasRole(Player player) {
        return playerRoles.containsKey(player.getUniqueId());
    }

    public void removeRole(Player player) {
        Role role = playerRoles.get(player.getUniqueId());
        if (role != null) {
            // Toujours sauvegarder le dernier rôle
            lastRoles.put(player.getUniqueId(), role);
            role.removeRole(player);
        }
        playerRoles.remove(player.getUniqueId());
    }

    // Appelé par /revive pour marquer le joueur comme en attente de revive
    public void markForRevive(Player player) {
        pendingRevive.add(player.getUniqueId());
    }

    // Vérifie si le joueur est en attente de revive (activé par /revive)
    public boolean isPendingRevive(Player player) {
        return pendingRevive.contains(player.getUniqueId());
    }

    public boolean hasLastRole(Player player) {
        return lastRoles.containsKey(player.getUniqueId());
    }

    public Role getLastRole(Player player) {
        return lastRoles.get(player.getUniqueId());
    }

    public void clearLastRole(Player player) {
        lastRoles.remove(player.getUniqueId());
        pendingRevive.remove(player.getUniqueId());
    }

    public void clearRoles() {
        for (UUID uuid : playerRoles.keySet()) {
            Player player = plugin.getServer().getPlayer(uuid);
            if (player != null) {
                playerRoles.get(uuid).removeRole(player);
            }
        }
        playerRoles.clear();
        lastRoles.clear();
        pendingRevive.clear();
    }
}