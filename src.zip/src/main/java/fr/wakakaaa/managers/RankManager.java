package fr.wakakaaa.managers;

import org.bukkit.entity.Player;
import java.util.HashMap;
import java.util.UUID;

public class RankManager {

    public enum Rank {
        OWNER("§4[Owner] ", true),
        ADMIN("§c[Admin] ", true),
        MODERATOR("§6[Modo] ", true),
        PLAYER("§7[Player]", false);

        private String prefix;
        private boolean isStaff;

        Rank(String prefix, boolean isStaff) {
            this.prefix = prefix;
            this.isStaff = isStaff;
        }

        public String getPrefix() {
            return prefix;
        }

        public boolean isStaff() {
            return isStaff;
        }
    }

    private HashMap<UUID, Rank> playerRanks;
    private HashMap<String, UUID> ownerList;

    public RankManager() {
        this.playerRanks = new HashMap<>();
        this.ownerList = new HashMap<>();
    }

    public void setRank(Player player, Rank rank) {
        playerRanks.put(player.getUniqueId(), rank);
        if (rank == Rank.OWNER || rank == Rank.ADMIN) {
            player.setOp(true);
        } else {
            player.setOp(false);
        }
    }

    public Rank getRank(Player player) {
        return playerRanks.getOrDefault(player.getUniqueId(), Rank.PLAYER);
    }

    public boolean hasPermission(Player player, Rank requiredRank) {
        return getRank(player).ordinal() <= requiredRank.ordinal();
    }

    public String getPrefix(Player player) {
        return getRank(player).getPrefix();
    }
}