package fr.wakakaaa.managers;

import fr.wakakaaa.Main;
import fr.wakakaaa.roles.StainRole;
import fr.wakakaaa.utils.TitleUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;

import java.util.ArrayList;
import java.util.List;

public class GameManager {

    private Main plugin;
    private GameState state;

    public GameManager(Main plugin) {
        this.plugin = plugin;
        this.state = GameState.WAITING;

        Bukkit.getScheduler().runTaskTimer(plugin, new Runnable() {
            @Override
            public void run() {
                if (state == GameState.INGAME) {
                    plugin.getScoreboardManager().incrementTimer();
                }
            }
        }, 0L, 20L);
    }

    public void startGame() {
        if (state != GameState.WAITING && state != GameState.STARTING) {
            Bukkit.broadcastMessage("§cUne partie est déjà en cours !");
            return;
        }
        if (state == GameState.WAITING) {
            state = GameState.STARTING;
            Bukkit.broadcastMessage("§6La partie va commencer !");
            plugin.getTimerManager().startCountdown();
            return;
        }
        if (state == GameState.STARTING) {
            state = GameState.INGAME;
            Bukkit.broadcastMessage("§aLa partie a commencé !");

            List<Player> players = new ArrayList<>(Bukkit.getOnlinePlayers());

            for (Player player : players) {
                TitleUtils.sendTitle(player, "§6§lLA PARTIE COMMENCE", "§eBonne chance à tous !");
                giveStarterKit(player);
            }

            // Distribuer les groupes sanguins AVANT les rôles
            StainRole.distributeBloodGroups(players);

            plugin.getRoleManager().distributeRoles(players);
            plugin.getBorderManager().startBorder();
        }
    }

    public void stopGame() {
        if (state == GameState.WAITING) {
            Bukkit.broadcastMessage("§cAucune partie en cours !");
            return;
        }
        state = GameState.WAITING;
        plugin.getTimerManager().stopTimer();
        plugin.getRoleManager().clearRoles();
        plugin.getKillManager().clearKills();
        plugin.getScoreboardManager().resetTimer();
        plugin.getBorderManager().resetBorder();
        Bukkit.broadcastMessage("§cLa partie a été arrêtée !");
    }

    private void giveStarterKit(Player player) {
        player.getInventory().clear();
        if (plugin.getKitManager().hasKit()) {
            player.getInventory().setContents(plugin.getKitManager().getKitContents());
            player.getInventory().setArmorContents(plugin.getKitManager().getKitArmor());
        } else {
            player.sendMessage("§cAucun kit sauvegardé !");
        }
    }

    public GameState getState() {
        return state;
    }

    public void setState(GameState state) {
        this.state = state;
    }

    public enum GameState {
        WAITING,
        STARTING,
        INGAME,
        ENDED
    }
}