package fr.wakakaaa.managers;

import fr.wakakaaa.Main;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;

public class TimerManager {

    private Main plugin;
    private BukkitTask task;
    private int countdown;

    public TimerManager(Main plugin) {
        this.plugin = plugin;
        this.countdown = 15;
    }

    public void startCountdown() {
        countdown = 15;
        task = Bukkit.getScheduler().runTaskTimer(plugin, new Runnable() {
            @Override
            public void run() {
                if (countdown <= 0) {
                    Bukkit.broadcastMessage("§aLa partie commence !");
                    plugin.getGameManager().startGame();
                    stopTimer();
                    return;
                }
                if (countdown <= 10 || countdown % 10 == 0) {
                    Bukkit.broadcastMessage("§eLa partie commence dans §6" + countdown + " §esecondes !");
                }
                countdown--;
            }
        }, 0L, 20L);
    }

    public void stopTimer() {
        if (task != null) {
            task.cancel();
            task = null;
        }
    }

    public int getCountdown() {
        return countdown;
    }
}