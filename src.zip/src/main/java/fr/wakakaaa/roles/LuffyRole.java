package fr.wakakaaa.roles;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class LuffyRole implements Role {

    @Override
    public String getName() {
        return "Luffy";
    }

    @Override
    public String getDescription() {
        return "Résistance aux coups et vitesse augmentée !";
    }

    @Override
    public void applyRole(Player player) {
        player.sendMessage(ChatColor.GOLD + "Tu es " + ChatColor.RED + "Monkey D. Luffy !");
        player.sendMessage(ChatColor.YELLOW + getDescription());
        player.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, Integer.MAX_VALUE, 1));
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1));
    }

    @Override
    public void removeRole(Player player) {
        player.removePotionEffect(PotionEffectType.DAMAGE_RESISTANCE);
        player.removePotionEffect(PotionEffectType.SPEED);
    }

    @Override
    public void onAbility(Player player) {
        player.sendMessage(ChatColor.RED + "Gomu Gomu no Pistol !");
        player.addPotionEffect(new PotionEffect(PotionEffectType.INCREASE_DAMAGE, 60, 2));
    }
}