package fr.wakakaaa.roles;

import fr.wakakaaa.Main;
import org.bukkit.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;

public class KokushiboRole implements Role {

    private Main plugin;
    private Map<UUID, Integer> comboCount = new HashMap<>();
    private Map<UUID, Long> lastHitTime = new HashMap<>();
    private Map<UUID, Long> comboCooldown = new HashMap<>();
    private Map<UUID, Long> luneNoireCooldown = new HashMap<>();
    private Map<UUID, Long> miroirCooldown = new HashMap<>();
    private Map<UUID, Integer> selectedAbility = new HashMap<>(); // 0 = Lune Noire, 1 = Miroir
    private Map<UUID, BukkitTask> speedTimers = new HashMap<>();

    // Passif Crépuscule : joueurs marqués par UUID de Kokushibo
    private Map<UUID, Set<UUID>> markedPlayers = new HashMap<>();
    // FIX: joueurs lancés en l'air par le Miroir, immunisés aux dégâts de chute
    private Set<UUID> miroirLaunched = new HashSet<>();

    public KokushiboRole() {
        this.plugin = Main.getInstance();
    }

    @Override
    public String getName() {
        return "Kokushibo";
    }

    @Override
    public String getDescription() {
        return "Maître des lames lunaires !";
    }

    @Override
    public void applyRole(Player player) {
        player.sendMessage(ChatColor.DARK_PURPLE + "Tu es " + ChatColor.LIGHT_PURPLE + "Kokushibo !");
        player.sendMessage(ChatColor.DARK_PURPLE + getDescription());
        comboCount.put(player.getUniqueId(), 0);
        lastHitTime.put(player.getUniqueId(), 0L);
        comboCooldown.put(player.getUniqueId(), 0L);
        luneNoireCooldown.put(player.getUniqueId(), 0L);
        miroirCooldown.put(player.getUniqueId(), 0L);
        selectedAbility.put(player.getUniqueId(), 0);
        markedPlayers.put(player.getUniqueId(), new HashSet<>());
        giveItems(player);
        startComboResetTimer(player);
    }

    @Override
    public void removeRole(Player player) {
        comboCount.remove(player.getUniqueId());
        lastHitTime.remove(player.getUniqueId());
        comboCooldown.remove(player.getUniqueId());
        luneNoireCooldown.remove(player.getUniqueId());
        miroirCooldown.remove(player.getUniqueId());
        selectedAbility.remove(player.getUniqueId());
        markedPlayers.remove(player.getUniqueId());
        if (speedTimers.containsKey(player.getUniqueId())) {
            speedTimers.get(player.getUniqueId()).cancel();
            speedTimers.remove(player.getUniqueId());
        }
        player.removePotionEffect(PotionEffectType.SPEED);
    }

    @Override
    public void onAbility(Player player) {
    }

    private void giveItems(Player player) {
        // Épée lunaire
        ItemStack sword = new ItemStack(Material.DIAMOND_SWORD);
        ItemMeta swordMeta = sword.getItemMeta();
        swordMeta.setDisplayName(ChatColor.LIGHT_PURPLE + "Lame Lunaire");
        List<String> swordLore = new ArrayList<>();
        swordLore.add(ChatColor.GRAY + "Combo: 0/5");
        swordMeta.setLore(swordLore);
        sword.setItemMeta(swordMeta);
        sword.addEnchantment(Enchantment.DAMAGE_ALL, 3);
        player.getInventory().setItem(0, sword);

        // Nether star pour les capacités
        ItemStack star = new ItemStack(Material.NETHER_STAR);
        ItemMeta starMeta = star.getItemMeta();
        starMeta.setDisplayName(ChatColor.LIGHT_PURPLE + "Lune Noire");
        List<String> starLore = new ArrayList<>();
        starLore.add(ChatColor.GRAY + "Clic-Droit pour utiliser");
        starLore.add(ChatColor.GRAY + "Clic-Gauche pour changer");
        starLore.add(ChatColor.GRAY + "Cooldown: 60s");
        starMeta.setLore(starLore);
        star.setItemMeta(starMeta);
        player.getInventory().setItem(1, star);
    }

    private void refreshSwordLore(Player player) {
        ItemStack item = player.getInventory().getItem(0);
        if (item == null || item.getType() != Material.DIAMOND_SWORD) return;
        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.hasDisplayName()) return;
        if (!meta.getDisplayName().equals(ChatColor.LIGHT_PURPLE + "Lame Lunaire")) return;

        int combo = comboCount.getOrDefault(player.getUniqueId(), 0);

        // Mettre à jour la lore
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "Combo: " + combo + "/5");
        meta.setLore(lore);
        item.setItemMeta(meta);
        player.getInventory().setItem(0, item);

        // Afficher le compteur au dessus de la hotbar via TitleUtils
        StringBuilder bar = new StringBuilder();
        for (int i = 0; i < 5; i++) {
            if (i < combo) {
                bar.append("§d⚔ ");
            } else {
                bar.append("§8⚔ ");
            }
        }
        fr.wakakaaa.utils.TitleUtils.sendActionBar(player, bar.toString().trim() + " §7(" + combo + "/5)");
    }

    private void refreshStarItem(Player player) {
        ItemStack item = player.getInventory().getItem(1);
        if (item == null || item.getType() != Material.NETHER_STAR) return;

        int ability = selectedAbility.getOrDefault(player.getUniqueId(), 0);
        long now = System.currentTimeMillis();
        ItemMeta meta = item.getItemMeta();

        if (ability == 0) {
            meta.setDisplayName(ChatColor.LIGHT_PURPLE + "Lune Noire");
            long cdLeft = Math.max(0, 60000 - (now - luneNoireCooldown.getOrDefault(player.getUniqueId(), 0L))) / 1000;
            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.GRAY + "Clic-Droit pour utiliser");
            lore.add(ChatColor.GRAY + "Clic-Gauche pour changer");
            lore.add(cdLeft > 0 ? ChatColor.RED + "Cooldown: " + cdLeft + "s" : ChatColor.GREEN + "Prêt !");
            meta.setLore(lore);
        } else {
            meta.setDisplayName(ChatColor.LIGHT_PURPLE + "Miroir du Malheur");
            long cdLeft = Math.max(0, 60000 - (now - miroirCooldown.getOrDefault(player.getUniqueId(), 0L))) / 1000;
            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.GRAY + "Clic-Droit pour utiliser");
            lore.add(ChatColor.GRAY + "Clic-Gauche pour changer");
            lore.add(cdLeft > 0 ? ChatColor.RED + "Cooldown: " + cdLeft + "s" : ChatColor.GREEN + "Prêt !");
            meta.setLore(lore);
        }

        item.setItemMeta(meta);
        player.getInventory().setItem(1, item);
    }

    // Démarre un timer qui reset le combo si pas de frappe pendant 2s
    private void startComboResetTimer(Player player) {
        plugin.getServer().getScheduler().runTaskTimer(plugin, new Runnable() {
            @Override
            public void run() {
                if (!player.isOnline()) return;
                long now = System.currentTimeMillis();
                long last = lastHitTime.getOrDefault(player.getUniqueId(), 0L);
                int combo = comboCount.getOrDefault(player.getUniqueId(), 0);
                // Reset si plus de 2s sans frapper et combo > 0
                if (combo > 0 && now - last > 2000) {
                    comboCount.put(player.getUniqueId(), 0);
                    refreshSwordLore(player);
                }
            }
        }, 0L, 5L); // vérifie toutes les 5 ticks
    }

    // Appelé depuis le listener quand Kokushibo frappe avec sa lame
    public void onHit(Player kokushibo, Player victim) {
        long now = System.currentTimeMillis();

        // Vérifier cooldown combo (20s après déclenchement)
        long lastCombo = comboCooldown.getOrDefault(kokushibo.getUniqueId(), 0L);
        if (now - lastCombo < 20000) return;

        lastHitTime.put(kokushibo.getUniqueId(), now);

        int combo = comboCount.getOrDefault(kokushibo.getUniqueId(), 0) + 1;

        if (combo >= 5) {
            // 5e coup : déclencher le croissant de lune
            comboCount.put(kokushibo.getUniqueId(), 0);
            comboCooldown.put(kokushibo.getUniqueId(), now);
            fireCroissantPassif(kokushibo, victim);
            refreshSwordLore(kokushibo);
        } else {
            comboCount.put(kokushibo.getUniqueId(), combo);
            refreshSwordLore(kokushibo);
        }
    }

    private void fireCroissantPassif(Player kokushibo, Player victim) {
        // Inflige 1 coeur (2.0) + Cécité 5s
        victim.damage(2.0, kokushibo);
        victim.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 20 * 5, 0));
        victim.sendMessage(ChatColor.DARK_PURPLE + "Tu as été touché par un croissant de lune !");
        kokushibo.sendMessage(ChatColor.LIGHT_PURPLE + "Croissant de Lune déclenché !");

        // Effet visuel : particules autour de la victime
        Location loc = victim.getLocation();
        for (int i = 0; i < 8; i++) {
            double angle = (2 * Math.PI * i) / 8;
            Location particleLoc = loc.clone().add(Math.cos(angle), 1, Math.sin(angle));
            loc.getWorld().playEffect(particleLoc, Effect.COLOURED_DUST, 10);
        }

        // Passif Crépuscule : marquer la victime
        markPlayer(kokushibo, victim);
    }

    // Passif Crépuscule : marquer un joueur + glowing + vitesse
    private void markPlayer(Player kokushibo, Player victim) {
        Set<UUID> marked = markedPlayers.getOrDefault(kokushibo.getUniqueId(), new HashSet<>());
        if (marked.contains(victim.getUniqueId())) return; // déjà marqué

        marked.add(victim.getUniqueId());
        markedPlayers.put(kokushibo.getUniqueId(), marked);

        // Glowing violet 30s
        victim.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 20 * 30, 0));
        victim.sendMessage(ChatColor.DARK_PURPLE + "Tu es marqué par les lunes de Kokushibo !");

        // Mettre à jour la vitesse de Kokushibo
        updateSpeed(kokushibo);

        // Retirer le marquage après 30s
        plugin.getServer().getScheduler().runTaskLater(plugin, new Runnable() {
            @Override
            public void run() {
                Set<UUID> m = markedPlayers.getOrDefault(kokushibo.getUniqueId(), new HashSet<>());
                m.remove(victim.getUniqueId());
                markedPlayers.put(kokushibo.getUniqueId(), m);
                updateSpeed(kokushibo);
            }
        }, 20L * 30);
    }

    // Met à jour la vitesse de Kokushibo selon le nombre de joueurs marqués
    private void updateSpeed(Player kokushibo) {
        if (!kokushibo.isOnline()) return;
        int marked = markedPlayers.getOrDefault(kokushibo.getUniqueId(), new HashSet<>()).size();
        marked = Math.min(marked, 3); // max 3 joueurs = 30%

        kokushibo.removePotionEffect(PotionEffectType.SPEED);
        if (marked > 0) {
            // Amplifier 0 = 10%, 1 = 20%, 2 = 30%
            kokushibo.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, marked - 1, false, false));
        }
    }

    // Capacité 1 : Lune Noire
    public void castLuneNoire(Player player) {
        long now = System.currentTimeMillis();
        long lastUse = luneNoireCooldown.getOrDefault(player.getUniqueId(), 0L);
        if (now - lastUse < 60000) {
            player.sendMessage(ChatColor.RED + "Cooldown ! Encore " + ((60000 - (now - lastUse)) / 1000) + "s");
            return;
        }
        luneNoireCooldown.put(player.getUniqueId(), now);
        refreshStarItem(player);
        player.sendMessage(ChatColor.LIGHT_PURPLE + "Lune Noire !");

        Location loc = player.getEyeLocation().clone();
        Vector direction = player.getEyeLocation().getDirection().normalize();

        // Rotation du croissant
        final double[] angle = {0};

        BukkitTask[] taskHolder = new BukkitTask[1];
        taskHolder[0] = plugin.getServer().getScheduler().runTaskTimer(plugin, new Runnable() {
            int blocks = 0;
            Set<UUID> alreadyHit = new HashSet<>();

            @Override
            public void run() {
                if (blocks >= 30 || !player.isOnline()) {
                    taskHolder[0].cancel();
                    refreshStarItem(player);
                    return;
                }

                loc.add(direction.clone().multiply(1));
                angle[0] += 30; // rotation de 30 degrés par tick

                // Détruire les blocs sur la trajectoire + rayon de 1
                for (int dx = -1; dx <= 1; dx++) {
                    for (int dy = -1; dy <= 1; dy++) {
                        for (int dz = -1; dz <= 1; dz++) {
                            Location blockLoc = loc.clone().add(dx, dy, dz);
                            Material type = blockLoc.getBlock().getType();
                            if (type != Material.AIR && type != Material.BEDROCK) {
                                blockLoc.getBlock().setType(Material.AIR);
                            }
                        }
                    }
                }

                // Particules qui tournent pour simuler le croissant
                for (int i = 0; i < 6; i++) {
                    double a = Math.toRadians(angle[0] + i * 60);
                    Location pLoc = loc.clone().add(Math.cos(a) * 1.2, Math.sin(a) * 1.2, 0);
                    loc.getWorld().playEffect(pLoc, Effect.COLOURED_DUST, 10);
                }

                // Repousser les joueurs proches
                for (Player nearby : Bukkit.getOnlinePlayers()) {
                    if (!nearby.equals(player) && !alreadyHit.contains(nearby.getUniqueId())
                            && nearby.getLocation().distance(loc) < 2.5) {
                        alreadyHit.add(nearby.getUniqueId());
                        // FIX: dégâts sans réduction d'armure
                        double finalHealth = Math.max(0, nearby.getHealth() - 3.0);
                        nearby.setHealth(finalHealth);
                        nearby.damage(0.001, player); // pour attribuer le kill à Kokushibo
                        // FIX: repousse plus puissant sur 3 ticks pour contourner le cap 1.8.9
                        Player finalNearby = nearby;
                        for (int t = 0; t < 3; t++) {
                            plugin.getServer().getScheduler().runTaskLater(plugin, new Runnable() {
                                @Override
                                public void run() {
                                    if (!finalNearby.isOnline()) return;
                                    Vector repulse = direction.clone().multiply(3.5);
                                    repulse.setY(0.4);
                                    finalNearby.setVelocity(repulse);
                                }
                            }, t);
                        }
                        nearby.sendMessage(ChatColor.DARK_PURPLE + "Tu as été touché par la Lune Noire !");
                        markPlayer(player, nearby);
                    }
                }

                blocks++;
            }
        }, 0L, 1L);
    }

    // Capacité 2 : Miroir du Malheur
    public void castMiroirDuMalheur(Player player) {
        long now = System.currentTimeMillis();
        long lastUse = miroirCooldown.getOrDefault(player.getUniqueId(), 0L);
        if (now - lastUse < 60000) {
            player.sendMessage(ChatColor.RED + "Cooldown ! Encore " + ((60000 - (now - lastUse)) / 1000) + "s");
            return;
        }
        miroirCooldown.put(player.getUniqueId(), now);
        refreshStarItem(player);
        player.sendMessage(ChatColor.LIGHT_PURPLE + "Miroir du Malheur !");

        Location eyeLoc = player.getEyeLocation().clone();
        Vector baseDir = eyeLoc.getDirection().normalize();

        // Projeter des entailles en cône sur 20 blocs
        // 5 rayons en cône (centre + 4 côtés) compatible 1.8.9
        List<Vector> coneDirections = new ArrayList<>();
        coneDirections.add(baseDir.clone()); // centre

        // Calculer 2 vecteurs perpendiculaires à baseDir
        Vector perp1 = new Vector(-baseDir.getZ(), 0, baseDir.getX()).normalize();
        Vector perp2 = baseDir.clone().crossProduct(perp1).normalize();
        double spread = Math.tan(Math.toRadians(15)); // écart du cône

        coneDirections.add(baseDir.clone().add(perp1.clone().multiply(spread)).normalize());
        coneDirections.add(baseDir.clone().add(perp1.clone().multiply(-spread)).normalize());
        coneDirections.add(baseDir.clone().add(perp2.clone().multiply(spread)).normalize());
        coneDirections.add(baseDir.clone().add(perp2.clone().multiply(-spread)).normalize());

        Set<UUID> alreadyHit = new HashSet<>();

        for (Vector coneDir : coneDirections) {
            Location rayLoc = eyeLoc.clone();
            for (int i = 0; i < 20; i++) {
                rayLoc.add(coneDir.clone().multiply(1));
                rayLoc.getWorld().playEffect(rayLoc, Effect.COLOURED_DUST, 10);

                // Toucher les joueurs
                for (Player nearby : Bukkit.getOnlinePlayers()) {
                    if (!nearby.equals(player) && !alreadyHit.contains(nearby.getUniqueId())
                            && nearby.getLocation().distance(rayLoc) < 1.5) {
                        alreadyHit.add(nearby.getUniqueId());

                        // Envoyer 30 blocs en l'air
                        nearby.setVelocity(new Vector(0, 3.0, 0));

                        // FIX: marquer le joueur comme lancé pour annuler les dégâts de chute
                        miroirLaunched.add(nearby.getUniqueId());
                        plugin.getServer().getScheduler().runTaskLater(plugin, new Runnable() {
                            @Override
                            public void run() {
                                miroirLaunched.remove(nearby.getUniqueId());
                            }
                        }, 20L * 8); // retirer l'immunité après 8s

                        plugin.getServer().getScheduler().runTaskLater(plugin, new Runnable() {
                            @Override
                            public void run() {
                                if (!nearby.isOnline()) return;
                                // Forcer le regard vers le ciel
                                Location look = nearby.getLocation();
                                look.setPitch(-90);
                                nearby.teleport(look);
                                nearby.setVelocity(new Vector(0, 3.0, 0));
                            }
                        }, 1L);

                        nearby.sendMessage(ChatColor.DARK_PURPLE + "Tu as été frappé par le Miroir du Malheur !");
                        markPlayer(player, nearby);
                    }
                }
            }
        }
    }

    // Switcher entre les capacités (clic gauche sur le nether star)
    public void onStarLeftClick(Player player) {
        int current = selectedAbility.getOrDefault(player.getUniqueId(), 0);
        int next = (current + 1) % 2;
        selectedAbility.put(player.getUniqueId(), next);
        refreshStarItem(player);
        String[] names = {"§dLune Noire", "§dMiroir du Malheur"};
        player.sendMessage(ChatColor.LIGHT_PURPLE + "Capacité : " + names[next]);
    }

    // Utiliser la capacité (clic droit sur le nether star)
    public void onStarRightClick(Player player) {
        int ability = selectedAbility.getOrDefault(player.getUniqueId(), 0);
        if (ability == 0) {
            castLuneNoire(player);
        } else {
            castMiroirDuMalheur(player);
        }
    }

    public boolean isMiroirLaunched(Player player) {
        return miroirLaunched.contains(player.getUniqueId());
    }

    public boolean isKokushiboSword(ItemStack item) {
        if (item == null || item.getType() != Material.DIAMOND_SWORD) return false;
        if (!item.hasItemMeta()) return false;
        ItemMeta meta = item.getItemMeta();
        return meta.hasDisplayName() && meta.getDisplayName().equals(ChatColor.LIGHT_PURPLE + "Lame Lunaire");
    }

    public boolean isKokushiboStar(ItemStack item) {
        if (item == null || item.getType() != Material.NETHER_STAR) return false;
        if (!item.hasItemMeta()) return false;
        ItemMeta meta = item.getItemMeta();
        if (!meta.hasDisplayName()) return false;
        String name = meta.getDisplayName();
        return name.equals(ChatColor.LIGHT_PURPLE + "Lune Noire") || name.equals(ChatColor.LIGHT_PURPLE + "Miroir du Malheur");
    }
}