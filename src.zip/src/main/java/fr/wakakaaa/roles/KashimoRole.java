package fr.wakakaaa.roles;

import fr.wakakaaa.Main;
import org.bukkit.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

public class KashimoRole implements Role {

    private Main plugin;
    private Map<UUID, Integer> charges = new HashMap<>();
    private Map<UUID, Integer> hitsCount = new HashMap<>();
    private Map<UUID, Long> electrificationCooldown = new HashMap<>();
    private Map<UUID, Boolean> trailFireImmune = new HashMap<>();
    private Map<UUID, BukkitTask> chargeTimers = new HashMap<>();

    public KashimoRole() {
        this.plugin = Main.getInstance();
    }

    @Override
    public String getName() {
        return "Kashimo";
    }

    @Override
    public String getDescription() {
        return "Maître de la foudre !";
    }

    @Override
    public void applyRole(Player player) {
        player.sendMessage(ChatColor.YELLOW + "Tu es " + ChatColor.GOLD + "Kashimo !");
        player.sendMessage(ChatColor.YELLOW + getDescription());
        charges.put(player.getUniqueId(), 3);
        hitsCount.put(player.getUniqueId(), 0);
        giveItems(player);
        startChargeTimer(player);
    }

    @Override
    public void removeRole(Player player) {
        charges.remove(player.getUniqueId());
        hitsCount.remove(player.getUniqueId());
        electrificationCooldown.remove(player.getUniqueId());
        trailFireImmune.remove(player.getUniqueId());
        if (chargeTimers.containsKey(player.getUniqueId())) {
            chargeTimers.get(player.getUniqueId()).cancel();
            chargeTimers.remove(player.getUniqueId());
        }
        player.removePotionEffect(PotionEffectType.SPEED);
    }

    @Override
    public void onAbility(Player player) {
    }

    private void giveItems(Player player) {
        ItemStack sword = new ItemStack(Material.DIAMOND_SWORD);
        ItemMeta swordMeta = sword.getItemMeta();
        swordMeta.setDisplayName(ChatColor.YELLOW + "Bâton Nyoi");
        sword.setItemMeta(swordMeta);
        sword.addEnchantment(Enchantment.DAMAGE_ALL, 3);
        updateWeaponLore(player, sword);
        player.getInventory().setItem(0, sword);

        ItemStack star = new ItemStack(Material.NETHER_STAR);
        ItemMeta starMeta = star.getItemMeta();
        starMeta.setDisplayName(ChatColor.YELLOW + "Électrification");
        List<String> starLore = new ArrayList<>();
        starLore.add(ChatColor.GRAY + "Clic-Droit pour activer");
        starLore.add(ChatColor.GRAY + "Cooldown: 45s");
        starMeta.setLore(starLore);
        star.setItemMeta(starMeta);
        player.getInventory().setItem(1, star);
    }

    private void updateWeaponLore(Player player, ItemStack sword) {
        int charge = charges.getOrDefault(player == null ? UUID.randomUUID() : player.getUniqueId(), 3);
        ItemMeta meta = sword.getItemMeta();
        List<String> lore = new ArrayList<>();
        StringBuilder chargeBar = new StringBuilder("§eCharges: ");
        for (int i = 0; i < 3; i++) {
            if (i < charge) {
                chargeBar.append("§6⚡");
            } else {
                chargeBar.append("§7⚡");
            }
        }
        lore.add(chargeBar.toString());
        lore.add(ChatColor.GRAY + "Clic-Droit pour libérer la foudre");
        meta.setLore(lore);
        sword.setItemMeta(meta);
    }

    public void refreshWeaponInHand(Player player) {
        ItemStack item = player.getInventory().getItem(0);
        if (item != null && item.getType() == Material.DIAMOND_SWORD) {
            ItemMeta meta = item.getItemMeta();
            if (meta != null && meta.getDisplayName().equals(ChatColor.YELLOW + "Bâton Nyoi")) {
                updateWeaponLore(player, item);
                player.getInventory().setItem(0, item);
            }
        }
        // Afficher les charges au dessus de la hotbar
        int charge = charges.getOrDefault(player.getUniqueId(), 0);
        StringBuilder bar = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            if (i < charge) {
                bar.append("§6⚡ ");
            } else {
                bar.append("§8⚡ ");
            }
        }
        fr.wakakaaa.utils.TitleUtils.sendActionBar(player, bar.toString().trim() + " §7(" + charge + "/3)");
    }

    private void startChargeTimer(Player player) {
        BukkitTask[] taskHolder = new BukkitTask[1];
        taskHolder[0] = plugin.getServer().getScheduler().runTaskTimer(plugin, new Runnable() {
            @Override
            public void run() {
                if (!player.isOnline()) {
                    taskHolder[0].cancel();
                    return;
                }
                int charge = charges.getOrDefault(player.getUniqueId(), 0);
                if (charge < 3) {
                    charges.put(player.getUniqueId(), charge + 1);
                    player.sendMessage("§e⚡ Charge rechargée ! (" + (charge + 1) + "/3)");
                    refreshWeaponInHand(player);
                }
            }
        }, 20L * 20, 20L * 20);
        chargeTimers.put(player.getUniqueId(), taskHolder[0]);
    }

    public void onHit(Player player) {
        int hits = hitsCount.getOrDefault(player.getUniqueId(), 0) + 1;
        if (hits >= 10) {
            hitsCount.put(player.getUniqueId(), 0);
            int charge = charges.getOrDefault(player.getUniqueId(), 0);
            if (charge < 3) {
                charges.put(player.getUniqueId(), charge + 1);
                player.sendMessage("§e⚡ Charge rechargée ! (" + (charge + 1) + "/3)");
                refreshWeaponInHand(player);
            }
        } else {
            hitsCount.put(player.getUniqueId(), hits);
        }
    }

    public void onKill(Player player) {
        charges.put(player.getUniqueId(), 3);
        player.sendMessage("§e⚡ Toutes les charges rechargées !");
        refreshWeaponInHand(player);
    }

    public void onBatonRightClick(Player player) {
        int charge = charges.getOrDefault(player.getUniqueId(), 0);
        if (charge <= 0) {
            player.sendMessage("§cPas de charges disponibles !");
            return;
        }

        int chargesUsed = charge;
        charges.put(player.getUniqueId(), 0);
        refreshWeaponInHand(player);

        Location loc = player.getEyeLocation();
        org.bukkit.util.Vector direction = loc.getDirection().normalize();

        Player target = null;
        for (int i = 1; i <= 10; i++) {
            Location check = loc.clone().add(direction.clone().multiply(i));
            check.getWorld().playEffect(check, Effect.COLOURED_DUST, 4);

            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!p.equals(player) && p.getLocation().distance(check) < 1.5) {
                    target = p;
                    break;
                }
            }
            if (target != null) break;
        }

        if (target != null) {
            // FIX: strikeLightningEffect au lieu de strikeLightning
            // strikeLightning = vrai éclair qui blesse tout le monde autour (y compris Kashimo)
            // strikeLightningEffect = juste l'effet visuel/sonore, sans dégâts automatiques
            target.getWorld().strikeLightningEffect(target.getLocation());
            target.setFireTicks(80);
            target.damage(chargesUsed * 1.0, player);
            target.sendMessage("§cTu as été foudroyé par Kashimo !");
            player.sendMessage("§eFoudre libérée sur " + target.getName() + " avec " + chargesUsed + " charges !");
            triggerPassifFoudre(player);
        } else {
            player.sendMessage("§cAucune cible sur la trajectoire !");
            charges.put(player.getUniqueId(), chargesUsed);
            refreshWeaponInHand(player);
        }
    }

    public void onElectrificationRightClick(Player player) {
        long now = System.currentTimeMillis();
        long lastUse = electrificationCooldown.getOrDefault(player.getUniqueId(), 0L);

        if (now - lastUse < 45000) {
            long remaining = (45000 - (now - lastUse)) / 1000;
            player.sendMessage("§cCooldown ! Encore " + remaining + "s");
            return;
        }

        electrificationCooldown.put(player.getUniqueId(), now);
        startElectrification(player);
    }

    private void startElectrification(Player player) {
        // FIX: retirer l'effet de speed existant avant d'appliquer le nouveau
        player.removePotionEffect(PotionEffectType.SPEED);
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 5, 3, false, true));
        player.sendMessage("§e⚡ Électrification activée !");

        List<Location> trail = new ArrayList<>();

        BukkitTask[] taskHolder = new BukkitTask[1];
        taskHolder[0] = plugin.getServer().getScheduler().runTaskTimer(plugin, new Runnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks >= 100 || !player.isOnline()) {
                    strikeTrail(player, trail);
                    taskHolder[0].cancel();
                    return;
                }
                Location loc = player.getLocation().clone();
                trail.add(loc);
                loc.getWorld().playEffect(loc, Effect.COLOURED_DUST, 4);
                ticks++;
            }
        }, 0L, 1L);
    }

    private void strikeTrail(Player player, List<Location> trail) {
        for (Location loc : trail) {
            loc.getWorld().strikeLightningEffect(loc);
            for (Player nearby : Bukkit.getOnlinePlayers()) {
                if (!nearby.equals(player) && nearby.getLocation().distance(loc) < 3.0) {
                    nearby.setFireTicks(160);
                    trailFireImmune.put(nearby.getUniqueId(), true);
                    nearby.sendMessage("§cTu es enflammé par la traînée de Kashimo !");
                    plugin.getServer().getScheduler().runTaskLater(plugin, new Runnable() {
                        @Override
                        public void run() {
                            trailFireImmune.remove(nearby.getUniqueId());
                        }
                    }, 20L * 8);
                }
            }
        }
        triggerPassifFoudre(player);
    }

    public void triggerPassifFoudre(Player player) {
        // FIX: n'appliquer la speed I que si pas déjà un effet plus fort
        PotionEffect current = null;
        for (PotionEffect effect : player.getActivePotionEffects()) {
            if (effect.getType().equals(PotionEffectType.SPEED)) {
                current = effect;
                break;
            }
        }
        if (current == null || current.getAmplifier() < 1) {
            player.removePotionEffect(PotionEffectType.SPEED);
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 15, 0, false, true));
        }
        player.sendMessage("§ePassif Foudre : Vitesse I activée !");
    }

    public boolean isTrailFireImmune(Player player) {
        return trailFireImmune.getOrDefault(player.getUniqueId(), false);
    }

    public int getCharges(Player player) {
        return charges.getOrDefault(player.getUniqueId(), 0);
    }
}