package fr.wakakaaa.roles;

import fr.wakakaaa.Main;
import org.bukkit.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;

public class YoriichRole implements Role {

    private Main plugin;

    private Map<UUID, Boolean> marqueActive = new HashMap<>();
    private Map<UUID, BukkitTask> marqueTasks = new HashMap<>();
    private Map<UUID, Integer> hitCount = new HashMap<>();

    private Map<UUID, UUID> lastHitPlayer = new HashMap<>();
    private Map<UUID, String> weakPoint = new HashMap<>();
    private Map<UUID, BukkitTask> weakPointTasks = new HashMap<>();
    private Map<UUID, Boolean> weakPointActive = new HashMap<>();

    // ── FIX : empêche de spawner plusieurs points faibles en même temps ──
    private Map<UUID, Boolean> weakPointRespawning = new HashMap<>();

    private Map<UUID, Long> danseCooldown = new HashMap<>();
    private Map<UUID, Boolean> lameRouge = new HashMap<>();

    public YoriichRole() {
        this.plugin = Main.getInstance();
    }

    @Override
    public String getName() { return "Yoriichi"; }

    @Override
    public String getDescription() { return "Le Dieu du Souffle !"; }

    @Override
    public void applyRole(Player player) {
        player.sendMessage(ChatColor.GOLD + "Tu es " + ChatColor.RED + "Yoriichi Tsugikuni !");
        player.sendMessage(ChatColor.GOLD + getDescription());
        player.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, Integer.MAX_VALUE, 0, false, false));
        hitCount.put(player.getUniqueId(), 0);
        marqueActive.put(player.getUniqueId(), false);
        lameRouge.put(player.getUniqueId(), false);
        weakPointActive.put(player.getUniqueId(), false);
        weakPointRespawning.put(player.getUniqueId(), false);
        danseCooldown.put(player.getUniqueId(), 0L);
        giveItems(player);
        startPassifs(player);
    }

    @Override
    public void removeRole(Player player) {
        player.removePotionEffect(PotionEffectType.DAMAGE_RESISTANCE);
        player.removePotionEffect(PotionEffectType.SPEED);
        if (marqueTasks.containsKey(player.getUniqueId())) {
            marqueTasks.get(player.getUniqueId()).cancel();
            marqueTasks.remove(player.getUniqueId());
        }
        if (weakPointTasks.containsKey(player.getUniqueId())) {
            weakPointTasks.get(player.getUniqueId()).cancel();
            weakPointTasks.remove(player.getUniqueId());
        }
        hitCount.remove(player.getUniqueId());
        marqueActive.remove(player.getUniqueId());
        lameRouge.remove(player.getUniqueId());
        weakPointActive.remove(player.getUniqueId());
        weakPointRespawning.remove(player.getUniqueId());
        weakPoint.remove(player.getUniqueId());
        lastHitPlayer.remove(player.getUniqueId());
        danseCooldown.remove(player.getUniqueId());
    }

    @Override
    public void onAbility(Player player) {}

    private void giveItems(Player player) {
        ItemStack sword = new ItemStack(Material.DIAMOND_SWORD);
        ItemMeta swordMeta = sword.getItemMeta();
        swordMeta.setDisplayName(ChatColor.WHITE + "Lame de Nichirin");
        List<String> swordLore = new ArrayList<>();
        swordLore.add(ChatColor.GRAY + "Frappe les ennemis sous Régénération");
        swordMeta.setLore(swordLore);
        sword.setItemMeta(swordMeta);
        sword.addEnchantment(Enchantment.DAMAGE_ALL, 3);
        player.getInventory().setItem(0, sword);

        ItemStack danse = new ItemStack(Material.NETHER_STAR);
        ItemMeta danseMeta = danse.getItemMeta();
        danseMeta.setDisplayName(ChatColor.GOLD + "Danse du Dragon Solaire");
        List<String> danseLore = new ArrayList<>();
        danseLore.add(ChatColor.GRAY + "Clic-Droit pour se propulser");
        danseLore.add(ChatColor.GRAY + "Cooldown: 45s");
        danseMeta.setLore(danseLore);
        danse.setItemMeta(danseMeta);
        player.getInventory().setItem(1, danse);
    }

    private void startPassifs(Player player) {
        plugin.getServer().getScheduler().runTaskTimer(plugin, new Runnable() {
            @Override
            public void run() {
                if (!player.isOnline()) return;

                boolean rouge = false;
                for (Player p : Bukkit.getOnlinePlayers()) {
                    if (p.equals(player)) continue;
                    if (player.getLocation().distance(p.getLocation()) <= 15) {
                        if (hasRegen(p)) {
                            rouge = true;
                            break;
                        }
                    }
                }

                boolean wasRouge = lameRouge.getOrDefault(player.getUniqueId(), false);
                lameRouge.put(player.getUniqueId(), rouge);

                if (rouge != wasRouge) {
                    updateSwordName(player, rouge);
                }

                updateActionBar(player);
            }
        }, 0L, 5L);
    }

    private boolean hasRegen(Player player) {
        for (PotionEffect effect : player.getActivePotionEffects()) {
            if (effect.getType().equals(PotionEffectType.REGENERATION)) return true;
        }
        return false;
    }

    private PotionEffect getRegenEffect(Player player) {
        for (PotionEffect effect : player.getActivePotionEffects()) {
            if (effect.getType().equals(PotionEffectType.REGENERATION)) return effect;
        }
        return null;
    }

    public void updateSwordName(Player player, boolean rouge) {
        for (int i = 0; i < player.getInventory().getSize(); i++) {
            ItemStack item = player.getInventory().getItem(i);
            if (item == null || item.getType() != Material.DIAMOND_SWORD) continue;
            if (!item.hasItemMeta()) continue;
            ItemMeta meta = item.getItemMeta();
            if (meta == null || !meta.hasDisplayName()) continue;
            String name = meta.getDisplayName();
            if (!name.contains("Nichirin") && !name.contains("Rouge")) continue;
            meta.setDisplayName(rouge ? ChatColor.RED + "Lame Rouge" : ChatColor.WHITE + "Lame de Nichirin");
            item.setItemMeta(meta);
            player.getInventory().setItem(i, item);
        }
    }

    private void updateActionBar(Player player) {
        StringBuilder bar = new StringBuilder();
        boolean marque = marqueActive.getOrDefault(player.getUniqueId(), false);
        if (marque) {
            bar.append("§6☀ §eMarque Active §6☀");
        } else {
            int hits = hitCount.getOrDefault(player.getUniqueId(), 0);
            bar.append("§7Marque: §f").append(hits).append("/15");
        }

        UUID lastUUID = lastHitPlayer.get(player.getUniqueId());
        if (lastUUID != null) {
            Player last = Bukkit.getPlayer(lastUUID);
            if (last != null && last.isOnline()) {
                double hp = last.getHealth();
                double maxHp = last.getMaxHealth();
                bar.append(" §7| §c").append(String.format("%.1f", hp / 2))
                        .append("§7/§c").append(String.format("%.1f", maxHp / 2))
                        .append("❤ §7(").append(last.getName()).append(")");
            }
        }

        fr.wakakaaa.utils.TitleUtils.sendActionBar(player, bar.toString());
    }

    public void onHit(Player yoriichi, Player victim) {
        lastHitPlayer.put(yoriichi.getUniqueId(), victim.getUniqueId());

        boolean rouge = lameRouge.getOrDefault(yoriichi.getUniqueId(), false);
        boolean victimHasRegen = hasRegen(victim);

        if (victimHasRegen) {
            PotionEffect regenEffect = getRegenEffect(victim);
            if (regenEffect != null) {
                int newDuration = regenEffect.getDuration() - 20;
                victim.removePotionEffect(PotionEffectType.REGENERATION);
                if (newDuration > 0) {
                    victim.addPotionEffect(new PotionEffect(
                            PotionEffectType.REGENERATION,
                            newDuration,
                            regenEffect.getAmplifier(),
                            false, false));
                }
                victim.sendMessage("§cTa régénération a été réduite !");
            }
        }

        boolean marque = marqueActive.getOrDefault(yoriichi.getUniqueId(), false);
        if (marque && rouge) {
            if (Math.random() < 0.25) {
                victim.setFireTicks(Integer.MAX_VALUE);
                plugin.getServer().getScheduler().runTaskLater(plugin, new Runnable() {
                    @Override
                    public void run() { victim.setFireTicks(0); }
                }, 20L * 6);
                victim.sendMessage("§cTu es enflammé par la Lame Rouge !");
            }
        }

        if (!marque) {
            int hits = hitCount.getOrDefault(yoriichi.getUniqueId(), 0) + 1;
            if (hits >= 15) {
                hitCount.put(yoriichi.getUniqueId(), 0);
                activateMarque(yoriichi);
            } else {
                hitCount.put(yoriichi.getUniqueId(), hits);
            }
        }

        updateActionBar(yoriichi);
        checkWeakPoint(yoriichi, victim);
    }

    public void onKill(Player yoriichi) {
        activateMarque(yoriichi);
    }

    private void activateMarque(Player player) {
        marqueActive.put(player.getUniqueId(), true);
        player.sendMessage("§6☀ Marque du Pourfendeur activée !");
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 30, 0, false, false));
        if (marqueTasks.containsKey(player.getUniqueId())) {
            marqueTasks.get(player.getUniqueId()).cancel();
        }
        BukkitTask task = plugin.getServer().getScheduler().runTaskLater(plugin, new Runnable() {
            @Override
            public void run() {
                marqueActive.put(player.getUniqueId(), false);
                player.removePotionEffect(PotionEffectType.SPEED);
                player.sendMessage("§7Marque du Pourfendeur expirée.");
                marqueTasks.remove(player.getUniqueId());
            }
        }, 20L * 30);
        marqueTasks.put(player.getUniqueId(), task);
    }

    private void checkWeakPoint(Player yoriichi, Player victim) {
        UUID uuid = yoriichi.getUniqueId();

        // ── FIX : si le point faible est actif, vérifier si ce coup le déclenche ──
        if (weakPointActive.getOrDefault(uuid, false)) {
            // Vérifier que la victime est bien la même que celle qui a le point faible
            UUID wpTarget = lastHitPlayer.get(uuid);
            if (wpTarget == null || !wpTarget.equals(victim.getUniqueId())) return;

            String zone = weakPoint.getOrDefault(uuid, "");
            if (zone.isEmpty()) return;

            // Désactiver le point faible immédiatement pour éviter tout double déclenchement
            weakPointActive.put(uuid, false);
            weakPoint.remove(uuid);
            if (weakPointTasks.containsKey(uuid)) {
                weakPointTasks.get(uuid).cancel();
                weakPointTasks.remove(uuid);
            }

            // Appliquer le malus selon la zone
            switch (zone) {
                case "HEAD":
                    yoriichi.sendMessage("§aPoint faible touché : §fTête !");
                    victim.sendMessage("§cTu es étourdi !");
                    BukkitTask[] headTask = new BukkitTask[1];
                    headTask[0] = plugin.getServer().getScheduler().runTaskTimer(plugin, new Runnable() {
                        int ticks = 0;
                        @Override
                        public void run() {
                            if (!victim.isOnline() || ticks >= 40) { headTask[0].cancel(); return; }
                            Location look = victim.getLocation();
                            look.setPitch(90);
                            victim.teleport(look);
                            ticks++;
                        }
                    }, 0L, 1L);
                    break;

                case "TORSO":
                    yoriichi.sendMessage("§aPoint faible touché : §fTorse !");
                    victim.sendMessage("§cTu as pris un double coup !");
                    double newHealth = Math.max(0, victim.getHealth() - 7.0);
                    victim.setHealth(newHealth);
                    victim.damage(0.001, yoriichi);
                    break;

                case "LEGS":
                    yoriichi.sendMessage("§aPoint faible touché : §fJambes !");
                    victim.sendMessage("§cTu ne peux plus sprinter !");
                    victim.setSprinting(false);
                    victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 20 * 4, 1, false, false));
                    break;
            }

            // Planifier le respawn après 7s
            scheduleWeakPointRespawn(yoriichi, victim);
            return;
        }

        // ── FIX : ne spawner un nouveau point faible QUE si aucun respawn n'est déjà en cours ──
        // Sans ce check, chaque coup pendant l'attente du respawn spawnait un nouveau point faible
        if (!weakPointRespawning.getOrDefault(uuid, false)) {
            weakPointRespawning.put(uuid, true);
            spawnWeakPoint(yoriichi, victim);
        }
    }

    private void spawnWeakPoint(Player yoriichi, Player victim) {
        String[] zones = {"HEAD", "TORSO", "LEGS"};
        String zone = zones[new Random().nextInt(3)];
        weakPoint.put(yoriichi.getUniqueId(), zone);
        weakPointActive.put(yoriichi.getUniqueId(), true);
        weakPointRespawning.put(yoriichi.getUniqueId(), false); // reset : le point est maintenant actif
        String zoneName = zone.equals("HEAD") ? "§cTête" : zone.equals("TORSO") ? "§cTorse" : "§cJambes";
        yoriichi.sendMessage("§fPoint faible détecté : " + zoneName + " §fsur §f" + victim.getName());
        startWeakPointParticles(yoriichi, victim, zone);
    }

    private void startWeakPointParticles(Player yoriichi, Player victim, String zone) {
        BukkitTask[] particleTask = new BukkitTask[1];
        particleTask[0] = plugin.getServer().getScheduler().runTaskTimer(plugin, new Runnable() {
            @Override
            public void run() {
                if (!victim.isOnline() || !yoriichi.isOnline()
                        || !weakPointActive.getOrDefault(yoriichi.getUniqueId(), false)) {
                    particleTask[0].cancel();
                    return;
                }
                Location loc = victim.getLocation().clone();
                switch (zone) {
                    case "HEAD":  loc.add(0, 1.8, 0); break;
                    case "TORSO": loc.add(0, 1.2, 0); break;
                    case "LEGS":  loc.add(0, 0.5, 0); break;
                }
                yoriichi.getWorld().playEffect(loc, Effect.COLOURED_DUST, 15);
            }
        }, 0L, 3L);
        weakPointTasks.put(yoriichi.getUniqueId(), particleTask[0]);
    }

    private void scheduleWeakPointRespawn(Player yoriichi, Player victim) {
        // ── FIX : marquer qu'un respawn est en cours pour bloquer les spawns intempestifs ──
        weakPointRespawning.put(yoriichi.getUniqueId(), true);
        plugin.getServer().getScheduler().runTaskLater(plugin, new Runnable() {
            @Override
            public void run() {
                if (!yoriichi.isOnline() || !victim.isOnline()) {
                    weakPointRespawning.put(yoriichi.getUniqueId(), false);
                    return;
                }
                spawnWeakPoint(yoriichi, victim);
            }
        }, 20L * 7); // 7 secondes comme demandé
    }

    public void onDanseDragon(Player player) {
        long now = System.currentTimeMillis();
        long cd = danseCooldown.getOrDefault(player.getUniqueId(), 0L);
        if (now - cd < 45000) {
            player.sendMessage("§cCooldown ! Encore " + ((45000 - (now - cd)) / 1000) + "s");
            return;
        }
        danseCooldown.put(player.getUniqueId(), now);
        player.sendMessage("§6Danse du Dragon Solaire !");

        Vector direction = player.getEyeLocation().getDirection().normalize();
        List<Location> path = new ArrayList<>();

        for (int t = 0; t < 3; t++) {
            plugin.getServer().getScheduler().runTaskLater(plugin, new Runnable() {
                @Override
                public void run() {
                    if (!player.isOnline()) return;
                    player.setVelocity(direction.clone().multiply(4.0));
                }
            }, t);
        }

        BukkitTask[] pathTask = new BukkitTask[1];
        pathTask[0] = plugin.getServer().getScheduler().runTaskTimer(plugin, new Runnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks >= 30 || !player.isOnline()) {
                    pathTask[0].cancel();
                    launchDragon(player, new ArrayList<>(path));
                    return;
                }
                path.add(player.getLocation().clone());
                player.getLocation().getWorld().playEffect(player.getLocation(), Effect.COLOURED_DUST, 4);
                ticks++;
            }
        }, 0L, 1L);
    }

    private void launchDragon(Player player, List<Location> path) {
        if (path.isEmpty()) return;
        BukkitTask[] dragonTask = new BukkitTask[1];
        dragonTask[0] = plugin.getServer().getScheduler().runTaskTimer(plugin, new Runnable() {
            int index = 0;
            Set<UUID> hit = new HashSet<>();
            @Override
            public void run() {
                if (index >= path.size() || !player.isOnline()) {
                    dragonTask[0].cancel();
                    return;
                }
                Location loc = path.get(index);
                loc.getWorld().playEffect(loc, Effect.COLOURED_DUST, 14);
                loc.getWorld().playEffect(loc.clone().add(0, 1, 0), Effect.COLOURED_DUST, 14);
                for (Player nearby : Bukkit.getOnlinePlayers()) {
                    if (nearby.equals(player) || hit.contains(nearby.getUniqueId())) continue;
                    if (nearby.getLocation().distance(loc) < 2.5) {
                        hit.add(nearby.getUniqueId());
                        Vector repulse = nearby.getLocation().subtract(loc).toVector().normalize().multiply(2.0);
                        repulse.setY(0.3);
                        nearby.setVelocity(repulse);
                        nearby.setFireTicks(Integer.MAX_VALUE);
                        plugin.getServer().getScheduler().runTaskLater(plugin, new Runnable() {
                            @Override
                            public void run() { nearby.setFireTicks(0); }
                        }, 20L * 6);
                        nearby.sendMessage("§cTu as été touché par le Dragon Solaire !");
                    }
                }
                index++;
            }
        }, 5L, 1L);
    }

    public boolean isNichirinSword(ItemStack item) {
        if (item == null || item.getType() != Material.DIAMOND_SWORD) return false;
        if (!item.hasItemMeta()) return false;
        ItemMeta meta = item.getItemMeta();
        if (!meta.hasDisplayName()) return false;
        String name = meta.getDisplayName();
        return name.contains("Nichirin") || name.contains("Rouge");
    }

    public boolean isDanseDragonItem(ItemStack item) {
        if (item == null || item.getType() != Material.NETHER_STAR) return false;
        if (!item.hasItemMeta()) return false;
        ItemMeta meta = item.getItemMeta();
        return meta.hasDisplayName() && meta.getDisplayName().equals(ChatColor.GOLD + "Danse du Dragon Solaire");
    }

    public boolean isLameRouge(Player player) {
        return lameRouge.getOrDefault(player.getUniqueId(), false);
    }
}