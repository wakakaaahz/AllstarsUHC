package fr.wakakaaa.roles;

import fr.wakakaaa.Main;
import fr.wakakaaa.utils.TitleUtils;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

public class SunrakuRole implements Role {

    private final Main plugin;

    // ── Jauge de fusion (0..10 par épée, 10 = 50%) ──────────────────────────
    private final Map<UUID, Integer> goldsheenGauge   = new HashMap<>();
    private final Map<UUID, Integer> netherlightGauge = new HashMap<>();
    private final Map<UUID, Boolean> fusionActive      = new HashMap<>();

    // ── Goldsheen – cristallisation ─────────────────────────────────────────
    private final Map<UUID, Integer>    crystalSlot     = new HashMap<>();
    private final Map<UUID, ItemStack>  crystalSaved    = new HashMap<>();
    private final Map<UUID, BukkitTask> crystalTasks    = new HashMap<>();

    // ── Netherlight – compteur de crits ─────────────────────────────────────
    private final Map<UUID, Integer>  netherlightCrits    = new HashMap<>();
    private final Map<UUID, Long>     netherlightCooldown = new HashMap<>();

    // ── Parade Parfaite ──────────────────────────────────────────────────────
    private final Map<UUID, Long>     blockStart     = new HashMap<>();
    private final Map<UUID, Long>     paradeCooldown = new HashMap<>();
    private final Map<UUID, Boolean>  paradeBonus    = new HashMap<>();

    // ── Gravity Zero ────────────────────────────────────────────────────────
    private final Map<UUID, Integer>    gravityCharges  = new HashMap<>();
    private final Map<UUID, BukkitTask> chargeRegenTask = new HashMap<>();

    // ── Action bar ──────────────────────────────────────────────────────────
    private final Map<UUID, BukkitTask> actionBarTask = new HashMap<>();

    public SunrakuRole(Main plugin) {
        this.plugin = plugin;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Role interface
    // ════════════════════════════════════════════════════════════════════════

    @Override
    public String getName() {
        return "Sunraku";
    }

    @Override
    public String getDescription() {
        return "Mercenaire dual-wielder aux lames jumelles Goldsheen & Netherlight";
    }

    @Override
    public void applyRole(Player player) {
        UUID uuid = player.getUniqueId();

        goldsheenGauge.put(uuid, 0);
        netherlightGauge.put(uuid, 0);
        fusionActive.put(uuid, false);
        netherlightCrits.put(uuid, 0);
        gravityCharges.put(uuid, 5);
        paradeBonus.put(uuid, false);

        player.sendMessage(ChatColor.GOLD + "Tu es " + ChatColor.YELLOW + "Sunraku" + ChatColor.GOLD + " !");
        player.sendMessage(ChatColor.GRAY + "Tes lames jumelles t'attendent...");

        giveItems(player);
        startChargeRegen(player);
        startActionBar(player);
    }

    @Override
    public void removeRole(Player player) {
        UUID uuid = player.getUniqueId();

        cancelTask(actionBarTask, uuid);
        cancelTask(chargeRegenTask, uuid);
        cancelTask(crystalTasks, uuid);

        restoreCrystalSlot(player);

        goldsheenGauge.remove(uuid);
        netherlightGauge.remove(uuid);
        fusionActive.remove(uuid);
        netherlightCrits.remove(uuid);
        netherlightCooldown.remove(uuid);
        gravityCharges.remove(uuid);
        blockStart.remove(uuid);
        paradeCooldown.remove(uuid);
        paradeBonus.remove(uuid);
        crystalSlot.remove(uuid);
        crystalSaved.remove(uuid);
    }

    @Override
    public void onAbility(Player player) {
        // Géré par le listener
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Items
    // ════════════════════════════════════════════════════════════════════════

    private void giveItems(Player player) {
        player.getInventory().setItem(0, buildGoldsheen(player));
        player.getInventory().setItem(1, buildNetherlight(player));
        player.getInventory().setItem(2, buildGravityZero(player));
    }

    public ItemStack buildGoldsheen(Player player) {
        UUID uuid = player.getUniqueId();
        ItemStack sword = new ItemStack(Material.DIAMOND_SWORD);
        ItemMeta meta = sword.getItemMeta();
        meta.setDisplayName(ChatColor.GOLD + "Goldsheen");
        meta.addEnchant(Enchantment.DAMAGE_ALL, 3, true);

        int gauge = goldsheenGauge.getOrDefault(uuid, 0);
        List<String> lore = new ArrayList<>();
        lore.add(buildGaugeBar(gauge, ChatColor.GOLD));
        lore.add(ChatColor.GRAY + "Jauge : " + ChatColor.YELLOW + (gauge * 5) + "%" + ChatColor.GRAY + "/50%");
        lore.add("");
        lore.add(ChatColor.GOLD + "Crit" + ChatColor.GRAY + " → Vitesse 5s + Cristallisation");
        meta.setLore(lore);
        sword.setItemMeta(meta);
        return sword;
    }

    public ItemStack buildNetherlight(Player player) {
        UUID uuid = player.getUniqueId();
        ItemStack sword = new ItemStack(Material.DIAMOND_SWORD);
        ItemMeta meta = sword.getItemMeta();
        meta.setDisplayName(ChatColor.DARK_PURPLE + "Netherlight");
        meta.addEnchant(Enchantment.DAMAGE_ALL, 3, true);

        int gauge = netherlightGauge.getOrDefault(uuid, 0);
        int crits = netherlightCrits.getOrDefault(uuid, 0);
        List<String> lore = new ArrayList<>();
        lore.add(buildGaugeBar(gauge, ChatColor.DARK_PURPLE));
        lore.add(ChatColor.GRAY + "Jauge : " + ChatColor.LIGHT_PURPLE + (gauge * 5) + "%" + ChatColor.GRAY + "/50%");
        lore.add(ChatColor.GRAY + "Crits : " + ChatColor.LIGHT_PURPLE + crits + "/4");
        lore.add("");
        lore.add(ChatColor.DARK_PURPLE + "4 crits" + ChatColor.GRAY + " → Slash obscur (8 blocs, Cécité 4s)");
        meta.setLore(lore);
        sword.setItemMeta(meta);
        return sword;
    }

    public ItemStack buildPaleSheen() {
        ItemStack sword = new ItemStack(Material.DIAMOND_SWORD);
        ItemMeta meta = sword.getItemMeta();
        meta.setDisplayName(ChatColor.WHITE + "" + ChatColor.BOLD + "Pale Sheen");
        meta.addEnchant(Enchantment.DAMAGE_ALL, 3, true);
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "✦ " + ChatColor.GOLD + "Goldsheen" + ChatColor.GRAY + " + " + ChatColor.DARK_PURPLE + "Netherlight" + ChatColor.GRAY + " ✦");
        lore.add(ChatColor.GRAY + "Fusion complète !");
        lore.add("");
        lore.add(ChatColor.GOLD + "Crit" + ChatColor.GRAY + " → Vitesse 5s + Cristallisation");
        lore.add(ChatColor.DARK_PURPLE + "4 crits" + ChatColor.GRAY + " → Slash obscur (8 blocs, Cécité 4s)");
        meta.setLore(lore);
        sword.setItemMeta(meta);
        return sword;
    }

    public ItemStack buildGravityZero(Player player) {
        UUID uuid = player.getUniqueId();
        int charges = gravityCharges.getOrDefault(uuid, 5);
        ItemStack item = new ItemStack(Material.NETHER_STAR);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.AQUA + "Gravity Zero");
        List<String> lore = new ArrayList<>();
        lore.add(buildChargeBar(charges, 5, ChatColor.AQUA));
        lore.add(ChatColor.GRAY + "Charges : " + ChatColor.AQUA + charges + "/5");
        lore.add(ChatColor.GRAY + "(Régén. toutes les 15s)");
        lore.add("");
        lore.add(ChatColor.AQUA + "Clic Droit" + ChatColor.GRAY + " → Bond de 20 blocs");
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Méthodes publiques appelées par le listener
    // ════════════════════════════════════════════════════════════════════════

    public void onHit(Player sunraku, Player victim, boolean isCrit, boolean isGoldsheen, boolean isNetherlight) {
        UUID uuid = sunraku.getUniqueId();

        if (paradeBonus.getOrDefault(uuid, false)) {
            paradeBonus.put(uuid, false);
            sunraku.sendMessage(ChatColor.YELLOW + "✦ Bonus de Parade appliqué ! (+50% dégâts)");
        }

        if (!isCrit) return;

        boolean fusion = fusionActive.getOrDefault(uuid, false);

        if (isGoldsheen || fusion) {
            applyGoldsheenEffects(sunraku, victim);
            if (!fusion) incrementGoldsheenGauge(sunraku);
        }

        if (isNetherlight || fusion) {
            incrementNetherlight(sunraku);
            if (!fusion) incrementNetherightGauge(sunraku);
        }

        if (!fusion) checkFusion(sunraku);

        refreshSwords(sunraku);
    }

    public double getParadeMultiplier(Player player) {
        return paradeBonus.getOrDefault(player.getUniqueId(), false) ? 1.5 : 1.0;
    }

    public void onStartBlock(Player player) {
        blockStart.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public boolean tryParade(Player sunraku) {
        UUID uuid = sunraku.getUniqueId();
        if (!sunraku.isBlocking()) return false;

        long now = System.currentTimeMillis();
        long cd = paradeCooldown.getOrDefault(uuid, 0L);
        if (now - cd < 10_000L) return false;

        long start = blockStart.getOrDefault(uuid, 0L);
        if (start == 0L) return false;

        long elapsed = now - start;
        if (elapsed < 1000L) {
            paradeCooldown.put(uuid, now);
            paradeBonus.put(uuid, true);
            blockStart.remove(uuid);
            sunraku.sendMessage(ChatColor.GREEN + "✦ Parade Parfaite ! Prochain coup +50%");
            sunraku.playSound(sunraku.getLocation(), Sound.ANVIL_LAND, 0.5f, 2.0f);
            return true;
        }
        return false;
    }

    public void triggerGravityZero(Player player) {
        UUID uuid = player.getUniqueId();
        int charges = gravityCharges.getOrDefault(uuid, 0);

        if (charges <= 0) {
            player.sendMessage(ChatColor.RED + "Pas de charges disponibles !");
            return;
        }

        gravityCharges.put(uuid, charges - 1);

        org.bukkit.util.Vector dir = player.getLocation().getDirection().normalize().multiply(2.0);
        dir.setY(Math.max(dir.getY(), 0.6));
        player.setVelocity(dir);
        player.playSound(player.getLocation(), Sound.ENDERMAN_TELEPORT, 1f, 1.2f);

        refreshGravityZeroItem(player);
        updateActionBarNow(player);
    }

    public boolean isGoldsheenItem(ItemStack item) {
        if (item == null || item.getType() != Material.DIAMOND_SWORD) return false;
        if (!item.hasItemMeta() || !item.getItemMeta().hasDisplayName()) return false;
        return item.getItemMeta().getDisplayName().contains("Goldsheen");
    }

    public boolean isNetherightItem(ItemStack item) {
        if (item == null || item.getType() != Material.DIAMOND_SWORD) return false;
        if (!item.hasItemMeta() || !item.getItemMeta().hasDisplayName()) return false;
        return item.getItemMeta().getDisplayName().contains("Netherlight");
    }

    public boolean isPaleSheenItem(ItemStack item) {
        if (item == null || item.getType() != Material.DIAMOND_SWORD) return false;
        if (!item.hasItemMeta() || !item.getItemMeta().hasDisplayName()) return false;
        return item.getItemMeta().getDisplayName().contains("Pale Sheen");
    }

    public boolean isGravityZeroItem(ItemStack item) {
        if (item == null || item.getType() != Material.NETHER_STAR) return false;
        if (!item.hasItemMeta() || !item.getItemMeta().hasDisplayName()) return false;
        return item.getItemMeta().getDisplayName().contains("Gravity Zero");
    }

    public boolean isFused(Player player) {
        return fusionActive.getOrDefault(player.getUniqueId(), false);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Effets des lames
    // ════════════════════════════════════════════════════════════════════════

    private void applyGoldsheenEffects(Player sunraku, Player victim) {
        sunraku.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, 0, false, false), true);
        crystallizeRandomSlot(victim);
    }

    private void crystallizeRandomSlot(Player victim) {
        UUID vUuid = victim.getUniqueId();

        if (crystalSlot.containsKey(vUuid)) return;

        List<Integer> eligible = new ArrayList<>();
        for (int i = 0; i < 9; i++) {
            ItemStack item = victim.getInventory().getItem(i);
            if (item == null || item.getType() == Material.AIR) continue;
            Material type = item.getType();
            if (isSword(type)) continue;
            if (type == Material.WATER_BUCKET || type == Material.POTION) continue;
            if (type == Material.APPLE || type == Material.GOLDEN_APPLE || type == Material.GOLDEN_CARROT) continue;
            eligible.add(i);
        }
        if (eligible.isEmpty()) return;

        int slot = eligible.get(new Random().nextInt(eligible.size()));
        ItemStack saved = victim.getInventory().getItem(slot).clone();
        crystalSlot.put(vUuid, slot);
        crystalSaved.put(vUuid, saved);

        ItemStack ice = new ItemStack(Material.ICE);
        ItemMeta meta = ice.getItemMeta();
        meta.setDisplayName(ChatColor.AQUA + "❄ Cristallisé");
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "Slot gelé pendant 10s");
        meta.setLore(lore);
        ice.setItemMeta(meta);
        victim.getInventory().setItem(slot, ice);
        victim.sendMessage(ChatColor.AQUA + "❄ Un de tes slots a été cristallisé !");

        BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                restoreCrystalSlot(victim);
            }
        }.runTaskLater(plugin, 200L);
        cancelTask(crystalTasks, vUuid);
        crystalTasks.put(vUuid, task);
    }

    private void restoreCrystalSlot(Player victim) {
        UUID vUuid = victim.getUniqueId();
        Integer slot = crystalSlot.remove(vUuid);
        ItemStack saved = crystalSaved.remove(vUuid);
        if (slot == null || saved == null) return;
        if (victim.isOnline()) {
            victim.getInventory().setItem(slot, saved);
            victim.sendMessage(ChatColor.GRAY + "❄ Cristallisation terminée.");
        }
        cancelTask(crystalTasks, vUuid);
    }

    private boolean isSword(Material mat) {
        return mat == Material.DIAMOND_SWORD || mat == Material.IRON_SWORD
                || mat == Material.STONE_SWORD || mat == Material.WOOD_SWORD
                || mat == Material.GOLD_SWORD;
    }

    private void incrementNetherlight(Player player) {
        UUID uuid = player.getUniqueId();
        int crits = netherlightCrits.getOrDefault(uuid, 0) + 1;

        if (crits >= 4) {
            crits = 0;
            triggerNetherlightSlash(player);
        }
        netherlightCrits.put(uuid, crits);
    }

    private void triggerNetherlightSlash(Player player) {
        org.bukkit.util.Vector dir = player.getLocation().getDirection().normalize();
        org.bukkit.Location loc = player.getLocation().clone().add(0, 1, 0);

        Player target = null;
        double closest = 8.0;

        for (Player online : plugin.getServer().getOnlinePlayers()) {
            if (online.equals(player)) continue;
            if (!plugin.getRoleManager().hasRole(online)) continue;

            org.bukkit.util.Vector toTarget = online.getLocation().clone().add(0, 1, 0).toVector()
                    .subtract(loc.toVector());
            double dist = toTarget.length();
            if (dist > 8.0) continue;

            double dot = toTarget.normalize().dot(dir);
            if (dot < 0.75) continue;

            if (dist < closest) {
                closest = dist;
                target = online;
            }
        }

        if (target == null) {
            player.sendMessage(ChatColor.GRAY + "Aucune cible dans le slash...");
            return;
        }

        final Player finalTarget = target;
        final org.bukkit.Location start = loc.clone();
        final double finalClosest = closest; // ← FIX : variable finale pour le BukkitRunnable

        new BukkitRunnable() {
            double travelled = 0;
            @Override
            public void run() {
                if (travelled >= finalClosest) { // ← FIX : utilise finalClosest au lieu de closest
                    cancel();
                    return;
                }
                org.bukkit.Location pLoc = start.clone().add(dir.clone().multiply(travelled));
                pLoc.getWorld().playEffect(pLoc, org.bukkit.Effect.COLOURED_DUST, 0x8A2BE2);
                travelled += 0.5;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        finalTarget.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 80, 0, false, false), true);
        finalTarget.sendMessage(ChatColor.DARK_PURPLE + "⚔ Tu as été touché par le Slash Obscur !");
        finalTarget.playSound(finalTarget.getLocation(), Sound.WITHER_HURT, 1f, 0.8f);
        player.sendMessage(ChatColor.DARK_PURPLE + "⚔ Slash Obscur déclenché sur " + finalTarget.getName() + " !");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Jauge de fusion
    // ════════════════════════════════════════════════════════════════════════

    private void incrementGoldsheenGauge(Player player) {
        UUID uuid = player.getUniqueId();
        int g = goldsheenGauge.getOrDefault(uuid, 0);
        if (g < 10) goldsheenGauge.put(uuid, g + 1);
    }

    private void incrementNetherightGauge(Player player) {
        UUID uuid = player.getUniqueId();
        int g = netherlightGauge.getOrDefault(uuid, 0);
        if (g < 10) netherlightGauge.put(uuid, g + 1);
    }

    private void checkFusion(Player player) {
        UUID uuid = player.getUniqueId();
        int g = goldsheenGauge.getOrDefault(uuid, 0);
        int n = netherlightGauge.getOrDefault(uuid, 0);

        if (g >= 10 && n >= 10 && !fusionActive.getOrDefault(uuid, false)) {
            triggerFusion(player);
        }
    }

    private void triggerFusion(Player player) {
        UUID uuid = player.getUniqueId();
        fusionActive.put(uuid, true);

        player.getInventory().setItem(0, buildPaleSheen());
        player.getInventory().setItem(1, null);

        player.sendMessage(ChatColor.WHITE + "" + ChatColor.BOLD + "✦ FUSION ✦ " + ChatColor.RESET
                + ChatColor.GRAY + "Goldsheen & Netherlight fusionnent en "
                + ChatColor.WHITE + ChatColor.BOLD + "Pale Sheen" + ChatColor.RESET + " !");
        player.playSound(player.getLocation(), Sound.LEVEL_UP, 1f, 0.5f);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Gravity Zero – régénération de charges
    // ════════════════════════════════════════════════════════════════════════

    private void startChargeRegen(Player player) {
        UUID uuid = player.getUniqueId();
        cancelTask(chargeRegenTask, uuid);

        BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline()) { cancel(); return; }
                int charges = gravityCharges.getOrDefault(uuid, 5);
                if (charges < 5) {
                    gravityCharges.put(uuid, charges + 1);
                    player.sendMessage(ChatColor.AQUA + "✦ Gravity Zero : charge rechargée ! ("
                            + (charges + 1) + "/5)");
                    refreshGravityZeroItem(player);
                }
            }
        }.runTaskTimer(plugin, 300L, 300L);
        chargeRegenTask.put(uuid, task);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Action Bar
    // ════════════════════════════════════════════════════════════════════════

    private void startActionBar(Player player) {
        UUID uuid = player.getUniqueId();
        cancelTask(actionBarTask, uuid);

        BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline()) { cancel(); return; }
                updateActionBarNow(player);
            }
        }.runTaskTimer(plugin, 0L, 10L);
        actionBarTask.put(uuid, task);
    }

    public void updateActionBarNow(Player player) {
        UUID uuid = player.getUniqueId();
        ItemStack held = player.getItemInHand();
        boolean fusion = fusionActive.getOrDefault(uuid, false);

        String bar;

        if (isGravityZeroItem(held)) {
            int charges = gravityCharges.getOrDefault(uuid, 0);
            bar = buildGravityBar(charges);
        } else if (isGoldsheenItem(held)) {
            int gauge = goldsheenGauge.getOrDefault(uuid, 0);
            bar = ChatColor.GOLD + "Goldsheen  " + buildGaugeBar(gauge, ChatColor.GOLD)
                    + ChatColor.GRAY + "  " + (gauge * 5) + "%" + "/50%";
        } else if (isNetherightItem(held)) {
            int gauge = netherlightGauge.getOrDefault(uuid, 0);
            int crits = netherlightCrits.getOrDefault(uuid, 0);
            bar = ChatColor.DARK_PURPLE + "Netherlight  " + buildGaugeBar(gauge, ChatColor.DARK_PURPLE)
                    + ChatColor.GRAY + "  " + (gauge * 5) + "%/50%"
                    + "  " + ChatColor.LIGHT_PURPLE + crits + "/4 crits";
        } else if (isPaleSheenItem(held) && fusion) {
            int crits = netherlightCrits.getOrDefault(uuid, 0);
            bar = ChatColor.WHITE + "" + ChatColor.BOLD + "✦ Pale Sheen ✦"
                    + ChatColor.RESET + ChatColor.GRAY + "  " + ChatColor.DARK_PURPLE + crits + "/4 crits";
        } else {
            int gG = goldsheenGauge.getOrDefault(uuid, 0);
            int gN = netherlightGauge.getOrDefault(uuid, 0);
            int charges = gravityCharges.getOrDefault(uuid, 0);
            if (fusion) {
                bar = ChatColor.WHITE + "" + ChatColor.BOLD + "✦ Pale Sheen"
                        + ChatColor.RESET + ChatColor.GRAY + "  ✦Fusion active✦"
                        + "  " + ChatColor.AQUA + "⬆ " + charges + "/5";
            } else {
                bar = ChatColor.GOLD + "G " + buildMiniBar(gG, ChatColor.GOLD)
                        + ChatColor.GRAY + "  "
                        + ChatColor.DARK_PURPLE + "N " + buildMiniBar(gN, ChatColor.DARK_PURPLE)
                        + ChatColor.GRAY + "  "
                        + ChatColor.AQUA + "⬆ " + charges + "/5";
            }
        }

        TitleUtils.sendActionBar(player, bar);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Refresh items
    // ════════════════════════════════════════════════════════════════════════

    public void refreshSwords(Player player) {
        if (fusionActive.getOrDefault(player.getUniqueId(), false)) return;

        for (int i = 0; i < 36; i++) {
            ItemStack item = player.getInventory().getItem(i);
            if (isGoldsheenItem(item)) {
                player.getInventory().setItem(i, buildGoldsheen(player));
            } else if (isNetherightItem(item)) {
                player.getInventory().setItem(i, buildNetherlight(player));
            }
        }
    }

    public void refreshGravityZeroItem(Player player) {
        for (int i = 0; i < 9; i++) {
            ItemStack item = player.getInventory().getItem(i);
            if (isGravityZeroItem(item)) {
                player.getInventory().setItem(i, buildGravityZero(player));
                return;
            }
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Builders de barres
    // ════════════════════════════════════════════════════════════════════════

    private String buildGaugeBar(int gauge, ChatColor color) {
        StringBuilder sb = new StringBuilder();
        sb.append(ChatColor.GRAY).append("[");
        for (int i = 0; i < 10; i++) {
            if (i < gauge) sb.append(color).append("█");
            else           sb.append(ChatColor.DARK_GRAY).append("░");
        }
        sb.append(ChatColor.GRAY).append("]");
        return sb.toString();
    }

    private String buildMiniBar(int gauge, ChatColor color) {
        StringBuilder sb = new StringBuilder();
        int filled = gauge / 2;
        for (int i = 0; i < 5; i++) {
            if (i < filled) sb.append(color).append("█");
            else            sb.append(ChatColor.DARK_GRAY).append("░");
        }
        return sb.toString();
    }

    private String buildChargeBar(int charges, int max, ChatColor color) {
        StringBuilder sb = new StringBuilder();
        sb.append(ChatColor.GRAY).append("[");
        for (int i = 0; i < max; i++) {
            if (i < charges) sb.append(color).append("⬆");
            else             sb.append(ChatColor.DARK_GRAY).append("⬆");
        }
        sb.append(ChatColor.GRAY).append("]");
        return sb.toString();
    }

    private String buildGravityBar(int charges) {
        StringBuilder sb = new StringBuilder();
        sb.append(ChatColor.AQUA).append("Gravity Zero  ");
        sb.append(ChatColor.GRAY).append("[");
        for (int i = 0; i < 5; i++) {
            if (i < charges) sb.append(ChatColor.AQUA).append("⬆");
            else             sb.append(ChatColor.DARK_GRAY).append("⬆");
        }
        sb.append(ChatColor.GRAY).append("]");
        sb.append(ChatColor.GRAY).append("  ").append(ChatColor.AQUA).append(charges).append("/5");
        return sb.toString();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Utilitaires
    // ════════════════════════════════════════════════════════════════════════

    private void cancelTask(Map<UUID, BukkitTask> map, UUID uuid) {
        BukkitTask t = map.remove(uuid);
        if (t != null) t.cancel();
    }
}