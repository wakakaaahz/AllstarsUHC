package fr.wakakaaa.roles;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.wrappers.WrappedDataWatcher;
import fr.wakakaaa.Main;
import fr.wakakaaa.utils.TitleUtils;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Effect;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

public class TengenRole implements Role {

    private final Main plugin;

    private final Map<UUID, Map<UUID, Integer>> hitCounts   = new HashMap<>();
    private final Map<UUID, Integer>            victimNotes = new HashMap<>();
    private final Map<UUID, UUID>               lastVictimMap    = new HashMap<>();
    private final Map<UUID, Integer>            lastHitsOnVictim = new HashMap<>();
    private final Map<UUID, Long>               echoCooldown = new HashMap<>();
    private final Map<UUID, Boolean>            echoActive   = new HashMap<>();
    private final Map<UUID, BukkitTask>         echoTask     = new HashMap<>();
    private final Map<UUID, BukkitTask>         passifTask    = new HashMap<>();
    private final Map<UUID, BukkitTask>         actionBarTask = new HashMap<>();

    private static final String[] NOTE_NAMES = {
            ChatColor.GREEN + "Do",
            ChatColor.GOLD  + "Ré",
            ChatColor.RED   + "Mi"
    };

    public TengenRole(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getName() { return "Tengen"; }

    @Override
    public String getDescription() { return "Le Pilier du Son !"; }

    @Override
    public void applyRole(Player player) {
        UUID uuid = player.getUniqueId();
        hitCounts.put(uuid, new HashMap<>());
        echoCooldown.put(uuid, 0L);
        echoActive.put(uuid, false);
        player.sendMessage(ChatColor.YELLOW + "Tu es " + ChatColor.GOLD + "Tengen Uzui" + ChatColor.YELLOW + " !");
        player.sendMessage(ChatColor.GRAY + "Flamboyant !");
        giveItems(player);
        startPassifNinja(player);
        startPartitionMusicale(player);
        startActionBar(player);
    }

    @Override
    public void removeRole(Player player) {
        UUID uuid = player.getUniqueId();
        cancelTask(passifTask, uuid);
        cancelTask(actionBarTask, uuid);
        cancelTask(echoTask, uuid);
        // Désactiver le glowing sur tous les joueurs
        for (Player target : Bukkit.getOnlinePlayers()) {
            if (!target.equals(player)) sendGlowPacket(player, target, false);
        }
        hitCounts.remove(uuid);
        echoCooldown.remove(uuid);
        echoActive.remove(uuid);
        lastVictimMap.remove(uuid);
        lastHitsOnVictim.remove(uuid);
    }

    @Override
    public void onAbility(Player player) {}

    // ════════════════════════════════════════════════════════════════════════
    //  Items
    // ════════════════════════════════════════════════════════════════════════

    private void giveItems(Player player) {
        ItemStack sword = new ItemStack(Material.DIAMOND_SWORD);
        ItemMeta swordMeta = sword.getItemMeta();
        swordMeta.setDisplayName(ChatColor.YELLOW + "Kris de Tengen");
        List<String> swordLore = new ArrayList<>();
        swordLore.add(ChatColor.GRAY + "5 coups → Note musicale");
        swordMeta.setLore(swordLore);
        sword.setItemMeta(swordMeta);
        sword.addEnchantment(Enchantment.DAMAGE_ALL, 3);
        player.getInventory().setItem(0, sword);
        player.getInventory().setItem(1, buildEchoItem(player));
    }

    public ItemStack buildEchoItem(Player player) {
        UUID uuid = player.getUniqueId();
        long now = System.currentTimeMillis();
        long lastUse = echoCooldown.getOrDefault(uuid, 0L);
        long cdLeft = Math.max(0, 45000 - (now - lastUse)) / 1000;
        ItemStack item = new ItemStack(Material.NETHER_STAR);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.AQUA + "Écho");
        List<String> lore = new ArrayList<>();
        lore.add(cdLeft > 0 ? ChatColor.RED + "Cooldown : " + cdLeft + "s" : ChatColor.GREEN + "Prêt !");
        lore.add("");
        lore.add(ChatColor.GRAY + "Clic-Droit → Propulsion 3s");
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    public void refreshEchoItem(Player player) {
        for (int i = 0; i < 9; i++) {
            ItemStack item = player.getInventory().getItem(i);
            if (isEchoItem(item)) { player.getInventory().setItem(i, buildEchoItem(player)); return; }
        }
    }

    public boolean isKrisSword(ItemStack item) {
        if (item == null || item.getType() != Material.DIAMOND_SWORD) return false;
        if (!item.hasItemMeta() || !item.getItemMeta().hasDisplayName()) return false;
        return item.getItemMeta().getDisplayName().contains("Kris");
    }

    public boolean isEchoItem(ItemStack item) {
        if (item == null || item.getType() != Material.NETHER_STAR) return false;
        if (!item.hasItemMeta() || !item.getItemMeta().hasDisplayName()) return false;
        return item.getItemMeta().getDisplayName().contains("Écho");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Passif 1 — Ninja
    // ════════════════════════════════════════════════════════════════════════

    private void startPassifNinja(Player player) {
        UUID uuid = player.getUniqueId();
        cancelTask(passifTask, uuid);
        BukkitTask task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            if (!player.isOnline()) return;
            if (player.hasPotionEffect(PotionEffectType.POISON)) player.removePotionEffect(PotionEffectType.POISON);
            if (player.hasPotionEffect(PotionEffectType.WITHER)) player.removePotionEffect(PotionEffectType.WITHER);
        }, 0L, 5L);
        passifTask.put(uuid, task);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Passif 2 — Partition Musicale
    //  Les couleurs de nametag sont gérées par CampManager.applyTeamsToBoard
    //  qui applique les prefixes de vie (vert/orange/rouge) sur le scoreboard
    //  du ScoreboardManager quand le destinataire est Tengen.
    //  Ici on gère uniquement le packet de glowing.
    // ════════════════════════════════════════════════════════════════════════

    private void startPartitionMusicale(Player player) {
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            if (!player.isOnline()) return;
            for (Player target : Bukkit.getOnlinePlayers()) {
                if (target.equals(player)) continue;
                sendGlowPacket(player, target, true);
            }
        }, 0L, 20L);
    }

    private void sendGlowPacket(Player receiver, Player target, boolean glow) {
        try {
            ProtocolManager manager = ProtocolLibrary.getProtocolManager();
            PacketContainer packet = manager.createPacket(PacketType.Play.Server.ENTITY_METADATA);
            packet.getIntegers().write(0, target.getEntityId());
            WrappedDataWatcher watcher = new WrappedDataWatcher();
            WrappedDataWatcher.Serializer serializer = WrappedDataWatcher.Registry.get(Byte.class);
            watcher.setEntity(target);
            watcher.setObject(0, serializer, glow ? (byte) 0x40 : (byte) 0x00);
            packet.getWatchableCollectionModifier().write(0, watcher.getWatchableObjects());
            manager.sendServerPacket(receiver, packet);
        } catch (Exception e) { /* ignore */ }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Passif 3 — Souffle du Son
    // ════════════════════════════════════════════════════════════════════════

    public void onHit(Player tengen, Player victim) {
        UUID tengenUUID = tengen.getUniqueId();
        UUID victimUUID = victim.getUniqueId();
        Map<UUID, Integer> counts = hitCounts.computeIfAbsent(tengenUUID, k -> new HashMap<>());
        int hits = counts.getOrDefault(victimUUID, 0) + 1;
        if (hits >= 5) {
            counts.put(victimUUID, 0);
            applyNote(tengen, victim);
        } else {
            counts.put(victimUUID, hits);
        }
        lastVictimMap.put(tengenUUID, victimUUID);
        lastHitsOnVictim.put(tengenUUID, counts.getOrDefault(victimUUID, 0));
    }

    private void applyNote(Player tengen, Player victim) {
        UUID victimUUID = victim.getUniqueId();
        int note = victimNotes.getOrDefault(victimUUID, 0);
        switch (note) {
            case 0:
                tengen.sendMessage(ChatColor.GREEN + "♪ Do ! " + victim.getName());
                victim.sendMessage(ChatColor.GREEN + "♪ Do !");
                spawnFireworkParticles(victim, ChatColor.GREEN);
                freezeSlot(victim);
                victimNotes.put(victimUUID, 1);
                break;
            case 1:
                tengen.sendMessage(ChatColor.GOLD + "♪ Ré ! " + victim.getName());
                victim.sendMessage(ChatColor.GOLD + "♪ Ré !");
                spawnFireworkParticles(victim, ChatColor.GOLD);
                immobilize(victim, 20);
                victimNotes.put(victimUUID, 2);
                break;
            case 2:
                tengen.sendMessage(ChatColor.RED + "♪ Mi ! " + victim.getName());
                victim.sendMessage(ChatColor.RED + "♪ Mi !");
                spawnFireworkParticles(victim, ChatColor.RED);
                double newHealth = Math.max(0, victim.getHealth() - 2.0);
                victim.setHealth(newHealth);
                victim.damage(0.001, tengen);
                victim.addPotionEffect(new PotionEffect(PotionEffectType.CONFUSION, 20 * 10, 0, false, false), true);
                victimNotes.put(victimUUID, 0);
                tengen.sendMessage(ChatColor.GRAY + "Notes de " + victim.getName() + " réinitialisées !");
                break;
        }
    }

    private void spawnFireworkParticles(Player victim, ChatColor color) {
        int effectColor;
        switch (color.name()) {
            case "GREEN": effectColor = 13; break;
            case "GOLD":  effectColor = 4;  break;
            case "RED":   effectColor = 14; break;
            default:      effectColor = 15; break;
        }
        for (int i = 0; i < 12; i++) {
            victim.getLocation().clone().add(
                    (Math.random() - 0.5) * 1.5, 1.5 + Math.random(), (Math.random() - 0.5) * 1.5
            ).getWorld().playEffect(
                    victim.getLocation().clone().add(
                            (Math.random() - 0.5) * 1.5, 1.5 + Math.random(), (Math.random() - 0.5) * 1.5),
                    Effect.COLOURED_DUST, effectColor);
        }
        victim.playSound(victim.getLocation(), Sound.FIREWORK_BLAST, 1f, 1f);
    }

    private void freezeSlot(Player player) {
        int frozenSlot = player.getInventory().getHeldItemSlot();
        BukkitTask[] task = new BukkitTask[1];
        task[0] = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            if (!player.isOnline()) { task[0].cancel(); return; }
            player.getInventory().setHeldItemSlot(frozenSlot);
        }, 0L, 1L);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> task[0].cancel(), 30L);
    }

    private void immobilize(Player player, int ticks) {
        org.bukkit.Location frozenLoc = player.getLocation().clone();
        BukkitTask[] task = new BukkitTask[1];
        task[0] = plugin.getServer().getScheduler().runTaskTimer(plugin, new Runnable() {
            int elapsed = 0;
            @Override
            public void run() {
                if (!player.isOnline() || elapsed >= ticks) { task[0].cancel(); return; }
                org.bukkit.Location current = player.getLocation();
                frozenLoc.setYaw(current.getYaw());
                frozenLoc.setPitch(current.getPitch());
                player.teleport(frozenLoc);
                elapsed++;
            }
        }, 0L, 1L);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Capacité — Écho
    // ════════════════════════════════════════════════════════════════════════

    public void triggerEcho(Player player) {
        UUID uuid = player.getUniqueId();
        long now = System.currentTimeMillis();
        long lastUse = echoCooldown.getOrDefault(uuid, 0L);
        if (now - lastUse < 45000) {
            long left = (45000 - (now - lastUse)) / 1000;
            player.sendMessage(ChatColor.RED + "Cooldown Écho ! Encore " + left + "s");
            return;
        }
        if (echoActive.getOrDefault(uuid, false)) return;
        echoCooldown.put(uuid, now);
        echoActive.put(uuid, true);
        player.sendMessage(ChatColor.AQUA + "✦ Écho activé !");
        player.playSound(player.getLocation(), Sound.NOTE_BASS_GUITAR, 1f, 1.5f);
        cancelTask(echoTask, uuid);
        BukkitTask task = new BukkitRunnable() {
            int ticks = 0;
            final Set<UUID> alreadyHit = new HashSet<>();
            @Override
            public void run() {
                if (ticks >= 60 || !player.isOnline()) {
                    echoActive.put(uuid, false);
                    refreshEchoItem(player);
                    cancel();
                    return;
                }
                org.bukkit.util.Vector dir = player.getEyeLocation().getDirection().normalize().multiply(1.2);
                dir.setY(Math.max(dir.getY(), 0.1));
                player.setVelocity(dir);
                org.bukkit.Location loc = player.getLocation().clone().add(0, 1, 0);
                loc.getWorld().playEffect(loc, Effect.COLOURED_DUST, 4);
                loc.getWorld().playEffect(loc.clone().add(0.5, 0, 0), Effect.COLOURED_DUST, 4);
                loc.getWorld().playEffect(loc.clone().add(-0.5, 0, 0), Effect.COLOURED_DUST, 4);
                loc.getWorld().playEffect(loc.clone().add(0, 0, 0.5), Effect.FIREWORKS_SPARK, 0);
                if (ticks % 10 == 0)
                    player.getWorld().playSound(player.getLocation(), Sound.FIREWORK_BLAST, 0.6f, 1.8f);
                for (Player nearby : Bukkit.getOnlinePlayers()) {
                    if (nearby.equals(player)) continue;
                    if (alreadyHit.contains(nearby.getUniqueId())) continue;
                    if (nearby.getLocation().distance(player.getLocation()) < 2.0) {
                        alreadyHit.add(nearby.getUniqueId());
                        applyEchoHit(player, nearby);
                    }
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        echoTask.put(uuid, task);
    }

    private void applyEchoHit(Player tengen, Player victim) {
        double newHealth = Math.max(0, victim.getHealth() - 2.0);
        victim.setHealth(newHealth);
        victim.damage(0.001, tengen);
        victim.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 30, 0, false, false), true);
        victim.sendMessage(ChatColor.AQUA + "✦ Tu as été frappé par l'Écho !");
        victim.playSound(victim.getLocation(), Sound.NOTE_PLING, 1f, 0.5f);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Action Bar
    // ════════════════════════════════════════════════════════════════════════

    private void startActionBar(Player player) {
        UUID uuid = player.getUniqueId();
        cancelTask(actionBarTask, uuid);
        BukkitTask task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            if (!player.isOnline()) return;
            if (isEchoItem(player.getItemInHand())) updateActionBarEcho(player);
            else updateActionBarHits(player);
        }, 0L, 10L);
        actionBarTask.put(uuid, task);
    }

    private void updateActionBarEcho(Player tengen) {
        UUID uuid = tengen.getUniqueId();
        long now = System.currentTimeMillis();
        long cdLeft = Math.max(0, 45000 - (now - echoCooldown.getOrDefault(uuid, 0L))) / 1000;
        StringBuilder bar = new StringBuilder();
        bar.append(ChatColor.AQUA).append("Écho ");
        if (echoActive.getOrDefault(uuid, false)) bar.append(ChatColor.YELLOW).append("⚡ Actif");
        else if (cdLeft == 0) bar.append(ChatColor.GREEN).append("✔ Prêt");
        else bar.append(ChatColor.RED).append(cdLeft).append("s");
        TitleUtils.sendActionBar(tengen, bar.toString());
    }

    private void updateActionBarHits(Player tengen) {
        UUID uuid = tengen.getUniqueId();
        StringBuilder bar = new StringBuilder();
        UUID victimUUID = lastVictimMap.get(uuid);
        if (victimUUID != null) {
            Player victim = Bukkit.getPlayer(victimUUID);
            if (victim != null && victim.isOnline()) {
                int hits = lastHitsOnVictim.getOrDefault(uuid, 0);
                int note = victimNotes.getOrDefault(victimUUID, 0);
                bar.append(ChatColor.YELLOW).append(victim.getName())
                        .append(ChatColor.GRAY).append(" ").append(buildHitBar(hits))
                        .append(ChatColor.GRAY).append(" ").append(NOTE_NAMES[note]);
            }
        } else {
            long now = System.currentTimeMillis();
            long cdLeft = Math.max(0, 45000 - (now - echoCooldown.getOrDefault(uuid, 0L))) / 1000;
            bar.append(ChatColor.AQUA).append("Écho ");
            bar.append(cdLeft == 0 ? ChatColor.GREEN + "✔ Prêt" : ChatColor.RED + "" + cdLeft + "s");
        }
        TitleUtils.sendActionBar(tengen, bar.toString());
    }

    public void updateActionBarNow(Player tengen, Player lastVictim, int hitsOnVictim) {}

    private String buildHitBar(int hits) {
        StringBuilder sb = new StringBuilder();
        sb.append(ChatColor.GRAY).append("[");
        for (int i = 0; i < 5; i++) {
            if (i < hits) sb.append(ChatColor.YELLOW).append("█");
            else sb.append(ChatColor.DARK_GRAY).append("░");
        }
        sb.append(ChatColor.GRAY).append("]");
        return sb.toString();
    }

    private void cancelTask(Map<UUID, BukkitTask> map, UUID uuid) {
        BukkitTask t = map.remove(uuid);
        if (t != null) t.cancel();
    }
}