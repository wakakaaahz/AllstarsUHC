package fr.wakakaaa.roles;

import org.bukkit.entity.Player;

public interface Role {

    String getName();
    String getDescription();
    void applyRole(Player player);
    void removeRole(Player player);
    void onAbility(Player player);
}