package fr.wakakaaa.roles;

import fr.wakakaaa.Main;
import fr.wakakaaa.utils.TitleUtils;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.Vector;

import java.util.*;

public class StainRole implements Role {

    private Main plugin;

    private static Map<UUID, String> bloodGroups = new HashMap<>();

    private Map<UUID, Integer> daggerCharges = new HashMap<>();
    private Map<UUID, Integer> knifeCharges = new HashMap<>();
    private Map<UUID, Integer> katanaCharges = new HashMap<>();

    private Map<UUID, Long> daggerCooldown = new HashMap<>();
    private Map<UUID, Long> knifeCooldown = new HashMap<>();
    private Map<UUID, Long> katanaCooldown = new HashMap<>();

    private Map<UUID, Integer> selectedWeapon = new HashMap<>();

    private Map<UUID, Long> coagulationCooldown = new HashMap<>();
    private Map<UUID, Long> lastHitTime = new HashMap<>();

    private Map<UUID, Double> coagulatedPlayers = new HashMap<>();
    private Map<UUID, BukkitTask> coagulationTasks = new HashMap<>();
    private Map<UUID, BukkitTask> bleedingTasks = new HashMap<>();

    public StainRole() {
        this.plugin = Main.getInstance();
    }

    @Override
    public String getName() { return "Stain"; }

    @Override
    public String getDescription() { return "Le chasseur de héros !"; }

    public static void distributeBloodGroups(List<Player> players) {
        bloodGroups.clear();
        String[] groups = {"O", "A", "AB", "B"};
        List<Player> shuffled = new ArrayList<>(players);
        Collections.shuffle(shuffled);
        for (int i = 0; i < shuffled.size(); i++) {
            bloodGroups.put(shuffled.get(i).getUniqueId(), groups[i % 4]);
        }
    }

    public static String getBloodGroup(Player player) {
        return bloodGroups.getOrDefault(player.getUniqueId(), "O");
    }

    public static void setBloodGroup(Player player, String group) {
        bloodGroups.put(player.getUniqueId(), group);
    }

    @Override
    public void applyRole(Player player) {
        player.sendMessage(ChatColor.DARK_RED + "Tu es " + ChatColor.RED + "Stain !");
        player.sendMessage(ChatColor.DARK_RED + getDescription());
        daggerCharges.put(player.getUniqueId(), 2);
        knifeCharges.put(player.getUniqueId(), 2);
        katanaCharges.put(player.getUniqueId(), 2);
        selectedWeapon.put(player.getUniqueId(), 0);
        coagulationCooldown.put(player.getUniqueId(), 0L);
        giveItems(player);
        startNametaskDisplay(player);
    }

    @Override
    public void removeRole(Player player) {
        daggerCharges.remove(player.getUniqueId());
        knifeCharges.remove(player.getUniqueId());
        katanaCharges.remove(player.getUniqueId());
        daggerCooldown.remove(player.getUniqueId());
        knifeCooldown.remove(player.getUniqueId());
        katanaCooldown.remove(player.getUniqueId());
        selectedWeapon.remove(player.getUniqueId());
        coagulationCooldown.remove(player.getUniqueId());
        for (UUID uuid : new HashSet<>(coagulationTasks.keySet())) {
            coagulationTasks.get(uuid).cancel();
        }
        coagulationTasks.clear();
        coagulatedPlayers.clear();
    }

    @Override
    public void onAbility(Player player) {}

    private void giveItems(Player player) {
        player.getInventory().setItem(0, buildArsenalItem(player));
        ItemStack coag = new ItemStack(Material.NETHER_STAR);
        ItemMeta meta = coag.getItemMeta();
        meta.setDisplayName(ChatColor.DARK_RED + "Coagulation");
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "Clic-Droit pour activer");
        lore.add(ChatColor.GRAY + "Cooldown: 90s");
        meta.setLore(lore);
        coag.setItemMeta(meta);
        player.getInventory().setItem(1, coag);
    }

    private ItemStack buildArsenalItem(Player player) {
        ItemStack item = new ItemStack(Material.STICK);
        ItemMeta meta = item.getItemMeta();
        int selected = selectedWeapon.getOrDefault(player.getUniqueId(), 0);
        long now = System.currentTimeMillis();
        meta.setDisplayName(ChatColor.DARK_RED + "Arsenal");
        List<String> lore = new ArrayList<>();
        int dc = daggerCharges.getOrDefault(player.getUniqueId(), 0);
        long dcd = Math.max(0, 30000 - (now - daggerCooldown.getOrDefault(player.getUniqueId(), 0L))) / 1000;
        lore.add((selected == 0 ? "§c§l▶ " : "§7") + "§cPoignard §7(" + dc + "/2)" + (dcd > 0 ? " §c(" + dcd + "s)" : " §a(Prêt)"));
        int kc = knifeCharges.getOrDefault(player.getUniqueId(), 0);
        long kcd = Math.max(0, 30000 - (now - knifeCooldown.getOrDefault(player.getUniqueId(), 0L))) / 1000;
        lore.add((selected == 1 ? "§c§l▶ " : "§7") + "§cCouteau de Lancer §7(" + kc + "/2)" + (kcd > 0 ? " §c(" + kcd + "s)" : " §a(Prêt)"));
        int katc = katanaCharges.getOrDefault(player.getUniqueId(), 0);
        long katcd = Math.max(0, 60000 - (now - katanaCooldown.getOrDefault(player.getUniqueId(), 0L))) / 1000;
        lore.add((selected == 2 ? "§c§l▶ " : "§7") + "§cKatana Usé §7(" + katc + "/2)" + (katcd > 0 ? " §c(" + katcd + "s)" : " §a(Prêt)"));
        lore.add("");
        lore.add("§7Clic-Gauche: Utiliser");
        lore.add("§7Clic-Droit: Changer d'arme");
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    public void refreshArsenalItem(Player player) {
        ItemStack item = player.getInventory().getItem(0);
        if (item != null && item.getType() == Material.STICK) {
            player.getInventory().setItem(0, buildArsenalItem(player));
        }
    }

    // ── NOUVEAU : retourne le nom de l'arme sélectionnée pour l'action bar ──
    public String getSelectedWeaponName(Player player) {
        int selected = selectedWeapon.getOrDefault(player.getUniqueId(), 0);
        switch (selected) {
            case 0: return ChatColor.DARK_RED + "Arme : " + ChatColor.RED + "✦ Poignard";
            case 1: return ChatColor.DARK_RED + "Arme : " + ChatColor.RED + "✦ Couteau de Lancer";
            case 2: return ChatColor.DARK_RED + "Arme : " + ChatColor.RED + "✦ Katana Usé";
            default: return ChatColor.DARK_RED + "Arsenal";
        }
    }

    public void onArsenalRightClick(Player player) {
        int current = selectedWeapon.getOrDefault(player.getUniqueId(), 0);
        int next = (current + 1) % 3;
        selectedWeapon.put(player.getUniqueId(), next);
        // Message en chat retiré — remplacé par l'action bar dans le listener
        refreshArsenalItem(player);
    }

    public void onArsenalLeftClick(Player player) {
        int selected = selectedWeapon.getOrDefault(player.getUniqueId(), 0);
        switch (selected) {
            case 0: usePoignard(player); break;
            case 1: useCouteau(player); break;
            case 2: useKatana(player); break;
        }
    }

    private Player getTargetPlayer(Player player, double maxDistance) {
        Location eyeLoc = player.getEyeLocation();
        Vector dir = eyeLoc.getDirection().normalize();
        Player closest = null;
        double closestDist = maxDistance;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.equals(player)) continue;
            Vector toP = p.getEyeLocation().subtract(eyeLoc).toVector();
            double dist = toP.length();
            if (dist > maxDistance) continue;
            double dot = toP.normalize().dot(dir);
            if (dot > 0.85) {
                if (dist < closestDist) {
                    closestDist = dist;
                    closest = p;
                }
            }
        }
        return closest;
    }

    private void usePoignard(Player player) {
        long now = System.currentTimeMillis();
        long cd = daggerCooldown.getOrDefault(player.getUniqueId(), 0L);
        if (now - cd < 30000) {
            player.sendMessage("§cCooldown Poignard ! Encore " + ((30000 - (now - cd)) / 1000) + "s");
            return;
        }
        int charges = daggerCharges.getOrDefault(player.getUniqueId(), 0);
        if (charges <= 0) {
            player.sendMessage("§cPlus de Poignards !");
            return;
        }
        Player target = getTargetPlayer(player, 6.0);
        if (target == null) {
            player.sendMessage("§cAucune cible !");
            return;
        }
        daggerCharges.put(player.getUniqueId(), charges - 1);
        daggerCooldown.put(player.getUniqueId(), now);
        refreshArsenalItem(player);
        player.sendMessage("§cPoignard utilisé sur " + target.getName() + " !");
        target.sendMessage("§cTu saignes !");

        if (bleedingTasks.containsKey(target.getUniqueId())) {
            bleedingTasks.get(target.getUniqueId()).cancel();
        }
        final Player finalTarget = target;
        BukkitTask[] bleedTaskHolder = new BukkitTask[1];
        bleedTaskHolder[0] = plugin.getServer().getScheduler().runTaskTimer(plugin, new Runnable() {
            int times = 0;
            @Override
            public void run() {
                if (!finalTarget.isOnline() || times >= 4) {
                    bleedingTasks.remove(finalTarget.getUniqueId());
                    bleedTaskHolder[0].cancel();
                    return;
                }
                double newHealth = Math.max(0.5, finalTarget.getHealth() - 1.0);
                finalTarget.setHealth(newHealth);
                finalTarget.sendMessage("§cTu saignes ! (-0,5❤)");
                times++;
            }
        }, 20L * 5, 20L * 5);
        bleedingTasks.put(target.getUniqueId(), bleedTaskHolder[0]);
        trackHit(target);
    }

    private void useCouteau(Player player) {
        long now = System.currentTimeMillis();
        long cd = knifeCooldown.getOrDefault(player.getUniqueId(), 0L);
        if (now - cd < 30000) {
            player.sendMessage("§cCooldown Couteau ! Encore " + ((30000 - (now - cd)) / 1000) + "s");
            return;
        }
        int charges = knifeCharges.getOrDefault(player.getUniqueId(), 0);
        if (charges <= 0) {
            player.sendMessage("§cPlus de Couteaux !");
            return;
        }
        knifeCharges.put(player.getUniqueId(), charges - 1);
        knifeCooldown.put(player.getUniqueId(), now);
        refreshArsenalItem(player);
        player.sendMessage("§cCouteau lancé !");

        Location loc = player.getEyeLocation().clone();
        Vector direction = loc.getDirection().normalize();
        org.bukkit.entity.Item flyingKnife = player.getWorld().dropItem(
                loc, new ItemStack(Material.IRON_SWORD));
        flyingKnife.setVelocity(direction.clone().multiply(2.5));
        flyingKnife.setPickupDelay(Integer.MAX_VALUE);

        BukkitTask[] task = new BukkitTask[1];
        task[0] = plugin.getServer().getScheduler().runTaskTimer(plugin, new Runnable() {
            int ticks = 0;
            boolean hit = false;
            @Override
            public void run() {
                if (ticks >= 40 || !player.isOnline() || hit) {
                    flyingKnife.remove();
                    task[0].cancel();
                    return;
                }
                Location kLoc = flyingKnife.getLocation();
                for (Player nearby : Bukkit.getOnlinePlayers()) {
                    if (nearby.equals(player)) continue;
                    if (nearby.getLocation().distance(kLoc) < 1.5) {
                        hit = true;
                        double baseDmg = 3.0;
                        double dmg = applyBloodBonus(player, nearby, baseDmg);
                        double newHealth = Math.max(0, nearby.getHealth() - dmg);
                        nearby.setHealth(newHealth);
                        nearby.damage(0.001, player);
                        nearby.sendMessage("§cTu as été touché par un couteau ! (-1,5❤)");
                        player.sendMessage("§cCouteau touché sur " + nearby.getName() + " !");
                        trackHit(nearby);
                        flyingKnife.remove();
                        task[0].cancel();
                        return;
                    }
                }
                ticks++;
            }
        }, 0L, 1L);
    }

    private void useKatana(Player player) {
        long now = System.currentTimeMillis();
        long cd = katanaCooldown.getOrDefault(player.getUniqueId(), 0L);
        if (now - cd < 60000) {
            player.sendMessage("§cCooldown Katana ! Encore " + ((60000 - (now - cd)) / 1000) + "s");
            return;
        }
        int charges = katanaCharges.getOrDefault(player.getUniqueId(), 0);
        if (charges <= 0) {
            player.sendMessage("§cPlus de Katanas !");
            return;
        }
        Player target = getTargetPlayer(player, 6.0);
        if (target == null) {
            player.sendMessage("§cAucune cible !");
            return;
        }
        katanaCharges.put(player.getUniqueId(), charges - 1);
        katanaCooldown.put(player.getUniqueId(), now);
        refreshArsenalItem(player);

        immobilize(target, 30);

        if (target.getHealth() <= 4.0) {
            target.damage(1000.0, player);
            player.sendMessage("§4EXÉCUTION de " + target.getName() + " !");
        } else {
            player.sendMessage("§cKatana utilisé sur " + target.getName() + " !");
            target.sendMessage("§cTu as été immobilisé par le Katana !");
        }
        trackHit(target);
    }

    private void immobilize(Player player, int ticks) {
        Location frozenLoc = player.getLocation().clone();
        BukkitTask[] stunTask = new BukkitTask[1];
        stunTask[0] = plugin.getServer().getScheduler().runTaskTimer(plugin, new Runnable() {
            int elapsed = 0;
            @Override
            public void run() {
                if (!player.isOnline() || elapsed >= ticks) {
                    stunTask[0].cancel();
                    return;
                }
                Location current = player.getLocation();
                frozenLoc.setYaw(current.getYaw());
                frozenLoc.setPitch(current.getPitch());
                player.teleport(frozenLoc);
                elapsed++;
            }
        }, 0L, 1L);
    }

    public void onCoagulation(Player stain) {
        long now = System.currentTimeMillis();
        long cd = coagulationCooldown.getOrDefault(stain.getUniqueId(), 0L);
        if (now - cd < 90000) {
            stain.sendMessage("§cCooldown Coagulation ! Encore " + ((90000 - (now - cd)) / 1000) + "s");
            return;
        }
        coagulationCooldown.put(stain.getUniqueId(), now);
        stain.sendMessage("§4Coagulation activée !");

        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.equals(stain)) continue;
            Long lastHit = lastHitTime.get(p.getUniqueId());
            if (lastHit == null || now - lastHit > 30000) continue;

            String group = getBloodGroup(p);
            int duration;
            double threshold;
            switch (group) {
                case "A":  duration = 80;  threshold = 5.0;  break;
                case "AB": duration = 100; threshold = 6.0;  break;
                case "B":  duration = 120; threshold = 7.0;  break;
                default:   duration = 60;  threshold = 3.0;  break;
            }
            coagulatedPlayers.put(p.getUniqueId(), threshold);

            Location frozenLoc = p.getLocation().clone();
            final Player fp = p;
            final int dur = duration;
            BukkitTask[] stunTask = new BukkitTask[1];
            stunTask[0] = plugin.getServer().getScheduler().runTaskTimer(plugin, new Runnable() {
                int elapsed = 0;
                @Override
                public void run() {
                    if (!fp.isOnline() || elapsed >= dur || !coagulatedPlayers.containsKey(fp.getUniqueId())) {
                        coagulatedPlayers.remove(fp.getUniqueId());
                        coagulationTasks.remove(fp.getUniqueId());
                        stunTask[0].cancel();
                        return;
                    }
                    Location current = fp.getLocation();
                    frozenLoc.setYaw(current.getYaw());
                    frozenLoc.setPitch(current.getPitch());
                    fp.teleport(frozenLoc);
                    elapsed++;
                }
            }, 0L, 1L);
            coagulationTasks.put(p.getUniqueId(), stunTask[0]);
            p.sendMessage("§4Tu es coagulé ! (" + group + ")");
            stain.sendMessage("§4" + p.getName() + " est coagulé (" + group + ") !");
        }
    }

    public void onCoagulatedPlayerDamage(Player player, double damage) {
        if (!coagulatedPlayers.containsKey(player.getUniqueId())) return;
        double threshold = coagulatedPlayers.get(player.getUniqueId());
        if (damage >= threshold) {
            coagulatedPlayers.remove(player.getUniqueId());
            if (coagulationTasks.containsKey(player.getUniqueId())) {
                coagulationTasks.get(player.getUniqueId()).cancel();
                coagulationTasks.remove(player.getUniqueId());
            }
            player.sendMessage("§aCoagulation brisée !");
        }
    }

    public boolean isCoagulated(Player player) {
        return coagulatedPlayers.containsKey(player.getUniqueId());
    }

    private double applyBloodBonus(Player stain, Player victim, double baseDamage) {
        String group = getBloodGroup(victim);
        switch (group) {
            case "A":  return baseDamage * 1.05;
            case "AB": return baseDamage * 1.10;
            case "B":  return baseDamage * 1.15;
            default:   return baseDamage;
        }
    }

    public double getDamageMultiplier(Player victim) {
        String group = getBloodGroup(victim);
        switch (group) {
            case "A":  return 1.05;
            case "AB": return 1.10;
            case "B":  return 1.15;
            default:   return 1.0;
        }
    }

    private void startNametaskDisplay(Player stain) {
        Scoreboard board = stain.getScoreboard();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.equals(stain)) continue;
            applyBloodTag(board, p);
        }

        plugin.getServer().getScheduler().runTaskTimer(plugin, new Runnable() {
            @Override
            public void run() {
                if (!stain.isOnline()) return;
                Scoreboard board = stain.getScoreboard();
                for (Player p : Bukkit.getOnlinePlayers()) {
                    if (p.equals(stain)) continue;
                    String teamName = "blood_" + p.getName().substring(0, Math.min(p.getName().length(), 10));
                    if (board.getTeam(teamName) == null) {
                        applyBloodTag(board, p);
                    }
                }
            }
        }, 0L, 40L);
    }

    private void applyBloodTag(Scoreboard board, Player target) {
        String group = getBloodGroup(target);
        String color;
        switch (group) {
            case "A":  color = "§a"; break;
            case "AB": color = "§5"; break;
            case "B":  color = "§9"; break;
            default:   color = "§f"; break;
        }
        try {
            String teamName = "blood_" + target.getName().substring(0, Math.min(target.getName().length(), 10));
            Team team = board.getTeam(teamName);
            if (team == null) team = board.registerNewTeam(teamName);
            team.setPrefix(color + "[" + group + "] ");
            if (!team.hasEntry(target.getName())) team.addEntry(target.getName());
        } catch (Exception e) {
            // ignore
        }
    }

    public boolean isArsenalItem(ItemStack item) {
        if (item == null || item.getType() != Material.STICK) return false;
        if (!item.hasItemMeta()) return false;
        ItemMeta meta = item.getItemMeta();
        return meta.hasDisplayName() && meta.getDisplayName().equals(ChatColor.DARK_RED + "Arsenal");
    }

    public boolean isCoagulationItem(ItemStack item) {
        if (item == null || item.getType() != Material.NETHER_STAR) return false;
        if (!item.hasItemMeta()) return false;
        ItemMeta meta = item.getItemMeta();
        return meta.hasDisplayName() && meta.getDisplayName().equals(ChatColor.DARK_RED + "Coagulation");
    }

    public void trackHit(Player victim) {
        lastHitTime.put(victim.getUniqueId(), System.currentTimeMillis());
    }
}