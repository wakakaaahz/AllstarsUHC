package fr.wakakaaa.roles;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import fr.wakakaaa.Main;
import net.minecraft.server.v1_8_R3.EnumParticle;
import net.minecraft.server.v1_8_R3.PacketPlayOutWorldParticles;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.EulerAngle;
import org.bukkit.util.Vector;

import java.lang.reflect.Field;
import java.util.*;

public class GojoRole implements Role {

    private Main plugin;
    private Map<UUID, Boolean> infinityActive = new HashMap<>();
    private Map<UUID, Long> infinityCooldown = new HashMap<>();
    private Map<UUID, Integer> selectedSpell = new HashMap<>();
    private Map<UUID, Long> blueCooldown = new HashMap<>();
    private Map<UUID, Long> redCooldown = new HashMap<>();
    private Map<UUID, Boolean> violetUsed = new HashMap<>();
    private Map<UUID, Boolean> channelingViolet = new HashMap<>();

    private static final String TEXTURE_BLUE =
            "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQu" +
                    "bmV0L3RleHR1cmUvZjIxMzhlY2IzZDliODQ1YzcxZjAzOTg5MzIwM2VhMjZlNmVjMjliOGNl" +
                    "OWM4ZDg1MGZmZTI2MjEwYjljNTc1YyJ9fX0=";

    private static final String TEXTURE_RED =
            "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQu" +
                    "bmV0L3RleHR1cmUvMTkwMjUzYzQ5ZTEzY2MyZGUwMDA5MGVlNjU4MDlkYTYxN2M1M2Y1OWUz" +
                    "NWYwOWE3YzZlMzUwMTFkMTlhY2IzZCJ9fX0=";

    public GojoRole() {
        this.plugin = Main.getInstance();
    }

    @Override
    public String getName() { return "Gojo"; }

    @Override
    public String getDescription() { return "Le plus fort !"; }

    @Override
    public void applyRole(Player player) {
        player.sendMessage(ChatColor.WHITE + "Tu es " + ChatColor.AQUA + "Gojo Satoru !");
        player.sendMessage(ChatColor.WHITE + getDescription());
        player.setMaxHealth(24.0);
        player.setHealth(24.0);
        infinityActive.put(player.getUniqueId(), true);
        selectedSpell.put(player.getUniqueId(), 0);
        violetUsed.put(player.getUniqueId(), false);
        channelingViolet.put(player.getUniqueId(), false);
        giveItems(player);
        startCircleDisplay(player);
    }

    @Override
    public void removeRole(Player player) {
        player.setMaxHealth(20.0);
        player.setHealth(Math.min(player.getHealth(), 20.0));
        infinityActive.remove(player.getUniqueId());
        infinityCooldown.remove(player.getUniqueId());
        selectedSpell.remove(player.getUniqueId());
        blueCooldown.remove(player.getUniqueId());
        redCooldown.remove(player.getUniqueId());
        violetUsed.remove(player.getUniqueId());
        channelingViolet.remove(player.getUniqueId());
    }

    public void removeAllPlayers() {
        for (UUID uuid : new HashSet<>(infinityActive.keySet())) {
            Player player = Bukkit.getPlayer(uuid);
            if (player != null) {
                player.setMaxHealth(20.0);
                player.setHealth(Math.min(player.getHealth(), 20.0));
            }
        }
        infinityActive.clear();
        infinityCooldown.clear();
        selectedSpell.clear();
        blueCooldown.clear();
        redCooldown.clear();
        violetUsed.clear();
        channelingViolet.clear();
    }

    @Override
    public void onAbility(Player player) {}

    private void giveItems(Player player) {
        ItemStack star = new ItemStack(Material.NETHER_STAR);
        ItemMeta meta = star.getItemMeta();
        meta.setDisplayName(ChatColor.WHITE + "Illimité");
        star.setItemMeta(meta);
        updateSpellLore(player, star);
        player.getInventory().setItem(0, star);
    }

    private void updateSpellLore(Player player, ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        int spell = selectedSpell.getOrDefault(player.getUniqueId(), 0);
        List<String> lore = new ArrayList<>();
        long now = System.currentTimeMillis();
        long blueLeft = Math.max(0, 30000 - (now - blueCooldown.getOrDefault(player.getUniqueId(), 0L))) / 1000;
        long redLeft = Math.max(0, 30000 - (now - redCooldown.getOrDefault(player.getUniqueId(), 0L))) / 1000;
        boolean vUsed = violetUsed.getOrDefault(player.getUniqueId(), false);
        lore.add((spell == 0 ? "§f§l▶ " : "§7") + "§9Bleu" + (blueLeft > 0 ? " §c(" + blueLeft + "s)" : " §a(Prêt)"));
        lore.add((spell == 1 ? "§f§l▶ " : "§7") + "§cRouge" + (redLeft > 0 ? " §c(" + redLeft + "s)" : " §a(Prêt)"));
        lore.add((spell == 2 ? "§f§l▶ " : "§7") + "§5Violet" + (vUsed ? " §c(Utilisé)" : " §a(Prêt)"));
        lore.add("");
        lore.add("§7Clic-Gauche: Changer de sort");
        lore.add("§7Clic-Droit: Utiliser le sort");
        meta.setLore(lore);
        item.setItemMeta(meta);
    }

    public void refreshItem(Player player) {
        ItemStack item = player.getInventory().getItem(0);
        if (item != null && item.getType() == Material.NETHER_STAR) {
            ItemMeta meta = item.getItemMeta();
            if (meta != null && meta.getDisplayName().equals(ChatColor.WHITE + "Illimité")) {
                updateSpellLore(player, item);
                player.getInventory().setItem(0, item);
            }
        }
    }

    public void onLeftClick(Player player) {
        int current = selectedSpell.getOrDefault(player.getUniqueId(), 0);
        int next = (current + 1) % 3;
        selectedSpell.put(player.getUniqueId(), next);
        // Message en chat retiré — remplacé par l'action bar dans le listener
        refreshItem(player);
    }

    public String getSelectedSpellName(Player player) {
        int spell = selectedSpell.getOrDefault(player.getUniqueId(), 0);
        switch (spell) {
            case 0: return ChatColor.WHITE + "Sort : " + ChatColor.BLUE + "✦ Bleu";
            case 1: return ChatColor.WHITE + "Sort : " + ChatColor.RED + "✦ Rouge";
            case 2: return ChatColor.WHITE + "Sort : " + ChatColor.DARK_PURPLE + "✦ Violet";
            default: return ChatColor.WHITE + "Illimité";
        }
    }

    public void onRightClick(Player player) {
        if (channelingViolet.getOrDefault(player.getUniqueId(), false)) {
            player.sendMessage("§cTu es en train de canaliser !");
            return;
        }
        int spell = selectedSpell.getOrDefault(player.getUniqueId(), 0);
        switch (spell) {
            case 0: castBlue(player); break;
            case 1: castRed(player); break;
            case 2: castViolet(player); break;
        }
    }

    private void castBlue(Player player) {
        long now = System.currentTimeMillis();
        long lastUse = blueCooldown.getOrDefault(player.getUniqueId(), 0L);
        if (now - lastUse < 30000) {
            player.sendMessage("§cCooldown Bleu ! Encore " + ((30000 - (now - lastUse)) / 1000) + "s");
            return;
        }
        blueCooldown.put(player.getUniqueId(), now);
        player.sendMessage("§9Orbe Bleue invoquée !");

        final Location[] orbLoc = { player.getEyeLocation().clone() };
        final double speed = 0.4;
        final double maxDistance = 15.0;

        BukkitTask[] taskHolder = new BukkitTask[1];
        taskHolder[0] = plugin.getServer().getScheduler().runTaskTimer(plugin, new Runnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks >= 100 || !player.isOnline()) {
                    for (Player nearby : Bukkit.getOnlinePlayers()) {
                        if (!nearby.equals(player) && nearby.getLocation().distance(orbLoc[0]) < 5.0) {
                            // ── FIX : setHealth bypass l'armure ──
                            double newHealth = Math.max(0, nearby.getHealth() - 2.0);
                            nearby.setHealth(newHealth);
                            nearby.damage(0.001, player); // attribution du kill
                            Vector pull = orbLoc[0].clone().subtract(nearby.getLocation()).toVector().normalize().multiply(2.5);
                            pull.setY(0.3);
                            nearby.setVelocity(pull);
                            nearby.sendMessage("§9Tu as été attiré par l'orbe bleue !");
                        }
                    }
                    for (int i = 0; i < 10; i++)
                        orbLoc[0].getWorld().playEffect(orbLoc[0], Effect.COLOURED_DUST, 15);
                    taskHolder[0].cancel();
                    refreshItem(player);
                    return;
                }
                Vector dir = player.getEyeLocation().getDirection().normalize().multiply(speed);
                orbLoc[0].add(dir);
                double dist = orbLoc[0].distance(player.getEyeLocation());
                if (dist > maxDistance) {
                    orbLoc[0] = player.getEyeLocation().clone().add(
                            player.getEyeLocation().getDirection().normalize().multiply(maxDistance));
                }
                orbLoc[0].getWorld().playEffect(orbLoc[0], Effect.COLOURED_DUST, 15);
                orbLoc[0].getWorld().playEffect(orbLoc[0], Effect.COLOURED_DUST, 15);
                orbLoc[0].getWorld().playEffect(orbLoc[0], Effect.COLOURED_DUST, 11);
                for (Player nearby : Bukkit.getOnlinePlayers()) {
                    if (!nearby.equals(player) && nearby.getLocation().distance(orbLoc[0]) < 5.0) {
                        Vector pull = orbLoc[0].clone().subtract(nearby.getLocation()).toVector().normalize().multiply(0.4);
                        nearby.setVelocity(pull);
                    }
                }
                ticks++;
            }
        }, 0L, 1L);
    }

    private void castRed(Player player) {
        long now = System.currentTimeMillis();
        long lastUse = redCooldown.getOrDefault(player.getUniqueId(), 0L);
        if (now - lastUse < 30000) {
            player.sendMessage("§cCooldown Rouge ! Encore " + ((30000 - (now - lastUse)) / 1000) + "s");
            return;
        }
        redCooldown.put(player.getUniqueId(), now);
        player.sendMessage("§cOrbe Rouge invoquée !");

        Location orbLoc = player.getEyeLocation().clone();
        Vector direction = player.getLocation().getDirection().normalize();

        org.bukkit.entity.Item flyingHead = player.getWorld().dropItem(
                player.getEyeLocation(), new ItemStack(Material.SKULL_ITEM, 1, (short) 3));
        flyingHead.setVelocity(direction.clone().multiply(2.0));
        flyingHead.setPickupDelay(Integer.MAX_VALUE);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> flyingHead.remove(), 60L);

        BukkitTask[] taskHolder = new BukkitTask[1];
        taskHolder[0] = plugin.getServer().getScheduler().runTaskTimer(plugin, new Runnable() {
            int blocks = 0;
            Set<UUID> alreadyHit = new HashSet<>();
            @Override
            public void run() {
                if (blocks >= 20 || !player.isOnline()) {
                    taskHolder[0].cancel();
                    refreshItem(player);
                    return;
                }
                orbLoc.add(direction.clone().multiply(1));
                orbLoc.getWorld().playEffect(orbLoc, Effect.COLOURED_DUST, 14);
                for (Player nearby : Bukkit.getOnlinePlayers()) {
                    if (!nearby.equals(player) && !alreadyHit.contains(nearby.getUniqueId())
                            && nearby.getLocation().distance(orbLoc) < 3.0) {
                        alreadyHit.add(nearby.getUniqueId());

                        // ── FIX : setHealth bypass l'armure ──
                        double newHealth = Math.max(0, nearby.getHealth() - 2.0);
                        nearby.setHealth(newHealth);
                        nearby.damage(0.001, player); // attribution du kill

                        nearby.sendMessage("§cTu as été repoussé par l'orbe rouge !");
                        Player finalNearby = nearby;
                        for (int t = 0; t < 3; t++) {
                            plugin.getServer().getScheduler().runTaskLater(plugin, new Runnable() {
                                @Override public void run() {
                                    if (!finalNearby.isOnline()) return;
                                    Vector repulse = direction.clone().normalize().multiply(3.8);
                                    repulse.setY(0.5);
                                    finalNearby.setVelocity(repulse);
                                }
                            }, t);
                        }
                        Location targetLoc = nearby.getLocation().clone();
                        for (int i = 1; i <= 15; i++) {
                            Location blockLoc = targetLoc.clone().add(direction.clone().multiply(i));
                            Material blockType = blockLoc.getBlock().getType();
                            if (blockType != Material.AIR && blockType != Material.BEDROCK)
                                blockLoc.getBlock().setType(Material.AIR);
                            for (int dy = -1; dy <= 2; dy++) {
                                Location sideLoc = blockLoc.clone().add(0, dy, 0);
                                Material sideType = sideLoc.getBlock().getType();
                                if (sideType != Material.AIR && sideType != Material.BEDROCK)
                                    sideLoc.getBlock().setType(Material.AIR);
                            }
                        }
                    }
                }
                blocks++;
            }
        }, 0L, 1L);
    }

    private void castViolet(Player player) {
        if (violetUsed.getOrDefault(player.getUniqueId(), false)) {
            player.sendMessage("§cViolet déjà utilisé cette partie !");
            return;
        }
        long now = System.currentTimeMillis();
        boolean blueReady = now - blueCooldown.getOrDefault(player.getUniqueId(), 0L) >= 30000;
        boolean redReady = now - redCooldown.getOrDefault(player.getUniqueId(), 0L) >= 30000;
        if (!blueReady || !redReady) {
            player.sendMessage("§cBesoin de Bleu ET Rouge disponibles !");
            return;
        }

        blueCooldown.put(player.getUniqueId(), now);
        redCooldown.put(player.getUniqueId(), now);
        channelingViolet.put(player.getUniqueId(), true);
        player.sendMessage("§5Canalisation de l'orbe violette...");

        Location origin = player.getLocation();
        Vector dir = origin.getDirection().normalize();
        Vector right = new Vector(-dir.getZ(), 0, dir.getX()).normalize();

        Location blueStart = player.getEyeLocation().clone().add(right.clone().multiply(-2.5)).add(0, -0.5, 0);
        Location redStart  = player.getEyeLocation().clone().add(right.clone().multiply(2.5)).add(0, -0.5, 0);
        Location meetPoint = player.getEyeLocation().clone().add(dir.clone().multiply(2)).add(0, -0.5, 0);

        ArmorStand blueStand = spawnOrbStand(blueStart, TEXTURE_BLUE);
        ArmorStand redStand  = spawnOrbStand(redStart,  TEXTURE_RED);

        int orbTicks = 60;
        BukkitTask[] taskHolder = new BukkitTask[1];
        taskHolder[0] = plugin.getServer().getScheduler().runTaskTimer(plugin, new Runnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (!player.isOnline()) {
                    blueStand.remove();
                    redStand.remove();
                    taskHolder[0].cancel();
                    return;
                }

                if (ticks >= orbTicks) {
                    blueStand.remove();
                    redStand.remove();
                    for (int i = 0; i < 20; i++)
                        spawnParticle(meetPoint, EnumParticle.CLOUD);
                    meetPoint.getWorld().playSound(meetPoint, Sound.EXPLODE, 2.0f, 0.8f);
                    channelingViolet.put(player.getUniqueId(), false);
                    violetUsed.put(player.getUniqueId(), true);
                    fireViolet(player, dir);
                    taskHolder[0].cancel();
                    refreshItem(player);
                    return;
                }

                double t = (double) ticks / orbTicks;
                Location posBlue = lerp(blueStart, meetPoint, t);
                Location posRed  = lerp(redStart,  meetPoint, t);

                blueStand.teleport(posBlue);
                redStand.teleport(posRed);

                spawnParticle(posBlue, EnumParticle.FIREWORKS_SPARK);
                spawnParticle(posBlue, EnumParticle.FIREWORKS_SPARK);
                spawnParticle(posRed,  EnumParticle.FIREWORKS_SPARK);
                spawnParticle(posRed,  EnumParticle.FIREWORKS_SPARK);

                ticks++;
            }
        }, 0L, 1L);
    }

    private void fireViolet(Player player, Vector direction) {
        player.sendMessage("§5Rayon Violet libéré !");
        Location pos = player.getEyeLocation().clone();
        int tunnelRadius = 2;
        double speed = 1.0;
        int travelTicks = 80;

        List<int[]> shell    = buildSphereShell(tunnelRadius);
        List<int[]> interior = buildSphereInterior(tunnelRadius);
        Set<String> prevBlocks = new HashSet<>();

        BukkitTask[] taskHolder = new BukkitTask[1];
        taskHolder[0] = plugin.getServer().getScheduler().runTaskTimer(plugin, new Runnable() {
            int ticks = 0;
            Set<UUID> alreadyHit = new HashSet<>();

            @Override
            public void run() {
                if (ticks >= travelTicks || !player.isOnline()) {
                    clearSphereBlocks(prevBlocks, pos.getWorld());
                    taskHolder[0].cancel();
                    return;
                }

                pos.add(direction.clone().multiply(speed));

                Set<String> newBlocks = computeBlockKeys(pos, shell, interior);

                Set<String> toRemove = new HashSet<>(prevBlocks);
                toRemove.removeAll(newBlocks);
                clearSphereBlocks(toRemove, pos.getWorld());

                placeSphere(pos, shell, interior);
                destroyBlocksAround(pos, tunnelRadius + 1, newBlocks);

                spawnParticle(pos, EnumParticle.FIREWORKS_SPARK);
                spawnParticle(pos, EnumParticle.FIREWORKS_SPARK);

                for (Player nearby : Bukkit.getOnlinePlayers()) {
                    if (!nearby.equals(player) && !alreadyHit.contains(nearby.getUniqueId())
                            && nearby.getLocation().distance(pos) < tunnelRadius + 1) {
                        alreadyHit.add(nearby.getUniqueId());
                        double finalHealth = Math.max(0, nearby.getHealth() - 6.0);
                        nearby.setHealth(finalHealth);
                        nearby.damage(0.001, player);
                        nearby.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 20 * 60, 0));
                        nearby.sendMessage("§5Tu as été touché par le rayon violet !");
                    }
                }

                prevBlocks.clear();
                prevBlocks.addAll(newBlocks);
                ticks++;
            }
        }, 0L, 1L);
    }

    // =========================================================================
    // HELPERS SPHÈRE
    // =========================================================================

    private List<int[]> buildSphereShell(int r) {
        List<int[]> list = new ArrayList<>();
        for (int x = -r; x <= r; x++)
            for (int y = -r; y <= r; y++)
                for (int z = -r; z <= r; z++) {
                    double d = Math.sqrt(x*x + y*y + z*z);
                    if (d >= r - 0.5 && d <= r + 0.5) list.add(new int[]{x, y, z});
                }
        return list;
    }

    private List<int[]> buildSphereInterior(int r) {
        List<int[]> list = new ArrayList<>();
        for (int x = -r; x <= r; x++)
            for (int y = -r; y <= r; y++)
                for (int z = -r; z <= r; z++) {
                    double d = Math.sqrt(x*x + y*y + z*z);
                    if (d < r - 0.5) list.add(new int[]{x, y, z});
                }
        return list;
    }

    private Set<String> computeBlockKeys(Location c, List<int[]> shell, List<int[]> interior) {
        Set<String> keys = new HashSet<>();
        int cx = c.getBlockX(), cy = c.getBlockY(), cz = c.getBlockZ();
        for (int[] o : interior) keys.add((cx+o[0])+","+(cy+o[1])+","+(cz+o[2]));
        for (int[] o : shell)    keys.add((cx+o[0])+","+(cy+o[1])+","+(cz+o[2]));
        return keys;
    }

    private void placeSphere(Location c, List<int[]> shell, List<int[]> interior) {
        World w = c.getWorld();
        int cx = c.getBlockX(), cy = c.getBlockY(), cz = c.getBlockZ();
        for (int[] o : interior) {
            Block b = w.getBlockAt(cx+o[0], cy+o[1], cz+o[2]);
            if (b.getType() == Material.AIR) {
                b.setType(Material.WOOL);
                b.setData((byte) 10);
            }
        }
        for (int[] o : shell) {
            Block b = w.getBlockAt(cx+o[0], cy+o[1], cz+o[2]);
            if (b.getType() == Material.AIR || b.getType() == Material.WOOL) {
                b.setType(Material.STAINED_GLASS);
                b.setData((byte) 10);
            }
        }
    }

    private void clearSphereBlocks(Set<String> keys, World world) {
        for (String key : keys) {
            String[] p = key.split(",");
            Block b = world.getBlockAt(Integer.parseInt(p[0]), Integer.parseInt(p[1]), Integer.parseInt(p[2]));
            Material m = b.getType();
            if (m == Material.WOOL || m == Material.STAINED_GLASS)
                b.setType(Material.AIR);
        }
    }

    private void destroyBlocksAround(Location c, int r, Set<String> sphereKeys) {
        World w = c.getWorld();
        int cx = c.getBlockX(), cy = c.getBlockY(), cz = c.getBlockZ();
        for (int x = -r; x <= r; x++)
            for (int y = -r; y <= r; y++)
                for (int z = -r; z <= r; z++) {
                    if (x*x + y*y + z*z > r*r) continue;
                    String key = (cx+x)+","+(cy+y)+","+(cz+z);
                    if (sphereKeys.contains(key)) continue;
                    Block b = w.getBlockAt(cx+x, cy+y, cz+z);
                    Material m = b.getType();
                    if (m == Material.AIR || m == Material.BEDROCK) continue;
                    b.setType(Material.AIR);
                }
    }

    // =========================================================================
    // HELPERS ARMOR STAND
    // =========================================================================

    private ArmorStand spawnOrbStand(Location loc, String texture) {
        ArmorStand s = (ArmorStand) loc.getWorld().spawnEntity(loc, EntityType.ARMOR_STAND);
        s.setVisible(false);
        s.setGravity(false);
        s.setSmall(false);
        s.setArms(false);
        s.setBasePlate(false);
        s.setCanPickupItems(false);
        s.setCustomNameVisible(false);
        s.setHeadPose(new EulerAngle(0, 0, 0));
        s.setHelmet(customSkull(texture));
        return s;
    }

    private ItemStack customSkull(String base64) {
        ItemStack skull = new ItemStack(Material.SKULL_ITEM, 1, (short) 3);
        SkullMeta meta  = (SkullMeta) skull.getItemMeta();
        try {
            GameProfile profile = new GameProfile(UUID.randomUUID(), "GojoOrb");
            profile.getProperties().put("textures", new Property("textures", base64));
            Field f = meta.getClass().getDeclaredField("profile");
            f.setAccessible(true);
            f.set(meta, profile);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        skull.setItemMeta(meta);
        return skull;
    }

    // =========================================================================
    // HELPERS PARTICULES NMS
    // =========================================================================

    private void spawnParticle(Location loc, EnumParticle type) {
        PacketPlayOutWorldParticles pkt = new PacketPlayOutWorldParticles(
                type, true,
                (float) loc.getX(), (float) loc.getY(), (float) loc.getZ(),
                0.3f, 0.3f, 0.3f, 0f, 1
        );
        double range = 64;
        double r2 = range * range;
        for (Player p : loc.getWorld().getPlayers())
            if (p.getLocation().distanceSquared(loc) <= r2)
                ((CraftPlayer) p).getHandle().playerConnection.sendPacket(pkt);
    }

    private Location lerp(Location a, Location b, double t) {
        return new Location(a.getWorld(),
                a.getX() + (b.getX() - a.getX()) * t,
                a.getY() + (b.getY() - a.getY()) * t,
                a.getZ() + (b.getZ() - a.getZ()) * t);
    }

    // =========================================================================
    // RESTE DU ROLE
    // =========================================================================

    private void startCircleDisplay(Player player) {
        plugin.getServer().getScheduler().runTaskTimer(plugin, new Runnable() {
            @Override
            public void run() {
                if (!player.isOnline()) return;
                if (!infinityActive.getOrDefault(player.getUniqueId(), false)) return;
                Location center = player.getLocation();
                double radius = 2.0;
                int points = 16;
                for (int i = 0; i < points; i++) {
                    double angle = (2 * Math.PI * i) / points;
                    double x = center.getX() + radius * Math.cos(angle);
                    double z = center.getZ() + radius * Math.sin(angle);
                    Location particleLoc = new Location(center.getWorld(), x, center.getY(), z);
                    center.getWorld().playEffect(particleLoc, Effect.COLOURED_DUST, 15);
                }
            }
        }, 0L, 5L);
    }

    public boolean isInfinityActive(Player player) {
        return infinityActive.getOrDefault(player.getUniqueId(), false);
    }

    public void triggerInfinityEscape(Player player) {
        infinityActive.put(player.getUniqueId(), false);
        player.sendMessage("§cInfini brisé ! Réactivation dans 6s...");
        plugin.getServer().getScheduler().runTaskLater(plugin, new Runnable() {
            @Override
            public void run() {
                if (!player.isOnline()) return;
                infinityActive.put(player.getUniqueId(), true);
                player.sendMessage("§aInfini réactivé !");
            }
        }, 20L * 6);
    }

    public double getInfinityRadius() {
        return 2.0;
    }
}